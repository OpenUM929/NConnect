G-A062 PC2 batch point p5_dof_acc_l2_m1p25e_7: 부모 P0 위 dof_acc_l2 -2.5e-07 -> -1.25e-07. P0 G3 후보. G-A061 N5와 같은 보상(트리 순서 대신 일괄 실행).
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
