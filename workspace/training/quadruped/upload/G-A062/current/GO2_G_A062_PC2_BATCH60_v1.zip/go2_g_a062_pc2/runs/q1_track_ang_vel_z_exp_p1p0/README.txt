G-A062 PC2 batch point q1_track_ang_vel_z_exp_p1p0: 부모 Q0 위 track_ang_vel_z_exp 0.75 -> 1. Q0 우회전 낙상 해결 후보 ①. 배포 고급 옵션 '회전 민첩 … ↑ 빠른 선회'. 경쟁 가설: 우회전은 추종 부족이 아니라 안쪽 지지 붕괴(Codex C4).
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
