G-A063 PC2 batch point s01_lin_vel_z_l2_m5: 부모 P0 위 lin_vel_z_l2 -1.25 -> -5. 배포 범위 최강. 배포 ③ '강하게: 몸을 낮게 깔고 안정 (험지/계단 유리, 대신 굼뜸)'.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
