GO2 G-A047 REWARD CHANGE ON G-A033 — flat_orientation_l2 0.0 -> -0.5
====================================================================

This package TRAINS one policy and then measures it.  status: exploratory.
One upload, one command, one result ZIP: the whole 69-case evaluation runs in a single
pass (run_config.env pins GO2_STAGE=full), so there is no target stage and no server gate.
  unzip -oq <this zip> -d /workspace
  bash /workspace/go2_g_a047/server_run_go2_candidate_iter_pinned.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_g_a047/server_run_go2_candidate_iter_pinned.sh

WHAT CHANGES
  Exactly one reward weight: flat_orientation_l2 0.0 -> -0.5.
  candidate/quadruped_rewards.py and reference/baseline_quadruped_rewards.py differ in that line only.
  Training length, seed, env count and every other weight are G-A033's.

WHY (analysis GO2_G_A047_PLAN_20260926.md)
  Purpose: G3 rough-terrain survival on G-A033. This is not a stairs candidate and it does not ask whether a posture penalty can repair lin_vel_z -1.5's G2 loss - that combination is a separate, later question.
  G-A033's G3 scores 4.22726 of 14.0 and is bound by survival (rough_lateral 0.375); the survival-1.0 counterfactual is 10.71746 (reports/GO2_AXIS_BOTTLENECK.md).
  Role first (Isaac Lab formula, reports/evidence/go2_reward_term_roles_20260917/isaaclab_envs_mdp_rewards.py:90): flat_orientation_l2 charges the squared xy gravity components, the trunk's tilt ANGLE.
  On A033's rough_lateral the fall verdict is reached through the tilt channel alone for 9, 8 and 13 robots of 32 and through the height channel alone for 0 (posture-channel classification, not a causal diagnosis).
  The tilt rises before the roll-over: pre-contact 0.31123 against 0.05106, AUC 0.838 (TILT.csv) - an association in the frozen trajectory, not a prediction of the retrained policy.
  Every other deployed lever aimed at G3 is measured (lin_vel_z, ang_vel_xy both directions, track 1.6) or has no situation evidence (action_rate); this is the one deployed name never measured on a walking baseline.
  Protected, not targeted: G4 slope (the trunk must tilt on a slope), G5 stairs (climbers tilt more on two of three policies), the flat scenarios, G6 push and the stall shortcut.
  The situation arithmetic ranks candidates and nothing more: G-A043's sway and push came back opposite to it.

HOW THE VALUE WAS CHOSEN
  source: workspace/training/quadruped/upload/plan/GO2_G_A047_PLAN_20260926.md sections 2-3; reports/GO2_A038_REREAD_20260919.md sections 2-1 and 4-3; reports/GO2_AXIS_BOTTLENECK.md; reports/GO2_REWARD_MECHANISM_FORECAST.md sections 5, 5-1 and 8; evidence reports/evidence/go2_a038_reread_20260919/FALL_CHANNEL_ROLLUP.csv and reports/evidence/go2_a038_reread_20260919/ROUGH_LATERAL_ROLLUP.csv and reports/evidence/go2_reward_mechanism_20260917/ (TILT.csv, SITUATIONS.csv, PROBE_SITUATIONS.csv); reports/GO2_TUNING_BASE_DATA.md sections 0-1, 1 and 4
  role: Penalize non-flat base orientation using L2 squared kernel (Isaac Lab v2.3.1, reports/evidence/go2_reward_term_roles_20260917/isaaclab_envs_mdp_rewards.py:90): the squared xy components of projected gravity, that is the tilt angle of the trunk. It is the only deployed name that charges the angle rather than a velocity, and the posture gate that scores our survival reads that same angle (proj_grav_z).
  walk_margin: G-A033 walk margin +0.1359 -> +0.1245 at -0.5 (WALK), the smallest walk cost of the three probed magnitudes; the stop zone's top is +0.0155, so the candidate sits about eight times above it. The walking-side number is itself an estimate: the training logs carry no raw value for this term because every walking run weighted it 0, so the forecast substitutes the evaluation tilt value (forecast section 5, marked [추정]).
  situations: PROBE_SITUATIONS.csv fills all three situation columns for this term, unlike dof_acc_l2: climb +0.0560, sway +0.1548, push +0.1278 at -0.5. The forecast marks climb and sway with a cross-sign dagger, because the sign of those two partial margins disagrees between the three measured policies (SITUATIONS.csv). Only push agrees on all three.
  rule: -0.5 is the smallest magnitude in the probe grid (-0.5, -1.0, -2.5) and the smallest step that is still inside the band the deployed file writes for this dial (추천 0.0 ~ -2.0). Three independent reasons pick the smallest: (a) R-Sci-4 says a new penalty charged in full from iteration 1 is a stall risk, and we cannot apply the penalty curriculum that paper uses; (b) the only magnitude our own runs ever set is -1.0 (A013, A025) and both policies ended stationary, which is not a valid rejection (asymmetric instrumentation, G-D104) but is the only observation there is, and F5 asks a new size to be distinguishable from it; (c) every walking run weighted this term 0, so there is no observed range a fraction could sit inside and the smallest probed step is the one that risks least.
  not_claimed: No score gain is estimated and -0.5 is not shown to be promising: it is an exploration value measured together with its side effects. The partial margins are reward arithmetic over the frozen baseline's postures; they rank candidates and predict no behaviour (G-A043's sway and push directions came back opposite to the arithmetic, forecast section 9).

LEVERS NOT MOVED
  lin_vel_z_l2: measured on the walking baseline at -1.5 (G-A043) and -1.75 (G-A044), both INTERNAL_GATE_FAIL; the seed-43 replicate is the frozen v10 pair, which waits on U2. Measured is not the same as exhausted - the dial keeps information value - but repeating it on seed 42 buys nothing the pair does not.
  ang_vel_xy_l2: both directions measured on G-A033: -0.08 (G-A038) collapsed the 10 cm climb (robots with >=1 step 90 -> 5) and -0.04 (G-A041) was INTERNAL_GATE_FAIL. The rate dial is the one lever that shrank the rough_lateral tilt-channel falls, which is why the angle dial is the next question, not a retry.
  track_lin_vel_xy_exp: 1.6 measured (G-A042): 10 cm >=2 steps 43 -> 0 and posture falls 34 -> 85; 1.5 is the Isaac Lab Go2 rough value.
  feet_air_time: 0.01 and 0.1 failed stage 1 (A031, A032) and 0.35 stopped the policy (A015): closed in both directions.
  action_rate_l2: -0.008 is a valid rejection (A018); the strengthening direction is unmeasured and has no situation columns at all (PROBE_SITUATIONS.csv), so it carries information value but no evidence to aim it at G3.
  dof_acc_l2: outside the deployed six-name list (G-A039) and dependent on open decision U1-R6-ENV-REWARD-20260918.
  track_ang_vel_z_exp: never changed, and its situation values agree in sign on all three measured policies - but the arithmetic at 1.0 is the same climb-for-sway trade as G-A038 (climb -0.0158, sway +0.0957) at a worse ratio, and at 0.5 the mirror trade of lin_vel_z -1.5 at a worse ratio. Computed 2026-09-26 with tools/go2_reward_mechanism.spec_margin; not kept as evidence because it only ranks candidates.

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  No gain estimate exists and one training seed cannot
  separate the lever from seed luck.
  Pre-registered: all other axes held -- per-scenario weighted loss at most twice its own
  evaluation sd (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358), flat G1/G2 guards unchanged.

CHECKPOINT
  Evaluated at iter 900 of 1000, the iteration G-A033 was evaluated at.

VIDEOS (4 env x 500 steps)
  G3:rough_lateral:101       the target case: G3's binding case, where A033's fall verdicts reach the tilt channel alone for 9, 8 and 13 robots of 32. The lever charges exactly that angle; the video shows whether the roll-over shrinks or turns into a stall.
  G3:rough_forward:101       the other G3 case; an axis score is a min over cases, so a gain on the side-step bought with the forward case is not a G3 gain.
  G4:slope_plus_20:101       the first predicted way to lose: on a 20 degree slope the trunk must tilt, so this penalty charges the correct posture every step. A033 climbs this slope to the end; the video shows whether the candidate still does or levels its trunk and stalls.
  G5:stairs_10_down:101      the stairs guard the climbed-robot counter reads. On two of three measured policies the climbers tilt more than the stallers, so a climb regression is a named risk.
  G5:stairs_15_down:101      the stairs guard at the height G5's score is bound by; the lever is not expected to help here (G5's loss is stalling, AUC 0.387) and must not make it worse.
  G6:push_pos_x:101          G6's binding case; push is the only situation whose sign agrees on all three measured policies, so it is the guard most likely to move up and the one whose failure would refute the reading most directly.
  G2:combined_yaw_right:101  the flat case that decided G-A043's failure; filmed so a flat-turn posture loss is not read from counters alone.
  G1:forward_fast:101        the flat forward guard and the stall check: a stationary shortcut shows here first.

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
