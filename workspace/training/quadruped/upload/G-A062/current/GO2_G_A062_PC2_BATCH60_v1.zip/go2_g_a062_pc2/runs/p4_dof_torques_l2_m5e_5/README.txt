G-A062 PC2 batch point p4_dof_torques_l2_m5e_5: 부모 P0 위 dof_torques_l2 -0.0002 -> -5e-05. P0 G3 후보. N3(−1e−4)는 험지 옆걸음 41→19·G3 +2.7, 15cm ≥1단 52→0. 트리 규칙상 닫혔으나 사용자 지시로 포함.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
