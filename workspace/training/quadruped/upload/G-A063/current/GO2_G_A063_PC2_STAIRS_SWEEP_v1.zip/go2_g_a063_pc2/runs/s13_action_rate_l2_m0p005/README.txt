G-A063 PC2 batch point s13_action_rate_l2_m0p005: 부모 P0 위 action_rate_l2 -0.01 -> -0.005. 배포 범위 최약. 배포 ⑤ '약하게: 민첩하지만 다리 떨림'.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
