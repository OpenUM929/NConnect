G-A074 evaluation-only recovery.
Requires /workspace/_keep/go2_g_a074_report_policy with TRAIN_RC=0, iter-2400 checkpoint d39b88e9a6b06fd08498c90bbba334a3aaaca1cc8e540102c7d0e284bac72211.
The runner contains no training command and fails closed if the preserved run is missing.
