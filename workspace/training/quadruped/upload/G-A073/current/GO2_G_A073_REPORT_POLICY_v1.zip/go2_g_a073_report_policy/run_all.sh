#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
bash "$ROOT_DIR/run_point.sh" --inner report_policy_flat_orientation_l2_m0p25
