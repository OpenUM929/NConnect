G-A085 PC2 precision evaluation (no training)
unzip -oq /workspace/GO2_G_A085_PRECISION_EVAL_v1.zip -d /workspace
bash /workspace/go2_g_a085_precision_eval/run_all.sh
Starts only after G-A084 finished with RUNNER_RC=0 (else rc 26, nothing started).
Progress: cat /workspace/_keep/GO2_G_A085_STATUS.txt
