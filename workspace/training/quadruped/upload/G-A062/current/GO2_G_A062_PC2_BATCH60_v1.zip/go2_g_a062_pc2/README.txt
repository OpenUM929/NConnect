GO2 G-A062 PC2 일괄 실행 — 60점 목표 전략 6점 (설계 workspace/training/quadruped/upload/plan/GO2_PC2_BATCH_60_STRATEGY_20261004.md)
==================================================
점(실행 순서). P0 = PC2 A048(G-A060 B1), Q0 = P0 + lin_vel_z -1.5(A043 보상, 1번 점):
   1. q0_lin_vel_z_l2_m1p5             부모 P0  lin_vel_z_l2 -> -1.5
   2. q1_track_ang_vel_z_exp_p1p0      부모 Q0  track_ang_vel_z_exp -> 1
   3. q2_ang_vel_xy_l2_m0p06           부모 Q0  ang_vel_xy_l2 -> -0.06
   4. p5_dof_acc_l2_m1p25e_7           부모 P0  dof_acc_l2 -> -1.25e-07
   5. p6_dof_acc_l2_m6p25e_8           부모 P0  dof_acc_l2 -> -6.25e-08
   6. p4_dof_torques_l2_m5e_5          부모 P0  dof_torques_l2 -> -5e-05
점마다 학습 seed 42, 4096 env, 1000 iter, 평가 iter 900, 69 case, 영상 10편. 점당 약 2시간 25분 [추정].

1. 올리기: GO2_G_A062_PC2_BATCH60_v1.zip  SHA256 (발행 시 기록)  → /workspace/GO2_G_A062_PC2_BATCH60_v1.zip
2. 환경 변수: workspace/_keep/go2_g_a060_pc2_run_chain.sh 머리의 mount·export 줄을 먼저 실행한다.
3. 실행(한 줄, nohup 또는 tmux 안에서):
   unzip -oq /workspace/GO2_G_A062_PC2_BATCH60_v1.zip -d /workspace && bash /workspace/go2_g_a062_pc2/run_all.sh
   진행: /workspace/_keep/go2_g_a062_pc2_points/BATCH_RUN.log, POINT_STATUS.tsv
4. GPU 감시: tools/go2_gpu_watch.sh --hours 18 --pattern 'go2_g_a062_pc2_*' (패턴 필수, 감시는 기록만 한다)
5. 실패 처리: rc 20~25(환경·패키지)면 run_all 이 멈춘다 — 고친 뒤 같은 한 줄(끝난 점은 SKIP).
   rc 30~34(학습 뒤)는 다음 점으로 간다 — 끝난 뒤 'bash run_point.sh --only <key>' 로 그 점만 재개한다.
   학습 도중 실패(iter 900 checkpoint 없음)는 자동 재학습하지 않는다 — 보고한다.
6. 회수: 점마다 /workspace/_keep/go2_g_a062_pc2_<key>/ 폴더와 GO2_G_A062_PC2_<KEY>_RESULT.zip + .sha256,
   /workspace/_keep/go2_g_a062_pc2_points/ → 저장소 workspace/_keep/ (100MB 초과는 95MB parts).
