GO2 G-A033 CAMPAIGN — one upload, one command, one result
=========================================================

This package TRAINS 1 policy and measures
it.  status: exploratory.  Plan: GO2_BASIC_MOTION_TUNING_PLAN_20260915.md.

ARMS (byte for byte what tools/build_go2_candidate_package.py builds)
  G-A033  track_lin_vel_xy_exp 1.4 -> 1.5   arms/GO2_G_A033_track_lin_vel_xy_150_staged.zip  sha256 0e873d6532f1c6bd98cb726a6de9e92ab5eb413e75cc5feb3e93e6a97ddac7a2

RUN
  unzip -oq GO2_G_A033_track_lin_vel_xy_150_one_command.zip -d /workspace
  bash /workspace/go2_campaign_g_a033/server_run_go2_campaign.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_campaign_g_a033/server_run_go2_campaign.sh

WHAT HAPPENS
  1 the target stage of each arm (~1h25m each): training, catastrophe gate, the
    9 target cases, the sentinel, the videos.
  2 after each target stage, go2_target_gate.py reads criterion 1 (plan 6-1); the
    runner takes the verdict from the gate's JSON:
      TARGET_PASS -> full stage (~55m); FAIL -> the arm ends;
      REMEASURE_BASELINE -> target stage again with A017 remeasured, gate again;
      UNDECIDED -> no full stage.
  3 full stage of each arm the gate passed.
  4 one result ZIP.  The gate only schedules GPU time; the local verifier
    (tools/verify_go2_basic_motion_harvest.py) decides every verdict.

DOWNLOAD
  /workspace/_keep/GO2_G_A033_CAMPAIGN_RESULT.zip
  /workspace/_keep/GO2_G_A033_CAMPAIGN_RESULT.zip.sha256
  Finish marker: [DONE] GO2_G_A033_CAMPAIGN_RESULT_READY
  Official results remain OFFICIAL_RESULT_UNMEASURED.
