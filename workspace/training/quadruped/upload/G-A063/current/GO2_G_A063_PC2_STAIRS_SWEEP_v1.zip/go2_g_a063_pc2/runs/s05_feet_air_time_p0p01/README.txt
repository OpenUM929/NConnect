G-A063 PC2 batch point s05_feet_air_time_p0p01: 부모 P0 위 feet_air_time 0.2 -> 0.01. 배포 범위 최소·배포 시작값. '↓ 발을 거의 안 들고 끌듯이'.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
