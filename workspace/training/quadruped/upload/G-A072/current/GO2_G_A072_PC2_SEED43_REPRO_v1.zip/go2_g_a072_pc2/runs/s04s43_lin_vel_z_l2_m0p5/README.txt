G-A072 PC2 batch point s04s43_lin_vel_z_l2_m0p5: 부모 P0 위 lin_vel_z_l2 -1.25 -> -0.5. s04 seed 42: 15cm ≥2단 3→23·10cm 낙상 44→2, 험지 옆걸음 낙상 41→63·밀침 0→40. 탐색 기준 ≥12 이고 >3(§64-2·§65). Claude 예측 ≥12.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
