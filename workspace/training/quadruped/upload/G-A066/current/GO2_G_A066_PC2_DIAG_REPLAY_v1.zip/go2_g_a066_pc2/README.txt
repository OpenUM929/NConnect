GO2 G-A066 PC2 진단 재생 — 학습 없음 · 보상 변경 없음 · 정책 5개 × 12회 (설계 workspace/training/quadruped/upload/plan/GO2_G_A063_SWEEP_CODEX_CONSULT_20261006.md §25·§26)
==================================================
정책(실행 순서, 모두 PC2 학습 iter 900):
   1. p0   P0 = PC2 A048 보상(track 1.5)
   2. s04  P0 + lin_vel_z_l2 -1.25->-0.5
   3. s11  P0 + ang_vel_xy_l2 -0.05->-0.02
   4. s13  P0 + action_rate_l2 -0.01->-0.005
   5. s07  P0 + feet_air_time 0.2->0.35 (G-A064 부모)
정책마다 stairs_15_down·rough_lateral × 평가 seed 202·101·303 × plain·diag(읽기 전용 진단 채널). 영상 없음.
시간 [추정]: 서버 실측 회당 21~33초 → 60회 약 30~40분 + 초기화. PC2 실측 없음.

1. 올리기: GO2_G_A066_PC2_DIAG_REPLAY_v1.zip  SHA256 (발행 시 기록)  → /workspace/GO2_G_A066_PC2_DIAG_REPLAY_v1.zip
2. 환경 변수: G-A063 인계 §2 의 mount·export 줄을 먼저 실행한다.
3. 실행(한 줄): unzip -oq /workspace/GO2_G_A066_PC2_DIAG_REPLAY_v1.zip -d /workspace && bash /workspace/go2_g_a066_pc2/run_all.sh
   진행: /workspace/_keep/go2_g_a066_pc2_points/BATCH_RUN.log
4. 실패: 러너가 멈추면 run_all 도 멈춘다. 고친 뒤 같은 한 줄(끝난 정책은 SKIP_DONE).
5. 회수: 정책마다 /workspace/_keep/go2_g_a066_pc2_<key>/ 와 GO2_G_A066_PC2_<KEY>_RESULT.zip + .sha256,
   그리고 /workspace/_keep/go2_g_a066_pc2_points/ → 저장소 workspace/_keep/ (100MB 초과는 95MB parts).
