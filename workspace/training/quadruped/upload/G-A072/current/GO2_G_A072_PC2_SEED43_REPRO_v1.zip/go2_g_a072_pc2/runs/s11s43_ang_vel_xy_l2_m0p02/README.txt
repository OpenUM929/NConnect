G-A072 PC2 batch point s11s43_ang_vel_xy_l2_m0p02: 부모 P0 위 ang_vel_xy_l2 -0.05 -> -0.02. s11 seed 42: 15cm ≥2단 3→13·밀침 2. 탐색 기준 ≥7. Claude 예측 <7(같은 항 c6가 seed 의존을 보임).
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
