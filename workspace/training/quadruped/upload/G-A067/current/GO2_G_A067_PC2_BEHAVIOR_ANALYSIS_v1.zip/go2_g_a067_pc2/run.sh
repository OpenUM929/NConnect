#!/usr/bin/env bash
# G-A067 PC2 행동 판독 — 읽기 전용, GPU 없음. 저장소 루트에서 실행한다: bash /workspace/go2_g_a067_pc2/run.sh <저장소 루트>
set -euo pipefail
REPO=${1:?usage: run.sh <repo root>}
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
cd "$REPO"
for p in p0 s04 s07 s11 s13; do for s in 101 202 303; do for c in stairs_15_down rough_lateral; do
  d=workspace/_keep/go2_g_a066_pc2_$p/diag/cases/seed_$s/$c
  [[ -s $d/steps.csv && -s $d/diag.csv.gz ]] || { echo "[FAIL] missing input $d"; exit 2; }
done; done; done
OUT=workspace/_keep/go2_g_a067_analysis
mkdir -p "$OUT"
export PYTHONIOENCODING=utf-8 PYTHONUTF8=1
nice -n 10 python -B "$HERE/go2_g_a067_behavior_analysis.py" --keep workspace/_keep --out "$OUT" 2>&1 | tee "$OUT/RUN.log"
grep -qx 'G_A067_ANALYSIS=COMPLETE' "$OUT/STATUS.txt" && echo "[DONE] G-A067 $OUT"
