GO2 TUNING ENGINE V1.1 — fixed engine + validated experiment JSON

HOTFIX
- v1.0 used bare python3 during preflight. The server image has no python3 command.
- v1.1 routes validation/materialization through /workspace/IsaacLab/isaaclab.sh -p.
- v1.0 SHA 4489bef4...8a5a is BUGGY_DO_NOT_REUSE and never started training.

PURPOSE
- The engine ZIP contains runner/evaluator/reporter/source template and Default-01 baseline evidence.
- It does not contain a G-A010-specific experiment. Reward/seed/iteration/gates/output names come from JSON.
- The runtime validator rejects anything other than one reward change against the frozen Default-01 baseline.

G-A010 UPLOADS
1. /workspace/go2_tuning_engine_v1_1.zip
2. /workspace/G_A010_lin_vel_z_m2.json

ONE-LINE RUN
cd /workspace && unzip -oq go2_tuning_engine_v1_1.zip && cd /workspace/go2_tuning_engine_v1_1 && bash server_run_go2_tuning_engine_v1.sh /workspace/G_A010_lin_vel_z_m2.json

MONITOR
tmux attach -t go2_g_a010

DONE MARKER
[DONE] GO2_LIN_VEL_Z_M2_RESULT_READY

DOWNLOAD BOTH
/workspace/_keep/GO2_LIN_VEL_Z_M2_RESULT.zip
/workspace/_keep/GO2_LIN_VEL_Z_M2_RESULT.zip.sha256

RESULT CONTRACT
- FULL or PARTIAL result status
- engine version, engine archive SHA when the uploaded ZIP remains at the canonical path
- experiment JSON, experiment SHA, schema
- training checkpoint/env/log/tfevents/params/source/reward diff
- candidate tier-1 telemetry, repaired baseline telemetry, conditional representative telemetry
- G1 forward-fast seed-101 video
- exported policy and actor-tensor lineage
- a single result ZIP plus SHA companion

LIMITS
- INTERNAL_* results are internal gates, not official results.
- One training seed is exploratory and cannot establish optimality or official qualification.
- Do not run two 4096-env trainings concurrently on the confirmed single RTX 5080.
