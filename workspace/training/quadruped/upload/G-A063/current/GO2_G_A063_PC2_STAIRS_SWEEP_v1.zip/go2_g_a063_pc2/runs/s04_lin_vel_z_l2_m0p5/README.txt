G-A063 PC2 batch point s04_lin_vel_z_l2_m0p5: 부모 P0 위 lin_vel_z_l2 -1.25 -> -0.5. 배포 범위 최약. 배포 ③ '약하게: 통통 튀며 역동 (착지 불안정)'.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
