GO2 G-A050 REWARD CHANGE ON G-A033 — lin_vel_z_l2 -2.0 -> -1.375
================================================================

This package TRAINS one policy and then measures it.  status: exploratory.
One upload, one command, one result ZIP: the whole 69-case evaluation runs in a single
pass (run_config.env pins GO2_STAGE=full), so there is no target stage and no server gate.
  unzip -oq <this zip> -d /workspace
  bash /workspace/go2_g_a050/server_run_go2_candidate_iter_pinned.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_g_a050/server_run_go2_candidate_iter_pinned.sh

WHAT CHANGES
  Exactly one reward weight: lin_vel_z_l2 -2.0 -> -1.375.
  candidate/quadruped_rewards.py and reference/baseline_quadruped_rewards.py differ in that line only.
  Training length, seed, env count and every other weight are G-A033's.

WHY (analysis GO2_G3_FIRST_20260927.md)
  Purpose: raise G3 (rough terrain), where about 5 of the remaining points sit, and keep the stairs, push, flat axes and G2. Not a promise of a higher score.
  Role first (Isaac Lab formula): lin_vel_z_l2 pays -w * v_z^2 in the body frame, with no direction term, so the rise a tread requires is charged at the same rate as the bounce a bad landing produces. That is the mechanism this arm moves, and it is a property of the formula.
  What is measured: at -2.0 / -1.75 / -1.5 / -1.25 / -1.0 the total was 42.53 / 38.89 / 44.62 / 50.16 / 46.20, rough side-step posture falls 59 / 80 / 24 / 16 / 46, G3 4.23 / 1.41 / 7.41 / 8.98 / 4.59 and combined_yaw_right falls 0 / 0 / 29 / 0 / 0. Every counter is non-monotone.
  Why -1.375: the midpoint of the only two values that raised G3 (-1.5, -1.25); both kept the stairs inside the protection limits. A044 shows a midpoint can be worse than both ends.
  Two verdicts, fixed before the run: adoption under fact_rules_v1 plus g3_guard_margin_v1 (stairs protected, not required to improve) and the hypothesis indicators (rough side-step falls <= 41 supported / >= 59 not; combined_yaw_right falls at >= 2 seeds = cost present). Neither verdict rescues the other.
  Collection is G-A049's: all 69 cases in one pass, both combined-turn directions and all four push directions filmed on the candidate, every baseline counterpart reused by SHA.

HOW THE VALUE WAS CHOSEN
  source: workspace/training/quadruped/upload/plan/GO2_G3_FIRST_20260927.md sections 1-2; reports/evidence/go2_axis_bottleneck_four_arms_20260927/AXIS_BOTTLENECK_FOUR_ARMS.csv; reports/evidence/go2_g_a048_readout_20260926/DIAL_FOUR_POINTS.csv; reports/evidence/go2_g_a048_readout_20260926/MONOTONICITY_FOUR.csv; workspace/server_returns/G-A049_REVIEW_20260927/harvest_verification.json; reports/evidence/go2_reward_mechanism_20260917/PROBES.csv.
  role: Penalize z-axis base linear velocity using an L2 squared kernel (Isaac Lab v2.3.1, reports/evidence/go2_reward_term_roles_20260917/isaaclab_envs_mdp_rewards.py: torch.square(asset.data.root_lin_vel_b[:, 2])). It is the body frame's vertical speed squared - not foot height, not world-frame altitude, not ground clearance. On a slope the body frame tilts with the robot, so the same climb charges differently there than on flat ground.
  walk_margin: G-A033 walk margin +0.1359 -> +0.151 at -1.375 (go2_reward_mechanism.spec_margin over reports/evidence/go2_reward_mechanism_20260917/, zone WALK, range_status BETWEEN_OBSERVED). The stop zone's top is +0.0155. A margin is reward arithmetic over measured postures and is not a ranking basis (reports/GO2_REWARD_MECHANISM_FORECAST.md section 8).
  situations: spec_margin situations at -1.375: climb +0.0322, sway -0.0587, push -0.0482. At -1.25 the same arithmetic predicted losses on sway and all four push directions and every one came out a gain (reports/evidence/go2_g_a048_readout_20260926/FORECAST_CHECK.csv). The cells are carried as a record, not as a prediction this arm relies on.
  rule: -1.375 is the midpoint of the two measured values that raised G3 on this baseline (-1.5 and -1.25). The midpoint is an operational search position between two observations with different weaknesses (G2 combined right turn at -1.5, none at -1.25); it is not proven better than -1.4 or -1.35.
  not_claimed: No score gain is estimated. A044 (-1.75), the midpoint of -2.0 and -1.5, was worse than both ends on every fall counter, so a midpoint does not inherit its neighbours' performance. One training seed cannot separate the value's effect from a different training path. The G3 target is chosen from the scoring arithmetic, not from a prediction that this value raises G3 further than G-A048.

LEVERS NOT MOVED
  track_lin_vel_xy_exp: held at 1.5: G-A042 raised it to 1.6 and the 10 cm two-or-more count went 43 -> 0 of 96 with posture falls 34 -> 85 (reports/GO2_G_A042_READOUT.md). The local extension of that dial is measured and closed.
  ang_vel_xy_l2: strengthening to -0.08 (G-A038) cut rough side-step falls to 18/96, but both -0.08 and the relaxation -0.04 (G-A041) collapsed the 10 cm climb (posture falls 96 and 93 of 96, limit 34 + 6). A value between -0.05 and -0.08 would bet G3 against a near-certain stairs protection failure.
  feet_air_time: held at 0.2: 0.01 and 0.1 were both rejected at stage 1 (A031, A032) and 0.35 stopped the policy (A015). It is air time, not foot height, so it does not address the tread.
  flat_orientation_l2: -0.5 (G-A047) left rough side-step falls at 60/96 and lost 6.89/70; there is no direct G3 evidence for a smaller value.
  action_rate_l2: -0.008 is a valid rejection (A018) and reports/evidence/go2_reward_mechanism_20260917/PROBE_SITUATIONS.csv leaves climb, sway and push empty for this term, so no situation direction can be read for it.
  dof_acc_l2: G-A039 is on hold and sits outside the deployed six, which makes it dependent on open decision U1-R6-ENV-REWARD-20260918. The 2026-09-26 policy revision also withdrew its old priority.
  max_iterations: outside R-6 (not a reward weight). See notes.curriculum_lag.
  training_seed: outside R-6 until U2 is answered. The seed replicate of G-A048 is the other G3 question and is published only after U2 is permitted, under the unused number of that time.
  track_ang_vel_z_exp: computed and set aside in the 2026-09-26 candidate comparison (workspace/training/quadruped/upload/plan/GO2_POST_A047_POLICY_20260926.md): no direct evidence on the stairs or rough behaviour, and it is not one of the six deployed names.
  lin_vel_z_l2_measured_values: -1.75, -1.5, -1.25 and -1.0 are measured on seed 42 (G-A044, G-A043, G-A048, G-A049). Re-training the same value on seed 42 is deterministic (reports/GO2_G_A038_READOUT.md section 4) and would only re-judge G-A048 under a rule chosen after its result; another seed waits on U2.
  lin_vel_z_l2_to_m1125: between -1.25 and -1.0, but -1.0 collapsed G3 (4.59) and its 15 cm posture falls (96) were outside the g3_guard_margin_v1 limit (90 + 3).

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  No gain estimate exists and one training seed cannot
  separate the lever from seed luck.
  Pre-registered: all other axes held -- per-scenario weighted loss at most twice its own
  evaluation sd (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358), flat G1/G2 guards unchanged.

CHECKPOINT
  Evaluated at iter 900 of 1000, the iteration G-A033 was evaluated at.

VIDEOS (4 env x 500 steps)
  G2:combined_yaw_left:101   the mirror of the case that broke G-A043. Filmed so a recurrence is not read from one direction alone.
  G2:combined_yaw_right:101  the hypothesis cost indicator. G-A043 (-1.5) lost 29 of 96 robots here; G-A048 (-1.25) and G-A049 (-1.0) lost none. Filmed on the candidate.
  G3:rough_forward:101       the rough axis the arm must hold. Stored G-A033 video, reused by SHA.
  G3:rough_lateral:101       the target: rough side-step posture falls 59 / 80 / 24 / 16 / 46 across the five measured values. Baseline reused by SHA.
  G5:stairs_10_down:101      the adoption target the climbed-robot counter and the plan screening read. Baseline reused by SHA.
  G5:stairs_15_down:101      stairs protection case (15 cm climb): posture falls 90 at baseline, limit 93 under g3_guard_margin_v1. Baseline reused by SHA.
  G6:push_pos_x:101          the push direction the fact_rules group scores. Baseline reused by SHA.
  G6:push_neg_x:101          push protection block direction. Baseline reused by SHA.
  G6:push_pos_y:101          push protection block direction. Baseline reused by SHA from the G-A044 run.
  G6:push_neg_y:101          push protection block direction. Baseline reused by SHA from the G-A044 run.

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
