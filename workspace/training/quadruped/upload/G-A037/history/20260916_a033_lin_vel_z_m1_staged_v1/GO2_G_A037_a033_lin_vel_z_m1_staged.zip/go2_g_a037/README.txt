GO2 G-A037 REWARD CHANGE ON G-A033 — lin_vel_z_l2 -2.0 -> -1.0
==============================================================

This package TRAINS one policy and then measures it.  status: exploratory.
It is one arm of a campaign; do not run it on its own (see the campaign guide).

WHAT CHANGES
  Exactly one reward weight: lin_vel_z_l2 -2.0 -> -1.0.
  candidate/quadruped_rewards.py and reference/baseline_quadruped_rewards.py differ in that line only.
  Training length, seed, env count and every other weight are G-A033's.

WHY (analysis GO2_STAIRS_BEHAVIOR_ANALYSIS_20260916.md)
  Goal: climb stairs while every other axis stays high (analysis 8-3b). G-A033 loses 10.46/70 on G5 and 9.77/70 on G3.
  G5: no policy has climbed two 15cm steps. Robots walk to the first riser and stop level (analysis 2-3).
  Stopping keeps about 47% of the flat-walking reward rate (CLIMB_REWARD.csv).
  On a 10cm climb G-A033 pays back 34% of the tracking gain as lin_vel_z_l2; at 15cm this is estimated at 76%.
  Walking itself started only when lin_vel_z and ang_vel_xy were relaxed together to the Isaac Lab values (analysis 8-1b).
  G3: rough_lateral ends in sideways roll-over, and ang_vel_xy is the roll-rate penalty, so it stays at -0.05 (analysis 9).
  track stays at 1.5: roll-over terminations rose 31 -> 48 -> 58 over the two track steps.
  An earlier note (MASTER line on slope stalls) excluded lin_vel_z by comparing its whole-episode size with the stall loss.
  This run uses a different quantity: the share of the climb's own tracking gain, measured per robot.
  Risks pre-registered: body bounce on flat ground (G1/G2 guards), push recovery (G6 limit 0.86196/70), roll-over on rough side-steps (G3 limit and target group).

HOW THE VALUE WAS CHOSEN
  source: reports/evidence/go2_stairs_behavior_20260916/CLIMB_REWARD.csv (G-A033 rows), analysis section 8-2
  measured_10cm_share: (0.124-0.021)/(0.985-0.679) = 34% of the climb's tracking gain is paid back as lin_vel_z_l2
  estimated_15cm_share: vz scales with step height at the same forward speed, so the penalty scales with (15/10)^2 = 2.25: 0.103*2.25/0.306 = 76%
  rule: choose the weight that brings the 15cm share back to the share G-A033 already climbs 10cm stairs with: 76% * (w/2) ~= 34%  ->  w ~= 0.9, rounded to 1.0 (share 38%)
  not_claimed: The share is a reward-arithmetic quantity on two measurable terms. It does not predict how many robots will climb. ang_vel_xy, joint penalties and termination risk are not in the measurement.

LEVERS NOT MOVED
  ang_vel_xy_l2: not relaxed: it penalises roll as well as pitch, and the G3 min-case rough_lateral ends in sideways roll-over (analysis section 9, LATERAL_BEHAVIOR.csv tilt cos -0.973)
  track_lin_vel_xy_exp: held: rough_lateral terminations rose at both track steps, 31 -> 48 -> 58 (analysis 9-1)
  feet_air_time: held at 0.2: lowering it cut slope progress on the A017 base (A031), raising it collapsed Pilot (A015) (analysis 8-1b)
  penalty_strengthening: no strengthened penalty on a walking base has walked (analysis 8-1b)

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  No gain estimate exists and one training seed cannot
  separate the lever from seed luck.
  Pre-registered: all other axes held -- per-scenario weighted loss at most twice its own
  evaluation sd (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358), flat G1/G2 guards unchanged.

CHECKPOINT
  Evaluated at iter 900 of 1000, the iteration G-A033 was evaluated at.

VIDEOS (4 env x 500 steps)
  G5:stairs_15_down:101      the 15cm climb: does the robot step onto the first riser instead of stopping level in front of it (analysis 2-3). No stored G-A033 video, so the baseline is rendered here.
  G3:rough_lateral:101       the roll-over: a looser vertical penalty must not add sideways flips. No stored G-A033 video, so the baseline is rendered here.
  G4:slope_plus_20:101       G-A033 climbs the slope to the end; guard against losing it
  G1:forward_fast:101        flat gait at the fastest command: a looser vertical penalty may add body bounce

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
