GO2 G-A038 REWARD CHANGE ON G-A033 — ang_vel_xy_l2 -0.05 -> -0.08
=================================================================

This package TRAINS one policy and then measures it.  status: exploratory.
It is one arm of a campaign; do not run it on its own (see the campaign guide).

WHAT CHANGES
  Exactly one reward weight: ang_vel_xy_l2 -0.05 -> -0.08.
  candidate/quadruped_rewards.py and reference/baseline_quadruped_rewards.py differ in that line only.
  Training length, seed, env count and every other weight are G-A033's.

WHY (analysis GO2_REWARD_MECHANISM_FORECAST.md)
  Goal: every axis high while stairs rise. G-A033 loses most on G5 (stairs) and G3 (rough side-step); G6 (push) also loses.
  Role first (Isaac Lab formula): ang_vel_xy_l2 penalises the rate of rolling and pitching.
  Measured on G-A033 trajectories: robots about to fall on a rough side-step or after a push roll and pitch far faster than survivors.
  That direction agrees on Pilot-01, A017 and G-A033 for the side-step, and on A017 and G-A033 for pushes (forecast 5-1).
  Walk margin: -0.08 stays in the walking zone on G-A033. A016 (-0.15) stopped from a Pilot-01 base that sat in the boundary band.
  Cost named in advance: the stairs partial margin falls a little, so the 10cm climb is a target group.
  Levers not moved: track (side-step terminations rose at 1.5), flat_orientation (sign disagrees), lin_vel_z (costs walk/stairs), feet_air, dof_acc.
  Risks pre-registered: stopping (walk zone), 10cm climb, slope, and every scenario loss limit of G-A037.

HOW THE VALUE WAS CHOSEN
  source: reports/GO2_REWARD_MECHANISM_FORECAST.md sections 2, 3, 5-1 and 6-0; evidence reports/evidence/go2_reward_mechanism_20260917/ (RUN_MARGIN.csv, SITUATIONS.csv, PROBE_SITUATIONS.csv)
  role: Penalize xy-axis base angular velocity using L2 squared kernel (Isaac Lab v2.3.1): the rate of rolling and pitching, not the tilt itself.
  walk_margin: G-A033 walk margin +0.1359 -> +0.0728 at -0.08 (WALK); the walking zone ends at weight -0.107243. A016 (-0.15 on Pilot-01) stopped because Pilot-01 sat in the boundary band (+0.0033); on G-A033 -0.15 is also predicted STOP, -0.08 is not.
  situations: partial margin change vs G-A033: side-step sway +0.3230 (the pre-fall state is penalised more on all 3 policies), push +0.1535 (more on both policies with >= 5 fallen robots), stairs climb -0.0107 (roll/pitch-rate lower bound, so the stairs cost may be larger).
  rule: a step that keeps the walk margin (+0.0728) above every stopped run (max +0.0155) and close to the walking run A017 (+0.0917); -0.08 is the deployed start value; the runs that carried it all stopped, but every one also had lin_vel_z -3 or track <= 1.2 and sits in the stop zone of the same margin (forecast section 2). No value between -0.05 and -0.08 has been trained
  not_claimed: The margins are reward arithmetic on measured behaviour (G-A033 trajectories and training logs). They say the reward prefers upright states more strongly; they do not predict how many robots stop falling. No score gain is estimated.

LEVERS NOT MOVED
  lin_vel_z_l2: strengthening also raises sway/push margins but lowers walk and stairs margins (forecast 6-0); weakening (G-A037) lowers sway and push
  flat_orientation_l2: second choice: its side-step sign disagrees across the three policies (forecast 5-1) and it charges every slope and stair constantly
  track_lin_vel_xy_exp: held at 1.5: rough side-step terminations rose on the grade-A pair 1.4 -> 1.5 (per-seed mean 19.333 of 32 robots on G-A033)
  feet_air_time: held at 0.2: lowering it cut slope progress (A031, grade A); raising it lowers the walk margin
  dof_acc_l2: the G5 lever of the forecast; no situation measurement exists for it, so it is a separate information run, not mixed into this one

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  No gain estimate exists and one training seed cannot
  separate the lever from seed luck.
  Pre-registered: all other axes held -- per-scenario weighted loss at most twice its own
  evaluation sd (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358), flat G1/G2 guards unchanged.

CHECKPOINT
  Evaluated at iter 900 of 1000, the iteration G-A033 was evaluated at.

VIDEOS (4 env x 500 steps)
  G3:rough_lateral:101       the side-step roll-over this lever aims at. No stored G-A033 video, so the baseline is rendered here.
  G6:push_pos_x:101          recovery after a forward push. No stored G-A033 video, so the baseline is rendered here.
  G3:rough_forward:101       rough forward walking: a stronger roll/pitch-rate penalty may slow or stiffen the gait on uneven ground
  G4:slope_plus_20:101       G-A033 climbs the slope to the end; guard against losing it

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
