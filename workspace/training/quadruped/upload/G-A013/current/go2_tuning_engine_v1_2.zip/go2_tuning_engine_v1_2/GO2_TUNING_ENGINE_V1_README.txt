GO2 TUNING ENGINE V1.2 — fixed engine + validated experiment JSON

WHAT CHANGED IN V1.2 (engine_version 1.1.0)
- flat_orientation_l2 is now a tunable reward key (default 0.0 = IsaacLab Go2 rough stock).
  Reason: G-A012 measured that the Go2 env has undesired_contacts = null and no
  termination_penalty term at all, so the two "advanced" survival dials named in the
  campaign plan do not exist. flat_orientation_l2 is the only untouched posture dial
  that is actually defined, and G-A012 showed survival — not tracking — is where the
  simulation points are lost (G3 12.97/70, G5 10.50/70 weighted loss).
- evaluation.gates.target_scenario may now be any of G1..G7 (was pinned to G1).
  Reason: G-A010 improved the weighted total by +2.26/70 and G3 survival by +0.094,
  yet was early-killed solely because the gate target was pinned to G1. The gate must
  point at the scenario the pre-registered rule selects.
- Engine archive renamed to go2_tuning_engine_v1_2.zip so a stale v1_1 upload cannot
  be used by mistake. go2_tuning_engine_v1_1.zip is SUPERSEDED_DO_NOT_REUSE; it
  rejects a 1.1.0 experiment at validate time, and v1.2 rejects a 1.0.1 experiment.

PURPOSE
- The engine ZIP contains runner/evaluator/reporter/source template and Default-01 baseline evidence.
- It contains no experiment. Reward/seed/iteration/gates/output names come from the JSON.
- The runtime validator rejects anything other than one reward change against the frozen Default-01 baseline.

G-A013 UPLOADS
1. /workspace/go2_tuning_engine_v1_2.zip
2. /workspace/G_A013_flat_orientation_m1.json

G-A013 IDENTITY
- single change: flat_orientation_l2  0.0 -> -1.0   (all five other weights stay at Default-01)
- training: from scratch, seed 42, 4096 envs, 1000 iterations
- tier-1 gate target: G3 (rough_forward), required proxy delta >= +0.05
- experiment SHA-256: 2e255c1e18165f2be7e17f09893503262a1c846998d12f20cb7ddbd9273cecb2
  (this README ships inside the engine ZIP, so the engine's own SHA is recorded in
   go2_tuning_engine_v1_2.VERIFICATION.md and SERVER_SESSION_RUNBOOK.md, not here)

ONE-LINE RUN
cd /workspace && unzip -oq go2_tuning_engine_v1_2.zip && cd /workspace/go2_tuning_engine_v1_2 && bash server_run_go2_tuning_engine_v1.sh /workspace/G_A013_flat_orientation_m1.json

MONITOR
tmux attach -t go2_g_a013

DONE MARKER
[DONE] GO2_FLAT_ORIENTATION_M1_RESULT_READY

DOWNLOAD BOTH
/workspace/_keep/GO2_FLAT_ORIENTATION_M1_RESULT.zip
/workspace/_keep/GO2_FLAT_ORIENTATION_M1_RESULT.zip.sha256

RESULT CONTRACT
- FULL or PARTIAL result status
- engine version, engine archive SHA when the uploaded ZIP remains at the canonical path
- experiment JSON, experiment SHA, schema
- training checkpoint/env/log/tfevents/params/source/reward diff
- candidate tier-1 telemetry, repaired baseline telemetry, conditional representative telemetry
- G1 forward-fast seed-101 video
- exported policy and actor-tensor lineage
- a single result ZIP plus SHA companion

LIMITS
- INTERNAL_* results are internal gates, not official results.
- One training seed is exploratory and cannot establish optimality or official qualification.
- Do not run two 4096-env trainings concurrently on the confirmed single RTX 5080.
- config/experiments/G_A010_lin_vel_z_m2.json is pinned to engine_version 1.0.1 and no
  longer validates against this engine. It is kept as a record of a completed run.
