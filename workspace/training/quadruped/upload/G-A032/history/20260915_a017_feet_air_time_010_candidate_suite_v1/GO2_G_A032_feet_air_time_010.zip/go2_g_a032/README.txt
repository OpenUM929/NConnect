GO2 G-A032 CANDIDATE SUITE — A017 + feet_air_time 0.2 -> 0.1
============================================================

This package TRAINS one policy and then measures it.  status: exploratory.
It is one arm of a dose pair (G-A032 0.1, G-A031 0.01).

WHAT CHANGES
  The baseline is A017 (Pilot-01 + track_lin_vel_xy_exp 1.4), 39.76/70 on the
  69-case internal proxy (G-A027).  The candidate changes one reward only:
  feet_air_time 0.2 -> 0.1.  Deployed train/play/task code is unchanged
  (R-6); only candidate/quadruped_rewards.py carries the new value.

WHY (plan GO2_BASIC_MOTION_TUNING_PLAN_20260915.md)
  A017 walks well on flat ground (G1/G2 survival 1.0, tracking >= .89) but on rough,
  slope and DR it moves at about half the commanded speed (speed/command .49-.60 rough,
  .53-.57 slope) and loses robots to the height gate, not to tilt (slope 7/8/4, rough 2/1/0).
  feet_air_time 0.2 is A017's only term without single-variable evidence and 20x the
  Isaac Lab Go2 rough value 0.01 (Isaac Lab uses 0.25 only in the flat config).
  Raising it to 0.35 (A015) lowered body height in all 7 cases and collapsed survival.
  This arm tests the midpoint 0.1; G-A031 tests the Isaac Lab value 0.01.

PHASES
  1  training, seed 42, 4096 envs, 1000 iter; report.html kept
  2  catastrophe gate: non-finite training loss, or a stationary candidate on
     G1:forward_nominal:101, stops the run here (one witness video)
  3  candidate 69-case suite, seeds 101/202/303, posture_gate_v2
  4  baseline: 5 sentinel cases re-measured against the stored G-A027 arm, or
     all 69 with GO2_REMEASURE_BASELINE=1
  5  12 candidate videos + 2 baseline videos
  6  one-file result ZIP

RUN (PACKAGE_ROOT must be given: the runner's default is the G-A030 folder)
  unzip GO2_G_A032_feet_air_time_010.zip -d /workspace
  PACKAGE_ROOT=/workspace/go2_g_a032 bash /workspace/go2_g_a032/server_run_go2_candidate_suite.sh
  Finish marker: [DONE] GO2_G_A032_RESULT_READY

DOWNLOAD
  /workspace/_keep/GO2_G_A032_RESULT.zip
  /workspace/_keep/GO2_G_A032_RESULT.zip.sha256

PRE-REGISTERED READING (plan section 6-1, fixed before the run)
  success needs all of:
   1 basic motion off flat ground: the mean case proxy (survival x tracking) over
     rough_forward, slope_plus_20 and the three DR cases (9 case-seeds) rises by
     >= 0.05, and at least 2 of the 3 groups improve
   2 total internal proxy delta >= 0.0/70, same evaluator
   3 flat ground holds: G1/G2 scenario proxy drop <= 0.02, no G1/G2 case loses
     more than 0.03125 survival; no other scenario loses more than
     0.5/70 weighted
   4 POLICY_LOCOMOTES and no new stationary case outside the stairs (G5)
   5 videos show normal four-legged walking with the feet lifted (human reading)
  Height and posture-gate falls on the target cases are read as the mechanism,
  not as a criterion.  The expected weighted gain is NOT estimated.
  Official results remain OFFICIAL_RESULT_UNMEASURED.
