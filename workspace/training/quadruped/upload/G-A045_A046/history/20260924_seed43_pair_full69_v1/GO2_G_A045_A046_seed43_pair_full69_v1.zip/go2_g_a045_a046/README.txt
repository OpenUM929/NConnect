GO2 G-A045 + G-A046 SEED PAIR — one upload, one command, one result
===================================================================

This package TRAINS TWO policies, one after the other on one GPU, and measures each over
all 69 cases.  status: exploratory.  Plan: GO2_A045_SEED_PAIR_PLAN_20260924.md.

WHAT IT MEASURES
  Both arms train at seed 43, a seed this project has never used - every one of its
  eighteen trainings ran at seed 42.
    G-A045 carries G-A033's reward file unchanged, so its distance from the stored
          G-A033 record is one sample of TRAINING PATH VARIANCE.
    G-A046 carries lin_vel_z_l2 -1.5, the value G-A043 measured at seed 42, so its
          distance from G-A045 is the DIAL'S EFFECT on a second path.
  The two comparisons are symmetric with G-A033 <-> G-A043 at seed 42, which is what
  makes "did the effect reproduce?" answerable.

NEITHER ARM MAY BE PROMOTED
  promotion: forbidden_not_a_reward_change (both arms).
  A training seed is not a reward weight.  Whatever these arms score, the frozen baseline
  stays G-A033 and no policy from this campaign becomes a submission candidate.
  Open reading: U2-SEED-REPLICATE-20260918 - the user's to close.

ARMS (byte for byte what tools/build_go2_seed_pair_package.py builds)
  G-A045  ruler        lin_vel_z_l2 -2.0  seed 43   arms/GO2_G_A045_seed43_a033_rewards_full69_v1.zip
           sha256 6b4eeb6e88b57fff7c57105466a2f9823624b8bc3be3745547b1b85e5934b1a4
  G-A046  replication  lin_vel_z_l2 -1.5  seed 43   arms/GO2_G_A046_seed43_lin_vel_z_m15_full69_v1.zip
           sha256 b5f09348051823028943d7b177c9d0dd711fb6da0ef704a9149907dd3adde453

RUN
  unzip -oq GO2_G_A045_A046_seed43_pair_full69_v1.zip -d /workspace
  bash /workspace/go2_g_a045_a046/server_run_go2_full69_campaign.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_g_a045_a046/server_run_go2_full69_campaign.sh

WHAT HAPPENS
  1 G-A045 full stage (~95m): training 1000 iter, catastrophe gate, all 69 cases,
    the sentinel, 6 candidate videos and 4 baseline videos, its result ZIP.
  2 G-A046 full stage (~95m): the same, with 6 candidate videos and no baseline
    videos - its counterparts were filmed in step 1 from the same stored policy.
  3 one result ZIP holding both arm result ZIPs and CAMPAIGN_STATUS.txt.
  There is no target gate and no arm gates the other: a failed arm is packaged with what
  it collected and the next arm runs.  Every verdict is read locally after recovery.

DOWNLOAD
  /workspace/_keep/GO2_SEED_PAIR_RESULT.zip
  /workspace/_keep/GO2_SEED_PAIR_RESULT.zip.sha256
  Finish marker: [DONE] GO2_SEED_PAIR_RESULT_READY  (it is NOT printed on the crash path - see the guide)
  Official results remain OFFICIAL_RESULT_UNMEASURED.
