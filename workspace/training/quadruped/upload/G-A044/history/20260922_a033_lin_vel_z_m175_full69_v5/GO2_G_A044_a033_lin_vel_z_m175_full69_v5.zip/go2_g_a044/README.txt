GO2 G-A044 REWARD CHANGE ON G-A033 — lin_vel_z_l2 -2.0 -> -1.75
===============================================================

This package TRAINS one policy and then measures it.  status: exploratory.
One upload, one command, one result ZIP: the whole 69-case evaluation runs in a single
pass (run_config.env pins GO2_STAGE=full), so there is no target stage and no server gate.
  unzip -oq <this zip> -d /workspace
  bash /workspace/go2_g_a044/server_run_go2_candidate_iter_pinned.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_g_a044/server_run_go2_candidate_iter_pinned.sh

WHAT CHANGES
  Exactly one reward weight: lin_vel_z_l2 -2.0 -> -1.75.
  candidate/quadruped_rewards.py and reference/baseline_quadruped_rewards.py differ in that line only.
  Training length, seed, env count and every other weight are G-A033's.

WHY (analysis GO2_POST_A043_PLAN_20260922.md)
  The plan's goal, in its own words: find out whether a smaller relaxation keeps the stair progression G-A043 found while giving back the flat combined-turn survival it lost. Not a promise that it will.
  Role first (Isaac Lab formula): lin_vel_z_l2 pays -w * v_z^2 in the body frame, with no direction term, so the rise a tread requires is charged at the same rate as the bounce a bad landing produces. That is the mechanism this arm moves, and it is a property of the formula.
  What is measured, not argued: G-A043 (-1.5) took the 15 cm two-or-more count from 0 to 77 of 96 and the 10 cm count from 43 to 94, and lost 4.63693/70 on G2 through combined_yaw_right alone (survival 1.0 -> 0.71875/0.71875/0.65625). Outside G2 it gained 6.73286/70. The total, +2.09593, is the difference of those two movements and hides both.
  Why an interpolation and not another dial: this is the only dial with two measured walking values on the frozen baseline, so -1.75 is the one candidate in the project whose range_status is BETWEEN_OBSERVED rather than OUT_OF_RANGE. Every other lever would start over from an unmeasured point.
  Named in advance: a midpoint in the weight is not a midpoint in the score. The plan pre-registers the linear -half outcome (B 3.367, L 2.318, net +1.048) and states that it fails c2 by 1.482 AND exceeds the c3 flat cap by 1.751 - both gates, not one. If the result lands there, the chain is refuted rather than 'nearly passed'.
  The forecast sheet is carried as a limit, not as support: at -1.75 it reads walk +0.0060, climb +0.0129, sway -0.0235, push -0.0193, and G-A043 is the measured test of exactly that sheet at twice the size. It got sway and push backwards - both were predicted down and both went up - and it has no cell at all for the flat combined turn that actually decided the run.
  Collection is the other half of this arm. G-A043's decisive case sat outside stage 1, outside the screening edition and outside the video set, so the loss was invisible until the full suite ran and its shape is still VIDEO_UNKNOWN. This run measures all 69 cases in one pass, films both combined-turn directions and all four push directions on both arms, and widens the push protection block to four directions. No threshold moves.
  Risks pre-registered under fact_rules_v1 plus post_a043_push4_v1: the rough and push group floors, the per-scenario loss limits (G3 2.03646, G6 0.86196), the flat guards including the per-case survival drop of 0.0625 that caught G-A043, the stationary guard, the climbed-robot floors as the reverse guard, and all four G6 directions as a paired-seed protection block.

HOW THE VALUE WAS CHOSEN
  source: workspace/training/quadruped/upload/plan/GO2_POST_A043_PLAN_20260922.md sections 1-4 and 9; reports/GO2_G_A043_READOUT.md; evidence reports/evidence/go2_a043_scenario_split_20260922/SCENARIO_SPLIT.csv and CASE_DELTAS.csv; reports/evidence/go2_stairs_behavior_20260916/STAIRS_CLIMB.csv; reports/evidence/go2_reward_mechanism_20260917/PROBES.csv.
  role: Penalize z-axis base linear velocity using an L2 squared kernel (Isaac Lab v2.3.1, reports/evidence/go2_reward_term_roles_20260917/isaaclab_envs_mdp_rewards.py: torch.square(asset.data.root_lin_vel_b[:, 2])). It is the body frame's vertical speed squared - not foot height, not world-frame altitude, not ground clearance. On a slope the body frame tilts with the robot, so the same climb charges differently there than on flat ground.
  walk_margin: G-A033 walk margin +0.1359 -> +0.1420 at -1.75 (reports/evidence/go2_reward_mechanism_20260917/PROBES.csv, zone WALK, delta +0.0060, range_status BETWEEN_OBSERVED - the first value of this dial that is inside the observed walking range, because G-A043 walked at -1.5). The stop zone's top is +0.0155, so the margin stays about nine times above it. A margin is reward arithmetic over measured postures, not a prediction of speed.
  situations: reports/evidence/go2_reward_mechanism_20260917/PROBE_SITUATIONS.csv at -1.75: walk +0.0060, climb +0.0129, sway -0.0235, push -0.0193 - the same shape as -1.5 at half the size. G-A043 is the measured test of that sheet and it got two of the four directions WRONG: sway and push were predicted to fall and both rose (reports/evidence/go2_g_a043_readout_20260922/FORECAST_CHECK.csv). The sheet is therefore carried as a limit on the claim, not as a prediction this arm relies on.
  rule: The plan halves G-A043's step: -1.75 is the midpoint of the two values this dial has now been measured at on a walking baseline (-2.0 and -1.5), which is why its range_status is BETWEEN_OBSERVED rather than OUT_OF_RANGE. A midpoint in the weight is not a midpoint in the score: the plan pre-registers that a linear-half outcome (B 3.367 / L 2.318) fails BOTH c2 and c3, so 'half the step, half the damage' is a falsifiable claim here, not an assumption.
  not_claimed: No score gain is estimated. G-A043 showed the gain and the loss arrive together, and nothing measures how either scales with the weight - two points cannot give a curve. One training seed (42) cannot separate the lever from seed luck.

LEVERS NOT MOVED
  lin_vel_z_l2_to_m15_again: -1.5 is measured (G-A043) and failed: stairs up, G2 down, total +2.096/70 against a preregistered 2.53. Repeating it buys a seed replicate, which the plan puts after a screening pass, not before one.
  lin_vel_z_l2_to_m1: -1.0 (G-A037) stays on hold. It is twice this step in the direction that already broke a guard axis at half the distance, and its own derivation rests on the penalty-share rule that base data section 5 S5 reports as not holding across runs. A FAIL here does not license it either.
  track_lin_vel_xy_exp: held at 1.5: G-A042 raised it to 1.6 and the 10 cm two-or-more count went 43 -> 0 of 96 with posture falls 34 -> 85 (reports/GO2_G_A042_READOUT.md). The local extension of that dial is measured and closed.
  ang_vel_xy_l2: measured and closed for now in both directions on the stairs: -0.08 took the 10 cm climbed-robot count 90 -> 5 (G-A038) and the relaxation -0.04 took it 90 -> 34 with posture falls 34 -> 93 of 96 (G-A041).
  feet_air_time: held at 0.2: 0.01 and 0.1 were both rejected at stage 1 (A031, A032) and 0.35 stopped the policy (A015). It is air time, not foot height, so it does not address the tread.
  flat_orientation_l2: G-A040 is on hold with six adverse rows and a climb guard whose floor is non-positive, which tools/go2_fact_rules.py reports as inoperative. Its chain is not closed, so it does not overtake this arm. It is also the term a G2 posture loss would most obviously point at, which is exactly why it is not bundled in here: two changes at once would make the trade unreadable.
  action_rate_l2: -0.008 is a valid rejection (A018) and reports/evidence/go2_reward_mechanism_20260917/PROBE_SITUATIONS.csv leaves climb, sway and push empty for this term, so no situation direction can be read for it.
  dof_acc_l2: G-A039 is on hold and sits outside the deployed six, which makes it dependent on open decision U1-R6-ENV-REWARD-20260918. A term inside the list needs no such decision.
  max_iterations: outside R-6 (not a reward weight). See notes.curriculum_lag.
  training_seed: outside R-6. The plan asks for an independent-seed pair after a screening pass, not before it (reports/GO2_SEED_SENSITIVITY.md section 5).

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  No gain estimate exists and one training seed cannot
  separate the lever from seed luck.
  Pre-registered: all other axes held -- per-scenario weighted loss at most twice its own
  evaluation sd (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358), flat G1/G2 guards unchanged.

CHECKPOINT
  Evaluated at iter 900 of 1000, the iteration G-A033 was evaluated at.

VIDEOS (4 env x 500 steps)
  G2:combined_yaw_left:101   the mirror of the case that decided G-A043. It is filmed so the loss is not read from one direction alone: if only the right turn breaks again, that asymmetry is itself the finding. No G-A033 video of this case exists at these settings, so the baseline is rendered here.
  G2:combined_yaw_right:101  the case that broke G-A043: survival 1.0 -> 0.71875/0.71875/0.65625 at the three evaluation seeds while terminations stayed 0, so the posture gate caught something a termination count cannot show. G-A043 filmed none of G2, so the shape of that fall is VIDEO_UNKNOWN to this day. This run films it on both arms.
  G3:rough_forward:101       the axis this arm must hold while the stairs move; the case whose absence made G-A038 unscorable. Stored G-A033 video, reused by SHA.
  G3:rough_lateral:101       the sway case the arithmetic predicts a loss in (sway -0.0235 at -1.75). G-A043 improved it instead (+0.296 mean proxy), which is why the prediction is carried as direction only. The G-A033 counterpart was rendered in the G-A041 run and is reused here by SHA.
  G5:stairs_10_down:101      the target case the climbed-robot counter reads. The G-A033 counterpart was rendered in the G-A041 run from the frozen baseline model and is reused here by SHA.
  G5:stairs_15_down:101      the height the plan refuses to drop, and the one G-A043 moved most (pooled ge2 0 -> 77 of 96). The G-A033 counterpart was rendered in the G-A042 run and is reused here by SHA.
  G6:push_pos_x:101          the push direction the guard scores. Its G-A033 counterpart was rendered in the G-A043 run and is reused here by SHA - the first reuse of a push video, which needed the builder's fingerprint to model PUSH_X/PUSH_Y at all (defect C-13).
  G6:push_neg_x:101          the opposite push direction, guarded at three seeds since G-A043. Baseline reused by SHA from the G-A043 run.
  G6:push_pos_y:101          G-A043 left this direction as a single-seed observation with no verdict. The plan's section 6 promotes all four directions to the protection block, so it is measured at three seeds and filmed on both arms. No G-A033 video of this case exists, so the baseline is rendered here.
  G6:push_neg_y:101          the fourth push direction, and the only situation cell whose observed direction agreed with the arithmetic in G-A043 (-0.010). Filmed on both arms for the same reason as push_pos_y.

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
