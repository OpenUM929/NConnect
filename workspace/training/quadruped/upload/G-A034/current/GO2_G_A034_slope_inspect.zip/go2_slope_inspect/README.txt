GO2 G-A034  A017 uphill stall witness   (NO TRAINING)
======================================================

The stored A017 suite marks 7 of 32 robots on slope_plus_20 seed 101 as fallen
(envs 4 18 20 22 24 27 31).  Their numbers are level, low and nearly stopped;
no video has ever shown one of them.  This replays that case with the camera
following robots 22, 24, 4 (fallen) and 0 (walked), one replay each, and
re-records the telemetry so STUCK_CHECK.txt shows whether the replay matches.

Run:     bash /workspace/go2_slope_inspect/server_run_go2_slope_inspect.sh
Result:  /workspace/_keep/GO2_SLOPE_INSPECT_RESULT.zip  (+ .sha256)
Options: GO2_INSPECT_ENVS="22 31"   GO2_INSPECT_EYE="[-4.0,-4.0,4.0]"
