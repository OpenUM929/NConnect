GO2 G-A035 TRAINING LENGTH — G-A033 rewards, 1500 iterations
============================================================

This package TRAINS one policy and then measures it.  status: exploratory.

WHAT CHANGES
  NO REWARD WEIGHT CHANGES.  candidate/quadruped_rewards.py and
  reference/baseline_quadruped_rewards.py are byte-identical, on purpose.
  The single change is training length: 1000 -> 1500 iterations,
  the Isaac Lab v2.3.1 go2_rough value.  Deployed train/play/task code is unchanged.

WHY (plan GO2_BASIC_MOTION_TUNING_PLAN_20260915.md)
  The frozen baseline G-A033 scores 42.53/70. Its remaining loss is 27.47, and 20.2 of that is two cases:
  G5 stairs_15_down (10.46) and G3 rough_lateral (9.77).
  Neither is reachable by a reward weight. G5 is tracking-bound: survival could reach 1.00 and the
  scenario would still cap at 1.55/10.50 because the robot moves 0.10 m/s against a ~0.8 m/s command.
  G3 is survival-bound, and the only dial with proven effect (track) moves it the wrong way:
  1.4 -> 1.5 gained speed everywhere and cost rough_lateral survival .47 -> .38.
  The external reference explains both. Isaac Lab trains go2_rough for 1500 iterations; we train 1000.
  The terrain has 10 difficulty levels; our four runs reached 3.38 / 4.24 / 4.50 / 4.50 and were still
  rising at the last recorded iteration. Stair height scales 0.05 -> 0.23 m with difficulty, so the
  highest stair any of our policies has trained on is about 0.14 m, while the evaluation asks for 0.15 m.
  The 0.15 m stairs have never been trained. G-A033's own numbers fit: reaching level 4.50 took
  stairs_10_down from .03 to .88/.53/.53 while stairs_15_down stayed at .03-.13.
  This run changes no reward. It asks one question with a readout that cannot be lost in noise:
  how far does the terrain ladder go when the policy is given the training length Isaac Lab uses.

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  More training may not help.
  Promised: the reached terrain curriculum level is recorded at iterations
  700 / 900 / 1000 / 1200 / 1450.  That is a 0..9 axis whose run-to-run
  spread is already 1.1 in our data, so this readout cannot be lost in noise.
  Free side check: iterations 0..899 repeat G-A033 exactly (same code, seed and
  env count), so the SHA of model_900.pt says whether training is deterministic.

CHECKPOINT
  Evaluated at iter 1450 of 1500 (save_interval 50); the baseline
  G-A033 was evaluated at 900 of 1000.  Both are near-final checkpoints of their
  own run.  The iteration differs because training length IS the variable here.
  finalize's reward pick is kept as training/model_best_by_reward.pt, not evaluated.

STAGES (run the target stage first)
  target (default, ~115m): training, catastrophe gate, the 9 target cases,
     5 sentinel cases, 5 videos, result ZIP.  Criterion 1 is decided on
     the target cases alone, so a target-stage FAIL is final for this arm.
  full (~55m, only after a target pass): GO2_STAGE=full GO2_RESUME=1

ONE COMMAND
  cd /workspace && unzip -o GO2_G_A035_a033_iter1500_staged.zip && cd /workspace/go2_g_a035 && \
    tmux new -s go2_g_a035 -d 'bash server_run_go2_candidate_iter_pinned.sh 2>&1 | tee runner.log'
  Done marker: [DONE] GO2_G_A035_RESULT_READY
  Result:      /workspace/go2_g_a035/GO2_G_A035_RESULT.zip

VIDEOS (4 env x 500 steps)
  G5:stairs_15_down:101      THE min-case of G5 and of the whole score. Survival .03 and tracking .14 at 0.10 m/s against a ~0.8 m/s command: the robot is not falling, it is crawling. The video decides whether longer training makes it walk the 0.15 m stairs or still stall at them. No stored counterpart exists, so the baseline video is rendered in this run.
  G5:stairs_15_up:101        the ascent counterpart at the same step height; a stored G-A033 video exists for a direct A/B
  G3:rough_lateral:101       the min-case of G3, survival .38-.41. Side-stepping falls are the second largest hole. No stored counterpart, so the baseline video is rendered here.
  G4:slope_plus_20:101       G-A033 already reaches survival 1.00 here; the video guards against losing it
  G1:forward_fast:101        R-Sci-4 stationary-exploit guard on flat ground at the fastest command

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Promoted to the frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
