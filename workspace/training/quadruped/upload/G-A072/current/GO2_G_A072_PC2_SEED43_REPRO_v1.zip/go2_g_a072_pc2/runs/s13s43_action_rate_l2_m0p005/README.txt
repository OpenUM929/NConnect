G-A072 PC2 batch point s13s43_action_rate_l2_m0p005: 부모 P0 위 action_rate_l2 -0.01 -> -0.005. s13 seed 42: 15cm ≥2단 3→19. 탐색 기준 ≥10. Claude 예측 <10, Codex CX72-S13 ≥10.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
