GO2 G-A032 STAGED CANDIDATE — A017 + feet_air_time 0.2 -> 0.1
=============================================================

This package TRAINS one policy and then measures it.  status: exploratory.
It is one arm of a dose pair (G-A032 0.1, G-A031 0.01).

WHAT CHANGES
  The baseline is A017 (Pilot-01 + track_lin_vel_xy_exp 1.4), 39.76/70 on the
  69-case internal proxy (G-A027).  The candidate changes one reward only:
  feet_air_time 0.2 -> 0.1.  Deployed train/play/task code is unchanged
  (R-6); only candidate/quadruped_rewards.py carries the new value.

WHY (plan GO2_BASIC_MOTION_TUNING_PLAN_20260915.md)
  A017 walks well on flat ground (G1/G2 survival 1.0, tracking >= .89) but on rough,
  slope and DR it moves at about half the commanded speed (speed/command .49-.60 rough,
  .53-.57 slope) and loses robots to the height gate, not to tilt (slope 7/8/4, rough 2/1/0).
  feet_air_time 0.2 is A017's only term without single-variable evidence and 20x the
  Isaac Lab Go2 rough value 0.01 (Isaac Lab uses 0.25 only in the flat config).
  Raising it to 0.35 (A015) lowered body height in all 7 cases and collapsed survival.
  This arm tests the midpoint 0.1; G-A031 tests the Isaac Lab value 0.01.

STAGES (run the target stage first)
  target (default, ~1h25m): training, catastrophe gate, the 9 target cases,
     5 sentinel cases, 5 videos, result ZIP.  Criterion 1 is decided
     on the target cases alone, so a target-stage FAIL is final for this arm.
  full (~55m more, only after the local verifier says TARGET_PASS_FULL_STAGE_REQUIRED):
     the other cases of the 69, the target stage kept, result ZIP again; criteria 2-4.

RUN
  unzip GO2_G_A032_feet_air_time_010_staged.zip -d /workspace
  PACKAGE_ROOT=/workspace/go2_g_a032 bash /workspace/go2_g_a032/server_run_go2_candidate_staged.sh
  GO2_STAGE=full GO2_RESUME=1 PACKAGE_ROOT=/workspace/go2_g_a032 bash /workspace/go2_g_a032/server_run_go2_candidate_staged.sh
  Finish marker (both stages): [DONE] GO2_G_A032_RESULT_READY; RUNNER_STATUS.txt carries STAGE and DECISION.

VIDEOS (relevant cases only; the A017 counterparts are in the G-A027 harvest)
  G1:forward_fast:101      flat gait: are the feet still lifted, or dragged (H3)
  G3:rough_forward:101     target: rough-terrain forward walking
  G4:slope_plus_20:101     target: body height on the 20 deg climb (H1)
  G5:stairs_15_up:101      side effect: toes catching on steps (H3)
  G7:dr_seed_101:101       target: walking under domain randomisation

DOWNLOAD
  /workspace/_keep/GO2_G_A032_RESULT.zip
  /workspace/_keep/GO2_G_A032_RESULT.zip.sha256

PRE-REGISTERED READING (plan section 6-1, fixed before the run)
  success needs all of:
   1 basic motion off flat ground: the mean case proxy (survival x tracking) over
     rough_forward, slope_plus_20 and the three DR cases (9 case-seeds) rises by
     >= 0.05, and at least 2 of the 3 groups improve   [target stage]
   2 total internal proxy delta >= 0.0/70, same evaluator                 [full stage]
   3 flat ground holds: G1/G2 scenario proxy drop <= 0.02, no G1/G2 case loses
     more than 0.03125 survival; no other scenario loses more than
     0.5/70 weighted                                         [full stage]
   4 POLICY_LOCOMOTES and no new stationary case outside the stairs (G5)   [full stage]
   5 videos show normal four-legged walking with the feet lifted (human reading)
  Height and posture-gate falls on the target cases are read as the mechanism,
  not as a criterion.  The expected weighted gain is NOT estimated.
  Official results remain OFFICIAL_RESULT_UNMEASURED.
