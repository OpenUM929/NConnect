GO2 G-A031 + G-A032 BASIC-MOTION PAIR — one upload, one command, one result
===========================================================================

This package TRAINS two policies, one after the other on one GPU, and measures
them.  status: exploratory.  Plan: GO2_BASIC_MOTION_TUNING_PLAN_20260915.md.

ARMS (byte for byte the published single-arm packages)
  G-A031  feet_air_time 0.2 -> 0.01   arms/GO2_G_A031_feet_air_time_001_staged.zip  sha256 5f86fe9143834dbf5b13859545275c7e5374d3c659f3e77a6dfd8c2f3a8771b5
  G-A032  feet_air_time 0.2 -> 0.1   arms/GO2_G_A032_feet_air_time_010_staged.zip  sha256 c6e93bb5e8d9e5768283bdc8f9210e6c90c1dcb4739d73c6f56c9346399b8bba

RUN
  unzip -oq GO2_G_A031_A032_basic_motion_pair.zip -d /workspace
  bash /workspace/go2_basic_motion_pair/server_run_go2_basic_motion_pair.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_basic_motion_pair/server_run_go2_basic_motion_pair.sh

WHAT HAPPENS
  1 target stage of G-A031, then of G-A032 (~1h25m each): training, catastrophe
    gate, the 9 target cases, the sentinel, 5 videos.
  2 after each target stage, go2_target_gate.py reads criterion 1 (plan 6-1):
      TARGET_PASS -> full stage (~55m); FAIL -> the arm ends;
      REMEASURE_BASELINE -> target stage again with A017 remeasured, gate again;
      UNDECIDED -> no full stage.
  3 full stage of each arm the gate passed.
  4 one result ZIP.  The gate only schedules GPU time; the local verifier
    (tools/verify_go2_basic_motion_harvest.py) decides every verdict.

DOWNLOAD
  /workspace/_keep/GO2_BASIC_MOTION_PAIR_RESULT.zip
  /workspace/_keep/GO2_BASIC_MOTION_PAIR_RESULT.zip.sha256
  Finish marker: [DONE] GO2_BASIC_MOTION_PAIR_RESULT_READY
  Official results remain OFFICIAL_RESULT_UNMEASURED.
