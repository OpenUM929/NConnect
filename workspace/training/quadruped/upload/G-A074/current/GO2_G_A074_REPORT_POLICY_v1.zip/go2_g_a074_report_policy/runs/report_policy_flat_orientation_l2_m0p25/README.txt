G-A074 report-derived policy
Base: report.html seven values; candidate changes only flat_orientation_l2 -0.20 -> -0.25.
PC2: seed 42, 4096 envs, 3000 iterations, pinned checkpoint 2400, full 69-case collection.
Exploratory result; no automatic adoption or official-score claim.
