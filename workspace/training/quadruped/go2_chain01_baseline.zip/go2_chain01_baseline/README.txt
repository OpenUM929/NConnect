GO2 CHAIN-01 BASELINE  (work id G-A023)
==========================================

This package trains NOTHING.  It measures.

WHY
  Chain-01 (Default-01 + track_lin_vel_xy_exp 1.0->1.2 only, G-A011) is the
  campaign's frozen baseline -- the only reward dial with an independently
  verified, zero-survival-regression single-variable result.  It has only
  ever been scored by the tier-1 proxy (1 seed, internal early-kill cutoff).
  It has never run the full 69-case G1-G7 suite, never run seeds 202/303,
  and never been scored under the posture-gated evaluator on terrain.

  Three individual reward-weight overlays on top of Chain-01 have since each
  failed the tier-1 gate: lin_vel_z_l2 -3.0->-2.0 (G-A020, total collapse),
  ang_vel_xy_l2 -0.08->-0.05 (G-A021, partial regression), feet_air_time
  0.01->0.20 (G-A022, near-total collapse despite a positive prior on
  Default-01).  The remaining two participant-file dials (action_rate_l2,
  flat_orientation_l2) were already dial-wise exhausted on other baselines
  before the Chain-01 reset -- every direction either caused full-scenario
  collapse or was withdrawn as a sign/mechanism error, with no basis to
  expect a different outcome on Chain-01.  No further single-variable
  reward experiment is pre-registered.

  Chain-01 is therefore the campaign's best verified point and is the
  candidate this run gives a real score.

WHAT IT DOES
  1  frozen Chain-01, all 69 G1-G7 cases, seeds 101/202/303, posture-gated
  2  one video per scenario G1-G7, so the numbers have a witness
  3  one-file result ZIP

  Cost: about 1h05m of the remaining budget.  No training happens, so nothing
  about the submission candidate changes -- this run cannot damage it.

RUN
  unzip go2_chain01_baseline.zip -d /workspace
  bash /workspace/go2_chain01_baseline/server_run_go2_chain01_baseline.sh

  It starts inside tmux and returns immediately.
  Finish marker:  [DONE] GO2_CHAIN01_BASELINE_RESULT_READY

DOWNLOAD
  /workspace/_keep/GO2_CHAIN01_BASELINE_RESULT.zip
  /workspace/_keep/GO2_CHAIN01_BASELINE_RESULT.zip.sha256

GATES BUILT INTO THE RUNNER
  - the staged policy SHA must equal the frozen Chain-01 SHA, or it aborts
  - every case summary must carry survival_proxy_source = posture_gate_v2,
    or that case FAILS rather than being banked on the old metric
  - all 69 cases and all 7 videos must exist before packaging

PRE-REGISTERED READING (fixed before the run, not renegotiated after)
  Primary output is Chain-01's real /70 scorecard -- the number the campaign
  submits unless a future single-variable experiment with a genuinely new,
  untested, mechanically coherent direction is proposed and separately
  pre-registered.  This run does not itself select a next variable.
