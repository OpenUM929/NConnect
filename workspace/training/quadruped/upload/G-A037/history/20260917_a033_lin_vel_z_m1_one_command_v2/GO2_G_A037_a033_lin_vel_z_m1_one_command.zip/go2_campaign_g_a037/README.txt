GO2 G-A037 CAMPAIGN — one upload, one command, one result
=========================================================

This package TRAINS one policy and measures it.  status: exploratory.
Analysis: GO2_STAIRS_BEHAVIOR_ANALYSIS_20260916.md sections 8-9.

ARM (byte for byte what tools/build_go2_a033_reward_package.py builds)
  G-A037  lin_vel_z_l2 -2.0 -> -1.0 on G-A033; every other weight, seed 42,
  4096 envs and 1000 iterations are G-A033's
  arms/GO2_G_A037_a033_lin_vel_z_m1_staged.zip  sha256 975777e769e06345a4b9c32b2e59a70d69977b560b66ed33db15dddf4422fb90

BASELINE
  G-A033 (model ccd60e192bf4...), stored arm G-A033.
  Its summaries travel under stored_baseline/evaluation/g_a033.

RUN
  unzip -oq GO2_G_A037_a033_lin_vel_z_m1_one_command.zip -d /workspace
  bash /workspace/go2_campaign_g_a037/server_run_go2_campaign.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_campaign_g_a037/server_run_go2_campaign.sh

WHAT HAPPENS
  1 target stage (~90m): training 1000 iter, catastrophe gate, the 9 target cases
    (15cm climb, 10cm climb, rough side-step), the 5 sentinel cases, the videos.
  2 go2_target_gate.py reads criterion 1; the runner takes the verdict from the gate's JSON:
      TARGET_PASS -> full stage (~55m); FAIL -> ends;
      REMEASURE_BASELINE -> target stage again with G-A033 remeasured, gate again;
      UNDECIDED -> no full stage.
  3 one result ZIP.  The gate only schedules GPU time; the local verifier
    (tools/verify_go2_basic_motion_harvest.py) decides every verdict, including the
    per-scenario loss limits (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358).

CHECKPOINT
  The candidate is evaluated at iter 900, the iteration G-A033 was evaluated at.

DOWNLOAD
  /workspace/_keep/GO2_G_A037_CAMPAIGN_RESULT.zip
  /workspace/_keep/GO2_G_A037_CAMPAIGN_RESULT.zip.sha256
  Finish marker: [DONE] GO2_G_A037_CAMPAIGN_RESULT_READY
  Official results remain OFFICIAL_RESULT_UNMEASURED.
