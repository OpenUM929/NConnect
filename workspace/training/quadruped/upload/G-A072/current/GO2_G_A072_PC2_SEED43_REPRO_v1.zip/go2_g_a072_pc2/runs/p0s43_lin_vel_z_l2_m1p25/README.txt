G-A072 PC2 batch point p0s43_lin_vel_z_l2_m1p25: 부모 P0 위 lin_vel_z_l2 -1.25 -> -1.25. P0 seed 43. s04·s13·s11 seed 43을 같은 seed의 부모와 비교한다. P0 seed 42: 15cm ≥2단 3.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
