G-A063 PC2 batch point s08_feet_air_time_p0p5: 부모 P0 위 feet_air_time 0.2 -> 0.5. 배포 범위 최대. '0.5+ 면 바운딩 가능성'.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
