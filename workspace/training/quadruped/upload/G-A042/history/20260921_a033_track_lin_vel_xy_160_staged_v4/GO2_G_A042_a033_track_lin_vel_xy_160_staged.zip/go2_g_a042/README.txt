GO2 G-A042 REWARD CHANGE ON G-A033 — track_lin_vel_xy_exp 1.5 -> 1.6
====================================================================

This package TRAINS one policy and then measures it.  status: exploratory.
It is one arm of a campaign; do not run it on its own (see the campaign guide).

WHAT CHANGES
  Exactly one reward weight: track_lin_vel_xy_exp 1.5 -> 1.6.
  candidate/quadruped_rewards.py and reference/baseline_quadruped_rewards.py differ in that line only.
  Training length, seed, env count and every other weight are G-A033's.

WHY (analysis GO2_FORWARD_STAIRS_POLICY_20260921.md)
  The plan's goal, in its own words: hold rough forward travel and reduce the stall in front of the stairs, while learning how a reward weight changes behaviour. Not G3 mean alone, and not a reduction in wobble counted as a stairs improvement.
  Role first (Isaac Lab formula): track_lin_vel_xy_exp pays w * exp(-||v_cmd,xy - v_body,xy||^2 / std^2). Raising w raises what following the command is worth relative to every penalty. The robot that stops in front of a tread is not being paid enough to keep going; that is the reading this arm tests.
  This is the selected dial: A017->A033 (1.4 -> 1.5,900/900) took rough forward travel 5.002/4.744/6.121 -> 7.626/8.028/6.855 m and 10 cm climbed robots 28 -> 90 of 96, two-or-more 2 -> 43.
  The stall is what the numbers show in front of the stairs: G-A033 averages 0.199/0.180/0.192 m/s against a 0.5 m/s command on stairs_10_down and travels 2.126/2.217/2.215 m of an expected 10 m (reports/evidence/go2_stairs_behavior_20260916/CASE_BEHAVIOR.csv).
  Walking is the safe side: the walk margin rises +0.1359 -> +0.1801 at 1.6 and the stop zone's top is +0.0155, so the arm cannot produce a standing policy by arithmetic.
  Named in advance, and this is why the arm is an information run and not a recommendation: the direct A017->A033 comparison improved stairs and is also a comparison with side-step loss - rough_lateral terminations 48 -> 58 of 96 and posture falls 8 -> 45 - and the participant file itself warns that raising this term breaks posture on rough ground. G-A033's own stage 2 failed on that axis (G3 weighted loss 0.743 > 0.5) and was promoted by user decision, not by the gate.
  1.6 is a step size, not an optimum: the increment repeats the last valid comparison, stays inside the deployed band 추천 0.5 ~ 2.0, and is the smallest untested value of a dial with no rejection history on a walking baseline.
  Risks pre-registered under fact_rules_v1: the rough and push group floors, the per-scenario loss limits (G3 2.03646, G6 0.86196), the flat guards, the stationary guard, and the climbed-robot floors as the reverse guard. The 15 cm stairs are a required record in stage 1 whatever the gate decides.

HOW THE VALUE WAS CHOSEN
  source: workspace/training/quadruped/upload/plan/GO2_FORWARD_STAIRS_POLICY_20260921.md sections 2 and 3; reports/GO2_STAIRS_BEHAVIOR_ANALYSIS_20260916.md; reports/GO2_G_A041_READOUT.md; evidence reports/evidence/go2_stairs_behavior_20260916/STAIRS_CLIMB.csv and reports/evidence/go2_stairs_behavior_20260916/CASE_BEHAVIOR.csv; reports/evidence/go2_reward_mechanism_20260917/PROBES.csv and reports/evidence/go2_reward_mechanism_20260917/PROBE_SITUATIONS.csv; reports/GO2_TUNING_BASE_DATA.md sections 0-1, 2 and 4; reports/runs/LEDGER.csv, reports/runs/SCENARIO_SCORES.csv and reports/runs/TERRAIN_AT_PIN.csv
  role: Track linear velocity commands (xy axes) with an exponential kernel (Isaac Lab v2.3.1, reports/evidence/go2_reward_term_roles_20260917/isaaclab_envs_mdp_rewards.py): w * exp(-||v_cmd,xy - v_body,xy||^2 / std^2), std 0.5. The weight multiplies a bounded kernel, so raising it raises the value of closing the velocity error and, relative to every penalty, lowers the value of standing still. It says nothing about how the foot reaches the tread. G-A033 logs this term at 0.9436 of a 1.5 weight at iteration 999 (reports/runs/LEDGER.csv track_lin_vel_999), that is about 0.63 of the kernel's maximum.
  walk_margin: G-A033 walk margin +0.1359 -> +0.1801 at 1.6 (reports/evidence/go2_reward_mechanism_20260917/PROBES.csv, zone WALK, delta +0.0442, range_status OUT_OF_RANGE). The stop zone's top is +0.0155 and the walk-zone edge weight for this term is 1.22752, below the baseline, so the change moves away from the edge. Raising the objective term cannot lower this margin; the margin is therefore not evidence for the arm, counterfactual arithmetic that cannot rule out a stalled policy.
  situations: reports/evidence/go2_reward_mechanism_20260917/PROBE_SITUATIONS.csv at 1.6: walk +0.0442, climb +0.0204, sway +0.0111, push +0.0573. All four cells are positive, which is exactly why they may not be read as a forecast of this arm: the direct A017->A033 comparison (900/900) has the sway case going the other way (rough_lateral terminations 48 -> 58 of 96, posture falls 8 -> 45, reports/evidence/go2_stairs_behavior_20260916/CASE_BEHAVIOR.csv). Where the model and the measurement disagree, this spec follows the measurement and puts the case in stage 1 with a measured floor.
  rule: The plan selects 1.6 as one additional 0.1 increment, not an optimum or a calibrated prediction. The direct comparison A017->A033 uses checkpoint900/900; Pilot->A017 uses999/900 and is supporting observation only, not an identical-condition replication. Loss is observed but no scaling law or exclusive cause is established.
  not_claimed: No score gain is estimated and no claim is made that a third raise repeats the first two. The partial margins are reward arithmetic over measured postures: they say what the reward prefers, not how many robots will climb, and for this dial all four situation cells point the same way while the measurement does not. The plan's own words are kept: 1.6 is an information value outside the observed range, not the current best value.

LEVERS NOT MOVED
  ang_vel_xy_l2: measured and closed for now in both directions on the stairs: -0.08 took the 10 cm climbed-robot count 90 -> 5 (G-A038) and the relaxation -0.04 took it 90 -> 34 with posture falls 34 -> 93 of 96 (G-A041, INTERNAL_GATE_FAIL, reports/GO2_G_A041_READOUT.md). Neither side of this dial helped the stairs, which is what moves the plan to a dial with a measured joint improvement.
  feet_air_time: held at 0.2: 0.01 and 0.1 were both rejected at stage 1 (A031, A032) and 0.35 stopped the policy (A015). It is air time, not foot height, so it does not address the tread.
  lin_vel_z_l2: G-A037 is on hold: -1.0 is outside the observed walking range and its derivation came out reversed in base data S5. Relaxing the vertical penalty as a stairs lever is contradicted by that row, so it is not taken here.
  flat_orientation_l2: G-A040 is on hold with six adverse rows and still carries a climb guard whose floor is non-positive (stairs_15_climb_ge1, baseline sum 4, max drop 5.523), which tools/go2_fact_rules.py reports as inoperable (defect S-2). This spec leaves that group out for the same reason and measures the 15 cm stairs as a required record instead.
  action_rate_l2: -0.008 is a valid rejection (A018) and PROBE_SITUATIONS.csv leaves climb, sway and push empty for this term, so no situation direction can be read for it.
  dof_acc_l2: G-A039 is on hold and sits outside the deployed six, which makes it dependent on open decision U1-R6-ENV-REWARD-20260918. A term inside the list needs no such decision.
  max_iterations: outside R-6 (not a reward weight). Matching the two arms' curriculum level at the pin would need it and is therefore not done here; see notes.curriculum_lag.
  training_seed: outside R-6. The plan asks for an independent-seed pair after a screening pass, not before it, and a seed replicate buys interpretation rather than score (reports/GO2_SEED_SENSITIVITY.md section 5).

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  No gain estimate exists and one training seed cannot
  separate the lever from seed luck.
  Pre-registered: all other axes held -- per-scenario weighted loss at most twice its own
  evaluation sd (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358), flat G1/G2 guards unchanged.

CHECKPOINT
  Evaluated at iter 900 of 1000, the iteration G-A033 was evaluated at.

VIDEOS (4 env x 500 steps)
  G5:stairs_10_down:101      the target case the climbed-robot counter reads. The G-A033 counterpart was rendered in the G-A041 run from the frozen baseline model and is reused here by SHA.
  G5:stairs_15_down:101      the height the plan refuses to drop. No G-A033 video of this case exists at these settings - the stored arm holds stairs_15_up, a different case - so the baseline is rendered here.
  G3:rough_forward:101       the axis the arm must hold while the stairs move; this is the case whose absence made G-A038 unscorable. Stored G-A033 video.
  G3:rough_lateral:101       the measured loss of this dial's last two raises (terminations 48 -> 58). The G-A033 counterpart was rendered in the G-A041 run and is reused here by SHA.

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
