G-A063 PC2 batch point s12_action_rate_l2_m0p02: 부모 P0 위 action_rate_l2 -0.01 -> -0.02. 배포 범위 최강. 배포 ⑤ '강하게: 부드럽지만 굼뜬 반응'.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
