G-A061 PC2 tree node n3_dof_torques_l2_m1e_4: 부모 P0 위 dof_torques_l2 -0.0002 -> -0.0001. 학습 seed 42, 4096 env, 1000 iter, 평가 iter 900, 69 case.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
