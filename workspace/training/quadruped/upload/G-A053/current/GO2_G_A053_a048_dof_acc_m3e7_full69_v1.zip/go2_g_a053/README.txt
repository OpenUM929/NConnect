GO2 G-A053 REWARD CHANGE ON G-A048 REWARDS — dof_acc_l2 -2.5e-07 -> -3e-07
==========================================================================

This package TRAINS one policy and then measures it.  status: exploratory.
One upload, one command, one result ZIP: the whole 69-case evaluation runs in a single
pass (run_config.env pins GO2_STAGE=full), so there is no target stage and no server gate.
  unzip -oq <this zip> -d /workspace
  bash /workspace/go2_g_a053/server_run_go2_candidate_iter_pinned.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_g_a053/server_run_go2_candidate_iter_pinned.sh

WHAT CHANGES
  Exactly one reward weight on G-A048's trained rewards: dof_acc_l2 -2.5e-07 -> -3e-07.
  candidate/quadruped_rewards.py and reference/reward_base_quadruped_rewards.py differ in that line only.
  Against the adoption baseline G-A033 two weights differ: lin_vel_z_l2 -2.0 -> -1.25
  (G-A048's own change) and this one; reference/baseline_quadruped_rewards.py is G-A033's.
  Effects are read as candidate - G-A048; adoption is judged against G-A033.
  Training length, seed and env count are G-A033's (and G-A048's).

WHY (analysis GO2_G_A053_PLAN_20260928.md)
  Purpose: remove the rough side-step failure pattern in which joint-acceleration cost sits above the survivors' long before the fall (G-A052 env2, env4), while keeping G-A048's gains (total 50.16, rough falls 16, 10 cm ge2 90, combined-turn falls 0, push falls 1) and its low-posture recovery. Not a promise of a higher score.
  Support: env2 and env4 paid about twice the survivors' joint-acceleration cost at 1-3 s (-0.06711 and -0.05755 against -0.03003), before their command change rose.
  Against: the 15 cm survivor paid more joint-acceleration cost than the failures; env15 fell with a lower cost in its last second; this term is G-A048's largest walking cost; a high cost may be a result of terrain contact rather than its cause. The step is 20 percent.
  Selection by Codex (relayed by the user); the unlisted term is allowed by the user's decision G-D-U1-APPROVED-20260928; package and records by the main loop.

HOW THE VALUE WAS CHOSEN
  source: workspace/training/quadruped/upload/plan/GO2_G_A053_PLAN_20260928.md sections 1-3; reports/GO2_G_A052_DIAG_READOUT_20260928.md section 5; reports/evidence/go2_g_a052_diag_20260928/COST_PHASES.csv; reports/evidence/go2_g_a052_diag_20260928/CASE_COST_SUMMARY.csv; reports/evidence/go2_g_a052_diag_20260928/TORQUE_BY_HEIGHT.csv; reports/evidence/go2_reward_mechanism_20260917/RUN_MARGIN.csv
  role: Penalize joint accelerations on the articulation using L2 squared kernel (Isaac Lab v2.3.1, reports/evidence/go2_reward_term_roles_20260917/isaaclab_envs_mdp_rewards.py:163): -w * sum of squared joint accelerations. It charges how fast joint velocities change, not torque, not the policy's action change (action_rate_l2) and not a fall.
  walk_margin: walk margin G-A048 +0.1540 -> +0.126 for the candidate rewards (go2_reward_mechanism.spec_margin, zone WALK); the 20 percent step costs 0.2 x 0.1402 = 0.028. Doubling the penalty would take the margin to about +0.014, at the stop zone's top +0.0155, which is why 2x is excluded.
  situations: The evaluation records carry no joint channels, so the situation sheet has no cell for this term (unmeasured_in_situations). The G-A052 replay is the only situation-level observation: failures above survivors on rough side-stepping (5 of 7 in the last second) and on the 10 cm climb (5 of 8), below survivors on the 15 cm climb (14 of 31, survivor median -0.14622 against failure median -0.12456).
  rule: -3e-07 is +20 percent of the penalty. The width is limited because this term is the largest walking cost of G-A048 (-0.1402) and it also charges normal gait and stair leg placement; it is a design choice, not a measured safe value, and no data says 20 percent beats 10 or 25 percent.
  not_claimed: No score gain is estimated and no causal link is claimed: the elevated cost may be a result of terrain contact rather than its cause, the target pattern rests on two robots of one case at one evaluation seed of one policy, and the replay's survivors are not terrain- or gait-matched.

LEVERS NOT MOVED
  action_rate_l2: the comparison direction Codex ranked second: the command-change rise sits in the last window (env2, env4, env27) and strengthening it risks suppressing the last recovery command; the earlier relaxation (G-A018 -0.008) stopped the policy.
  dof_torques_l2: relaxation withdrawn 2026-09-28 (G-D-A052-TORQUE-20260928): survivors' torque cost rises as the body lowers (TORQUE_BY_HEIGHT.csv), so relaxing could deepen G-A048's low side-step posture; strengthening would tax the support force.
  dof_acc_l2_relax: G-A039 (-1.25e-07) is an unexecuted spec whose priority was withdrawn (GO2_REWARD_MECHANISM_FORECAST.md section 8-6); the G-A052 recovery windows of env23 do not show a large average acceleration that a penalty would block.
  dof_acc_l2_m5e7: doubling takes the walk margin to about +0.014, at the stop zone's top.
  ang_vel_xy_l2: A051 (-0.06 on G-A048) withdrawn; the G-A052 readout found no rotation-first fall (G-D-A052-READOUT-20260928).
  feet_air_time: not raised: contact markers were as common in survivors (G-D-A052-READOUT-20260928).
  lin_vel_z_l2: held at G-A048's -1.25: the single-term search closed after six measured points (G-A050 readout).
  track_lin_vel_xy_exp: held at 1.5: G-A042 raised it to 1.6 and the 10 cm two-or-more count went 43 -> 0 of 96.
  flat_orientation_l2: -0.5 (G-A047) lost the climb (10 cm ge1 90 -> 3) and left rough side-step falls at 60/96.
  max_iterations: training-length comparison is on hold by user decision; not used as a reason for this choice.
  training_seed: outside R-6 until U2 is answered; not used as a reason for this choice.

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  No gain estimate exists and one training seed cannot
  separate the lever from seed luck.
  Pre-registered: all other axes held -- per-scenario weighted loss at most twice its own
  evaluation sd (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358), flat G1/G2 guards unchanged.

CHECKPOINT
  Evaluated at iter 900 of 1000, the iteration G-A033 was evaluated at.

VIDEOS (4 env x 500 steps)
  G2:combined_yaw_left:101   the mirror of the case that broke G-A043. Filmed so a recurrence is not read from one direction alone.
  G2:combined_yaw_right:101  combined-turn protection: G-A043 lost 29 of 96 here; G-A048 lost none. Filmed on the candidate.
  G3:rough_forward:101       the rough axis the arm must hold. Stored G-A033 video, reused by SHA.
  G3:rough_lateral:101       the target: rough side-step posture falls G-A033 59, G-A048 16; the env2/env4 pattern comes from this case at seed 202. Baseline reused by SHA.
  G5:stairs_10_down:101      stairs protection: a joint-acceleration price also charges stair leg placement. Baseline reused by SHA.
  G5:stairs_15_down:101      stairs protection case (15 cm climb): in the G-A052 replay the survivor paid more joint-acceleration cost than the failures. Baseline reused by SHA.
  G6:push_pos_x:101          the push direction the fact_rules group scores; recovering from a shove needs fast joint motion. Baseline reused by SHA.
  G6:push_neg_x:101          push protection block direction. Baseline reused by SHA.
  G6:push_pos_y:101          push protection block direction. Baseline reused by SHA from the G-A044 run.
  G6:push_neg_y:101          push protection block direction. Baseline reused by SHA from the G-A044 run.

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
