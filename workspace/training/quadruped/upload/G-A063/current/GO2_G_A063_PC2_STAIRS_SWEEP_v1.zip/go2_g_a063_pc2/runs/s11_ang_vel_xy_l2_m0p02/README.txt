G-A063 PC2 batch point s11_ang_vel_xy_l2_m0p02: 부모 P0 위 ang_vel_xy_l2 -0.05 -> -0.02. 배포 범위 최약. 배포 ④ '약하게: 흔들림 허용 (험지 적응 여지)'.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
