GO2 G-A045 + G-A046 SEED PAIR — one upload, one command, one result
===================================================================

This package TRAINS TWO policies, one after the other on one GPU, and measures each over
all 69 cases.  status: exploratory.  Plan: GO2_A045_SEED_PAIR_PLAN_20260924.md.

WHAT IT MEASURES
  Both arms train at seed 43, a seed this project has never used:
  in every training this project has recovered the seed cell reads 42 (21 harvests record TRAIN_STATUS SEED=42; four older evaluation-only harvests record none, and no harvest anywhere records a different one).
    G-A045 carries G-A033's reward file unchanged, so its distance from the stored
          G-A033 record is ONE sample of the seed difference AT THAT WEIGHT.
    G-A046 carries lin_vel_z_l2 -1.5, the value G-A043 measured at seed 42, so
          (B - A) at the same seed is the dial's effect on a second training path.
  The two comparisons are symmetric with G-A033 <-> G-A043 at seed 42, which is what makes
  "did the effect repeat?" answerable.  It does NOT make "was G-A044's non-monotonic fall
  count caused by the dial or by the path?" answerable: this pair does not repeat -1.75.

HOW TO READ IT (plan section 4-2)
  Absolute level and paired difference are separate questions.  An arm reaching 50 of 96
  robots up two 15 cm steps says the behaviour appeared; only (B - A) at the same seed says
  the dial did it.  If A is already high and B is lower, the dial did not help there.

NEITHER ARM MAY BE PROMOTED
  promotion: forbidden_not_a_reward_change (both arms).
  A training seed is not a reward weight, so this campaign cannot produce a submission
  candidate and the frozen baseline stays G-A033 whatever these arms score.
  That ban is OURS and conservative.  What is established is only that no deployed file is
  edited; that a CLI argument is passed through is not evidence that the rules permit the
  round, and we equally do not claim the rules forbid submitting a seed-43 policy.
  Open reading: U2-SEED-REPLICATE-20260918 - best closed by an organiser's answer or an explicit official
  basis, not by our reading alone.

ARMS (byte for byte what tools/build_go2_seed_pair_package.py builds)
  G-A045  ruler        lin_vel_z_l2 -2.0  seed 43   arms/GO2_G_A045_seed43_a033_rewards_full69_v5.zip
           sha256 4ef3abeb7f8e323bf5a932c5ce857df2e27ab142961ac2075a5b70f35afe2787
  G-A046  replication  lin_vel_z_l2 -1.5  seed 43   arms/GO2_G_A046_seed43_lin_vel_z_m15_full69_v5.zip
           sha256 e595760df12bae2c663febedb6a400832d558359f9e60618523bf557dc2bbeff

RUN
  unzip -oq GO2_G_A045_A046_seed43_pair_full69_v6.zip -d /workspace
  bash /workspace/go2_g_a045_a046/server_run_go2_full69_campaign.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_g_a045_a046/server_run_go2_full69_campaign.sh

WHAT HAPPENS
  1 G-A045 full stage (~95m): training 1000 iter, catastrophe gate, all 69 cases,
    the sentinel, 6 candidate videos and 4 baseline videos, its result ZIP.
  2 G-A046 full stage (~95m): the same, with 6 candidate videos and no baseline
    videos - its counterparts were filmed in step 1 from the same stored policy.
  3 one result ZIP holding both arm result ZIPs and CAMPAIGN_STATUS.txt.
  There is no target gate and no arm gates the other: a failed arm is packaged with what
  it collected and the next arm runs.  Every verdict is read locally after recovery.

DOWNLOAD
  /workspace/_keep/GO2_SEED_PAIR_RESULT.zip
  /workspace/_keep/GO2_SEED_PAIR_RESULT.zip.sha256
  Finish marker: [DONE] GO2_SEED_PAIR_RESULT_READY  (it is NOT printed on the crash path - see the guide)
  Official results remain OFFICIAL_RESULT_UNMEASURED.
