GO2 G-A038 CAMPAIGN — one upload, one command, one result
=========================================================

This package TRAINS one policy and measures it.  status: exploratory.
Analysis: GO2_REWARD_MECHANISM_FORECAST.md sections 2, 5-1, 6-0 and 8.

ARM (byte for byte what tools/build_go2_a033_reward_package.py builds)
  G-A038  ang_vel_xy_l2 -0.05 -> -0.08 on G-A033; every other weight, seed 42,
  4096 envs and 1000 iterations are G-A033's
  arms/GO2_G_A038_a033_ang_vel_xy_m008_staged.zip  sha256 af515fa3abf523d3d79bd231c01ce3e80a63b8bb60bc4ceb27c6a0557e613ef6

BASELINE
  G-A033 (model ccd60e192bf4...), stored arm G-A033.
  Its summaries travel under stored_baseline/evaluation/g_a033.

RUN
  unzip -oq GO2_G_A038_a033_ang_vel_xy_m008_one_command.zip -d /workspace
  bash /workspace/go2_campaign_g_a038/server_run_go2_campaign.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_campaign_g_a038/server_run_go2_campaign.sh

WHAT HAPPENS
  1 target stage (~90m): training 1000 iter, catastrophe gate, the 9 target cases
    (rough side-step, forward push, 10cm climb), the 5 sentinel cases, the videos.
  2 go2_target_gate.py reads criterion 1; the runner takes the verdict from the gate's JSON:
      TARGET_PASS -> full stage (~55m); FAIL -> ends;
      REMEASURE_BASELINE -> target stage again with G-A033 remeasured, gate again;
      UNDECIDED -> no full stage.
  3 one result ZIP.  The gate only schedules GPU time; the local verifier
    (tools/verify_go2_basic_motion_harvest.py) decides every verdict, including the
    per-scenario loss limits (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358).

CHECKPOINT
  The candidate is evaluated at iter 900, the iteration G-A033 was evaluated at.

DOWNLOAD
  /workspace/_keep/GO2_G_A038_CAMPAIGN_RESULT.zip
  /workspace/_keep/GO2_G_A038_CAMPAIGN_RESULT.zip.sha256
  Finish marker: [DONE] GO2_G_A038_CAMPAIGN_RESULT_READY
  Official results remain OFFICIAL_RESULT_UNMEASURED.
