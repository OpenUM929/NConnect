G-A062 PC2 batch point q0_lin_vel_z_l2_m1p5: 부모 P0 위 lin_vel_z_l2 -1.25 -> -1.5. Q0 = P0 + lin_vel_z −1.5(A043 보상). B 계열의 직접 부모. 서버 A043 15cm ≥2단 77/96·우회전 낙상 29/96의 PC2 재현 여부.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
