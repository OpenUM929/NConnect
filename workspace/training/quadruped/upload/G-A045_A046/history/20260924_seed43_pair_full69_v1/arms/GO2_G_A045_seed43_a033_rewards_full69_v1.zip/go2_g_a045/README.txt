GO2 G-A045 — seed 43 ruler arm of the pair G-A045_A046
======================================================

This package TRAINS one policy and then measures it over all 69 cases.  status: exploratory.

WHAT CHANGES
  TRAINING SEED 42 -> 43.  Deployed train/play/task code is unchanged; the seed is the
  CLI argument the deployed train.py forwards to Isaac Lab's rsl_rl train.py.
  NO REWARD WEIGHT CHANGES.  candidate/quadruped_rewards.py and
  reference/baseline_quadruped_rewards.py are byte-identical, on purpose:
  this arm is G-A033's reward file trained again at seed 43, so that the
  difference from the stored G-A033 record is the training path alone.

WHAT THIS ARM MAY NOT BECOME
  A submission candidate.  promotion: forbidden_not_a_reward_change.
  A training seed is not a reward weight, so nothing measured here can be promoted,
  whatever it scores.  The open reading is U2-SEED-REPLICATE-20260918 and it is the user's to close.

WHY (plan GO2_A045_SEED_PAIR_PLAN_20260924.md)
  The plan's goal in its own words: measure the ruler before trusting another reading from it. Not a candidate, not a value search.
  What is measured, not argued: across the three runs of one dial the climbed-robot counts are ordered (43 -> 62 -> 94; 4 -> 39 -> 88) and the posture-fall counts are not (34 -> 65 -> 17; 59 -> 80 -> 24; 22 -> 66 -> 10). The 70-point total follows the falls.
  Why it cannot be settled by another value: a fourth point on the dial is measured with the same untested ruler. The disagreement above is about the instrument, and only a same-reward second training path reads it.
  Why now: the swings in question (-3.63 and +2.10 of 70) are the same size as the promotion margin (+2.53). Every FAIL the project has recorded sits inside that band.
  Named in advance: if this arm lands on top of the stored G-A033 record, the round says so and dial exploration continues unchanged. A null result here is a real result and the plan section 4-1 table reads it the same way either direction.

CHECKPOINT
  Evaluated at iter 900 of 1000,
  the iteration G-A033 and G-A044 were evaluated at.  finalize's reward pick is kept as
  training/model_best_by_reward.pt and is not evaluated.

STAGES
  full only (~95m): training, catastrophe gate, all 69 cases,
  5 sentinel cases, 6 candidate videos,
  4 baseline videos, result ZIP.  There is no stage 1 and no server gate.

THIS ARM IS RUN BY THE PAIR RUNNER
  The campaign package GO2_G_A045_A046_seed43_pair_full69_v1.zip carries this ZIP and runs it with
  server_run_go2_full69_campaign.sh.  Running this arm alone also works:
    bash /workspace/go2_g_a045/server_run_go2_candidate_iter_pinned.sh
  Done marker: [DONE] GO2_G_A045_RESULT_READY
  Result:      /workspace/_keep/GO2_G_A045_RESULT.zip

VIDEOS (4 env x 500 steps)
  G5:stairs_15_down:101      the counter that moved most on this dial (pooled >=1 step 4 -> 39 -> 88 of 96 over -2.0, -1.75, -1.5) and the one this round asks to see repeated on a second training path. Filmed on both arms so a count can be read as a behaviour.
  G5:stairs_10_down:101      the other stair height, where the climbed count rose monotonically (43 -> 62 -> 94) while posture falls did not (34 -> 65 -> 17). Two counters disagreeing on the same case is the thing this round measures.
  G3:rough_lateral:101       the fall counter with the widest swing between runs at the same weight family (59 -> 80 -> 24 of 96). If the seed-43 ruler arm lands far from 59, the counter is path-sensitive and the axis limits built on it are looser than they look.
  G2:combined_yaw_right:101  the case that decided G-A043 (posture falls 0 -> 29 of 96) and the only guard counter that follows the dial monotonically. Filmed on both arms: if it breaks again at seed 43 under -1.5, the loss belongs to the value, not to the path.
  G6:push_pos_y:101          one of the four push directions whose pooled falls went 22 -> 66 -> 10 across the three points. A shove is the shortest event we film, so the recovery shape is readable rather than inferred from a survival number.
  G1:forward_nominal:101     the catastrophe case and the flat floor. Both arms must walk before any other number means anything; this is the film that shows it rather than asserting it from a gate.

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 over 69 cases,
  trained at seed 42).  Its model and env ship here so the server can verify the sentinel
  cases re-measure the same policy with the same ruler.
