G-A075 PC2 execution
unzip -oq /workspace/GO2_G_A075_REPORT_POLICY_v1.zip -d /workspace
bash /workspace/go2_g_a075_report_policy/run_all.sh
Results: /workspace/_keep/go2_g_a075_report_policy and GO2_G_A075_REPORT_POLICY_RESULT.zip
