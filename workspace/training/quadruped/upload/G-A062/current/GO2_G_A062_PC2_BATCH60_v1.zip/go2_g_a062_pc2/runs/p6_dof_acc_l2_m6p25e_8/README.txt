G-A062 PC2 batch point p6_dof_acc_l2_m6p25e_8: 부모 P0 위 dof_acc_l2 -2.5e-07 -> -6.25e-08. P0 G3 후보. G-A061 N6 값을 N5 결과와 무관하게 P0 위에서 실행.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
