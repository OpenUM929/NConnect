G-A057 sweep arm ang_vel_xy_l2_m0p08
A048 보상에서 ang_vel_xy_l2 한 항만 -0.05 -> -0.08. 학습 seed 42, 4096 env, 1000 iter, 평가 iter 900, 69 case.
이 폴더는 run_sweep.sh 가 펼쳐서 쓴다. 혼자 실행하지 않는다. 결과는 반응 데이터이며 채택·승급 대상이 아니다.
