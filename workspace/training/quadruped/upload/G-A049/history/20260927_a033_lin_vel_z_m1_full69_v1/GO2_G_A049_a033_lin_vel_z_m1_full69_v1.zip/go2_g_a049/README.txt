GO2 G-A049 REWARD CHANGE ON G-A033 — lin_vel_z_l2 -2.0 -> -1.0
==============================================================

This package TRAINS one policy and then measures it.  status: exploratory.
One upload, one command, one result ZIP: the whole 69-case evaluation runs in a single
pass (run_config.env pins GO2_STAGE=full), so there is no target stage and no server gate.
  unzip -oq <this zip> -d /workspace
  bash /workspace/go2_g_a049/server_run_go2_candidate_iter_pinned.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_g_a049/server_run_go2_candidate_iter_pinned.sh

WHAT CHANGES
  Exactly one reward weight: lin_vel_z_l2 -2.0 -> -1.0.
  candidate/quadruped_rewards.py and reference/baseline_quadruped_rewards.py differ in that line only.
  Training length, seed, env count and every other weight are G-A033's.

WHY (analysis GO2_NEXT_CANDIDATE_20260927.md)
  Purpose: see whether the G3 and G6 gains of the only dial that raised the total on this baseline hold one interval further. Not a promise of a higher score.
  Role first (Isaac Lab formula): lin_vel_z_l2 pays -w * v_z^2 in the body frame, with no direction term, so the rise a tread requires is charged at the same rate as the bounce a bad landing produces. That is the mechanism this arm moves, and it is a property of the formula.
  What is measured: at -2.0 / -1.75 / -1.5 / -1.25 the total was 42.53 / 38.89 / 44.62 / 50.16, rough side-step posture falls 59 / 80 / 24 / 16, push falls 22 / 66 / 10 / 1 and combined_yaw_right falls 0 / 0 / 29 / 0. Every counter is non-monotone across the four points.
  Why -1.0: it keeps the 0.25 interval and steps once beyond the relaxed end. It is G-A037's held value, now chosen on the direct evidence of G-A043 and G-A048 and not on G-A037's penalty-share derivation, which still does not hold (S5).
  Two verdicts, fixed before the run: the hypothesis indicators (rough side-step falls <= 41 supported / >= 59 not; combined_yaw_right falls at >= 2 seeds = cost present, 0 seeds = absent; 15 cm ge2 recorded only) and adoption under fact_rules_v1 plus post_a048_guard_margin_v1. Neither verdict rescues the other.
  Collection is G-A048's: all 69 cases in one pass, both combined-turn directions and all four push directions filmed on the candidate, every baseline counterpart reused by SHA.

HOW THE VALUE WAS CHOSEN
  source: workspace/training/quadruped/upload/plan/GO2_NEXT_CANDIDATE_20260927.md section 2; reports/GO2_G_A048_READOUT.md; reports/GO2_G_A048_ANALYSIS_SUPPLEMENT.md; evidence reports/evidence/go2_g_a048_readout_20260926/DIAL_FOUR_POINTS.csv, reports/evidence/go2_g_a048_readout_20260926/MONOTONICITY_FOUR.csv, reports/evidence/go2_g_a048_readout_20260926/FORECAST_CHECK.csv, reports/evidence/go2_reward_mechanism_20260917/PROBES.csv.
  role: Penalize z-axis base linear velocity using an L2 squared kernel (Isaac Lab v2.3.1, reports/evidence/go2_reward_term_roles_20260917/isaaclab_envs_mdp_rewards.py: torch.square(asset.data.root_lin_vel_b[:, 2])). It is the body frame's vertical speed squared - not foot height, not world-frame altitude, not ground clearance. On a slope the body frame tilts with the robot, so the same climb charges differently there than on flat ground.
  walk_margin: G-A033 walk margin +0.1359 -> +0.1601 at -1.0 (reports/evidence/go2_reward_mechanism_20260917/PROBES.csv, zone WALK, delta +0.0242, range_status OUT_OF_RANGE - beyond the walking values -2.0, -1.75, -1.5 and -1.25). The stop zone's top is +0.0155. A margin is reward arithmetic over measured postures and is not a ranking basis (reports/GO2_REWARD_MECHANISM_FORECAST.md section 8).
  situations: reports/evidence/go2_reward_mechanism_20260917/PROBE_SITUATIONS.csv at -1.0: walk +0.0242, climb +0.0515, sway -0.0940, push -0.0771. At -1.25 the same sheet predicted losses on sway and all four push directions and every one of them came out a gain (reports/evidence/go2_g_a048_readout_20260926/FORECAST_CHECK.csv, 1 of 8 directions right; 11 of 27 cumulative). The cells are carried as a record, not as a prediction this arm relies on.
  rule: -1.0 keeps the 0.25 interval of the four measured points (-2.0, -1.75, -1.5, -1.25) and steps once beyond the relaxed end. The interval is an operational choice that keeps the existing spacing; it is not proven more informative than a smaller one. This is G-A037's held value, chosen now on different evidence (see not_claimed).
  not_claimed: No score gain is estimated and no improvement is predicted. G-A037 (-1.0) was held for two reasons: its derivation (a smaller vertical-penalty share climbs more) ran against base data section 5 S5, and -1.0 lay outside the single walking value then observed. The second reason has narrowed to one interval beyond the observed range, the same distance G-A048 stepped. The first still holds - 15 cm ge2 was 77 at -1.5 and 24 at -1.25 - so this arm is not chosen by that derivation and its hypothesis does not concern the 15 cm stairs. A failure at -1.0 does not make G-A048's result luck, and a success does not identify its cause.

LEVERS NOT MOVED
  lin_vel_z_l2_to_m1: taken by this arm, on the direct evidence of G-A043 and G-A048 rather than G-A037's penalty-share derivation (value_derivation.not_claimed).
  track_lin_vel_xy_exp: held at 1.5: G-A042 raised it to 1.6 and the 10 cm two-or-more count went 43 -> 0 of 96 with posture falls 34 -> 85 (reports/GO2_G_A042_READOUT.md). The local extension of that dial is measured and closed.
  ang_vel_xy_l2: measured and closed for now in both directions on the stairs: -0.08 took the 10 cm climbed-robot count 90 -> 5 (G-A038) and the relaxation -0.04 took it 90 -> 34 with posture falls 34 -> 93 of 96 (G-A041).
  feet_air_time: held at 0.2: 0.01 and 0.1 were both rejected at stage 1 (A031, A032) and 0.35 stopped the policy (A015). It is air time, not foot height, so it does not address the tread.
  flat_orientation_l2: measured at -0.5 on this baseline (G-A047): INTERNAL_GATE_FAIL, its G3 hypothesis not supported (rough side-step falls 59 -> 60, tilt-only falls did not fall) and the policy slowed off flat ground. A smaller value has no direct evidence on the target behaviour; the 2026-09-26 policy revision withdrew its old second-place ranking.
  action_rate_l2: -0.008 is a valid rejection (A018) and reports/evidence/go2_reward_mechanism_20260917/PROBE_SITUATIONS.csv leaves climb, sway and push empty for this term, so no situation direction can be read for it.
  dof_acc_l2: G-A039 is on hold and sits outside the deployed six, which makes it dependent on open decision U1-R6-ENV-REWARD-20260918. The 2026-09-26 policy revision also withdrew its old priority.
  max_iterations: outside R-6 (not a reward weight). See notes.curriculum_lag.
  training_seed: outside R-6 until U2 is answered. The seed replicate is branch A of workspace/training/quadruped/upload/plan/GO2_NEXT_CANDIDATE_20260927.md (seed 43 pair), published only after U2 is permitted.
  track_ang_vel_z_exp: computed and set aside in the 2026-09-26 candidate comparison (workspace/training/quadruped/upload/plan/GO2_POST_A047_POLICY_20260926.md): no direct evidence on the stairs or rough behaviour, and it is not one of the six deployed names.
  lin_vel_z_l2_measured_values: -1.75, -1.5 and -1.25 are measured on seed 42 (G-A044, G-A043, G-A048) and all failed their internal gate. Repeating any of them on seed 42 adds nothing; repeating on another seed is branch A, which waits on U2.

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  No gain estimate exists and one training seed cannot
  separate the lever from seed luck.
  Pre-registered: all other axes held -- per-scenario weighted loss at most twice its own
  evaluation sd (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358), flat G1/G2 guards unchanged.

CHECKPOINT
  Evaluated at iter 900 of 1000, the iteration G-A033 was evaluated at.

VIDEOS (4 env x 500 steps)
  G2:combined_yaw_left:101   the mirror of the case that broke G-A043. Filmed so a recurrence is not read from one direction alone.
  G2:combined_yaw_right:101  the hypothesis cost indicator. G-A043 lost 29 of 96 robots here; G-A048 lost none. Filmed on the candidate; the G-A048 frames of this case left one robot's posture undetermined at 4.3-5.7 s because the body was cut by the frame edge (reports/GO2_D2_D3_GUARD_RESAMPLING_AND_A048_VIDEO_20260926.md section 3).
  G3:rough_forward:101       the rough axis the arm must hold. Stored G-A033 video, reused by SHA.
  G3:rough_lateral:101       the rough hypothesis indicator (posture falls 59 / 80 / 24 / 16 across the four measured values). Baseline reused by SHA.
  G5:stairs_10_down:101      the adoption target the climbed-robot counter and the plan screening read. Baseline reused by SHA.
  G5:stairs_15_down:101      recorded, not judged: 15 cm ge2 0 / 0 / 77 / 24. G-A048's candidate frames showed the front legs folding at the first step edge from 3 s. Baseline reused by SHA.
  G6:push_pos_x:101          the push direction the fact_rules group scores. Baseline reused by SHA.
  G6:push_neg_x:101          push protection block direction. Baseline reused by SHA.
  G6:push_pos_y:101          push protection block direction. Baseline reused by SHA from the G-A044 run.
  G6:push_neg_y:101          push protection block direction. Baseline reused by SHA from the G-A044 run.

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
