G-A052 diagnostic replay — no training, no reward change.
Replays G-A048 iter 900 on rough_lateral seed 202 (plain and diag), stairs_10_down and stairs_15_down seed 101 (diag).
Run: bash /workspace/go2_g_a052/server_run_go2_diag_replay.sh
Plan: workspace/training/quadruped/upload/plan/GO2_G_A052_DIAG_REPLAY_PLAN_20260928.md
