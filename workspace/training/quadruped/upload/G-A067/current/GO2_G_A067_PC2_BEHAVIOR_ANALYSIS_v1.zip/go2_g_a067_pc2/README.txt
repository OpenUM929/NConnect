G-A067 PC2 행동 판독 (학습 없음, GPU 없음, 보상 변경 없음)
입력: 저장소 workspace/_keep/go2_g_a066_pc2_{p0,s04,s07,s11,s13}/diag/cases/seed_{101,202,303}/{stairs_15_down,rough_lateral}/ (steps.csv, diag.csv.gz) — G-A066이 이미 올린 파일
출력: workspace/_keep/go2_g_a067_analysis/ (SUMMARY.json, PER_ENV.csv, STATUS.txt, RUN.log)
정의: go2_g_a067_behavior_analysis.py 맨 위 설명. 판독·판정은 작성 PC가 한다.
