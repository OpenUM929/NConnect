H-A001 P0 — Run06 / Run05 speed grid (no training)
Plan: workspace/training/humanoid/upload/plan/H1_STABLE_SPEED_TUNING_DEBATE_20261008.md §12, §14
Adds only h1_ha001/. play.py, train.py, h1_task/, humanoid_rewards.py, exported/ are not touched (R-6).
The runner refuses to start unless play.py matches the distributed original SHA.

Run on the cloud server (upload the ZIP to /workspace/training/humanoid first):
  cd /workspace/training/humanoid && unzip -o H_A001_P0_SPEED_GRID_v2.zip && bash h1_ha001/server_run_h1_ha001_p0.sh
Monitor: tmux attach -t h1_ha001_p0
Run on PC2 (Git Bash, no tmux): see HANDOFF_H_A001_PC2.md §2 (NO_TMUX=1, ISAACLAB_SH, nohup).
Expected time: about 30-45 min (2 policies x 9 cases x 3 seeds, 32 env x 1000 steps each).
Resume after a failure: EVAL_RESUME=1 bash h1_ha001/server_run_h1_ha001_p0.sh

Download only after [DONE]:
  /workspace/_keep/H_A001_P0_SPEED_GRID_FULL.tar.gz
  /workspace/_keep/H_A001_P0_SPEED_GRID_FULL.tar.gz.sha256
Server shutdown gate: both FULL files downloaded and sha256 verified locally. PARTIAL is not complete.
Video: NOT_REQUIRED (fixed-policy telemetry only; policies already have Run06/Run05 videos).
report.html: NOT_APPLICABLE (no training in this package).
Local readout: python -I tools/h1_ha001_p0_readout.py <extracted>/H_A001_P0_SPEED_GRID
