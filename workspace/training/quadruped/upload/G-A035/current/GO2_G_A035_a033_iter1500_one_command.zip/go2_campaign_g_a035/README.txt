GO2 G-A035 CAMPAIGN — one upload, one command, one result
=========================================================

This package TRAINS one policy and measures it.  status: exploratory.
Plan: GO2_BASIC_MOTION_TUNING_PLAN_20260915.md.

ARM (byte for byte what tools/build_go2_training_length_package.py builds)
  G-A035  max_iterations 1000 -> 1500, no reward weight changes
  arms/GO2_G_A035_a033_iter1500_staged.zip  sha256 29ca4f0bd3e3d3424d0b3c9d6e239928b9fc33109be1652e74d9715ce7c1dd76

BASELINE
  G-A033 (model ccd60e192bf4...), stored arm G-A033.
  Its summaries travel under stored_baseline/evaluation/g_a033.

RUN
  unzip -oq GO2_G_A035_a033_iter1500_one_command.zip -d /workspace
  bash /workspace/go2_campaign_g_a035/server_run_go2_campaign.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_campaign_g_a035/server_run_go2_campaign.sh

WHAT HAPPENS
  1 target stage (~115m): training 1500 iter, catastrophe gate,
    the 9 target cases, the 5 sentinel cases, the videos.
  2 go2_target_gate.py reads criterion 1; the runner takes the verdict from the gate's JSON:
      TARGET_PASS -> full stage (~55m); FAIL -> ends;
      REMEASURE_BASELINE -> target stage again with G-A033 remeasured, gate again;
      UNDECIDED -> no full stage.
  3 one result ZIP.  The gate only schedules GPU time; the local verifier
    (tools/verify_go2_basic_motion_harvest.py) decides every verdict.

CHECKPOINT
  The candidate is evaluated at iter 1450, the last checkpoint save_interval guarantees
  for 1500 iterations.  G-A033 was evaluated at iter 900 of 1000.

DOWNLOAD
  /workspace/_keep/GO2_G_A035_CAMPAIGN_RESULT.zip
  /workspace/_keep/GO2_G_A035_CAMPAIGN_RESULT.zip.sha256
  Finish marker: [DONE] GO2_G_A035_CAMPAIGN_RESULT_READY
  Official results remain OFFICIAL_RESULT_UNMEASURED.
