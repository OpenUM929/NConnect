G-A063 PC2 batch point s03_lin_vel_z_l2_m2: 부모 P0 위 lin_vel_z_l2 -1.25 -> -2. 서버 A033 값을 P0 기준으로 재측정.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
