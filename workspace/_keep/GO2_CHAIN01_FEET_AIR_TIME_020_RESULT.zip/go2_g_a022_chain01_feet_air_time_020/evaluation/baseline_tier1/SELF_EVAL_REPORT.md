# Go2 internal self evaluation

- status: INTERNAL_GATE_FAIL
- telemetry: 7/7
- simulation proxy: 18.611/70 (not official)

| G | survival | tracking | proxy | worst case | gate |
|---|---:|---:|---:|---|---|
| G1 | 1.0000 | 0.0036 | 0.0036 | forward_fast@101 | INTERNAL_SCENARIO_FAIL |
| G2 | 1.0000 | 0.2672 | 0.2672 | diagonal_left@101 | INTERNAL_SCENARIO_FAIL |
| G3 | 0.8438 | 0.3818 | 0.3222 | rough_forward@101 | INTERNAL_SCENARIO_FAIL |
| G4 | 1.0000 | 0.3819 | 0.3819 | slope_plus_20@101 | INTERNAL_SCENARIO_FAIL |
| G5 | 1.0000 | 0.0319 | 0.0319 | stairs_15_up@101 | INTERNAL_SCENARIO_FAIL |
| G6 | 1.0000 | 0.9634 | 0.9634 | push_pos_x@101 | INTERNAL_SCENARIO_PASS |
| G7 | 0.0625 | 0.3842 | 0.0240 | dr_seed_101@101 | INTERNAL_SCENARIO_FAIL |

Official evaluator details remain unknown; this is INTERNAL_PROXY_SPEC v1.
