G-A011  Go2 terrain curriculum, 5,000 iterations
================================================

WHAT THIS RUN ASKS
  Pilot-01 reached terrain curriculum level 3.94 after 1,000 iterations.  The
  exam terrain needs about level 5.0 for 15 cm stairs (G5) and 7.9 for +-20
  degree slopes (G4).  The single question here is whether that gap closes with
  more iterations or not.  Reward weights are therefore byte-identical to
  Pilot-01: the only variable is training length.

WHAT ELSE COMES BACK FOR FREE
  * a tier-1 score curve at iterations 1000 / 2000 / 3000 / 4000
  * a full 69-case suite on frozen Pilot-01 under the NEW evaluator, which is
    the v2 baseline the campaign does not currently have

EVALUATOR CHANGE (read before comparing to older numbers)
  survival_proxy used to be 1 - terminated/num_envs, so a Go2 lying belly-down
  scored 1.00 as long as no termination fired.  Re-scoring the archived results
  showed every Default-lineage policy dropping from 1.000 to 0.000 on flat
  ground.  survival_proxy is now posture-gated: upright means gravity still
  points down through the base (<= 60 deg tilt) AND the base is >= 0.18 m above
  the terrain directly beneath it, sustained for 0.5 s before a fall is called.
  Old numbers remain readable as survival_proxy_v1.  Numbers from this package
  are NOT comparable to pre-v2 numbers except through pilot_v2.

RUN IT
  unzip go2_terrain_5k_v1.zip -d /workspace
  bash /workspace/go2_terrain_5k_v1/server_run_go2_terrain_5k_v1.sh

  Starts a tmux session and returns immediately.  Watch it with
      tmux attach -t go2_terrain_5k_v1
  Re-running with GO2_RESUME=1 skips work already verified on disk.

COST (measured on this server: 3.86 s/iter at 4096 envs)
  training 5,000 iter   ~5h 20m
  ladder + two suites   ~1h 20m
  total                 ~6h 40m

DOWNLOAD WHEN DONE
  /workspace/_keep/GO2_TERRAIN_5K_RESULT.zip
  /workspace/_keep/GO2_TERRAIN_5K_RESULT.zip.sha256
  Marker line: [DONE] GO2_TERRAIN_5K_RESULT_READY

PRE-REGISTERED VERDICT (fixed before the run, do not renegotiate after)
  PRIMARY   Curriculum/terrain_levels at 5,000 iterations
              >= 7.0        terrain was an iteration problem -> move to reward
                            refinement for stair descent
              5.5 to 7.0    partial; extend only if the ladder is still rising
              <= 5.5        not an iteration problem -> reward / curriculum work
  SECONDARY survival_proxy_v2 >= 0.95 on G1, G2, G6 (guards the new gate)
            G3, G4, G5 scenario proxy above pilot_v2 on the same evaluator
  VIDEO     7 scenario videos; a policy parked on a stair top platform is a
            fail regardless of its survival number
