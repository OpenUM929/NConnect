GO2 G-A058 보상 무변경 재학습 — 다른 PC 실행 안내
================================================

목적: G-A057 나머지 11행보다 먼저 세 학습을 돈다. 보상은 바꾸지 않는다.
  a048_seed42  A048 보상, 학습 seed 42 — 다른 PC의 동일 보상 비교 기준(효과 판정 문턱 아님)
  a043_seed43  A043 보상, 학습 seed 43 — 계단 이득 재현·우회전 결함 분리
  a043_seed44  A043 보상, 학습 seed 44 — 같음
근거: workspace/training/quadruped/upload/plan/GO2_OTHER_PC_SEQUENCE_PROPOSAL_20260930.md

환경·실패 처리·회수는 G-A057 안내(GO2_G_A057_RUN_GUIDE.txt)와 같다. 러너는 G-A055 v2 바이트 그대로다.

1. 올리기: GO2_G_A058_replicate_a048s42_a043s43s44_v1.zip  SHA256 (발행 시 기록)  → /workspace/GO2_G_A058_replicate_a048s42_a043s43s44_v1.zip
2. 실행 — 한 줄
   unzip -oq /workspace/GO2_G_A058_replicate_a048s42_a043s43s44_v1.zip -d /workspace && bash /workspace/go2_g_a058/run_sweep.sh
   목록만: bash /workspace/go2_g_a058/run_sweep.sh --list    진행: tmux attach -t go2_g_a058
   상태 표: /workspace/_keep/go2_g_a058_sweep/SWEEP_STATUS.tsv   재개: 같은 명령을 다시 친다.
3. 예상: 서버 GPU 기준 한 실행 약 90~95분, 세 실행 약 4.5~5시간. 다른 GPU에서는 달라진다.
4. 끝나면 G-A057을 이어서 돈다: bash /workspace/go2_g_a057/run_sweep.sh (완료 행은 SKIP_DONE).
5. 가져올 것: /workspace/_keep/go2_g_a058_<key>/ 폴더 전체, GO2_G_A058_<KEY>_RESULT.zip + .sha256,
   /workspace/_keep/go2_g_a058_sweep/ → 로컬 C:\dev\Nconnect\workspace\_keep\ 에 같은 이름으로 복사.
6. 규정: 다른 PC 학습은 탐색용이다. 제출 정책은 서버에서 다시 학습한다. 배포 학습 코드는 수정하지 않았다.
