GO2 PILOT-01 v2 BASELINE  (work id G-A012)
==========================================

This package trains NOTHING.  It measures.

WHY
  Prelim rule 8 scores each scenario as  survival x tracking,  and defines
  survival as "the share that finished WITHOUT FALLING" -- not as "no
  termination event fired".  The campaign's evaluator used the second
  definition until 260902, which counted a Go2 lying on its belly as alive.

  Re-scoring the archived flat-ground results with a posture gate (no GPU)
  moved every Default-lineage policy from survival 1.000 to 0.000 and left
  Pilot-01 unchanged at 1.000.  Pilot-01 is therefore the only Go2 policy
  known to actually walk.

  Rule 7 puts 0.60 of the Go2 weight on terrain -- G3 rough 0.20, G4 slope
  0.15, G5 stairs 0.15, G7 DR 0.10 -- and Pilot-01 has never been measured
  there with a valid survival metric.  Training again before that is known
  would be buying an answer to a question we cannot yet ask.

WHAT IT DOES
  1  frozen Pilot-01, all 69 G1-G7 cases, seeds 101/202/303, posture-gated
  2  one video per scenario G1-G7, so the numbers have a witness
  3  one-file result ZIP

  Cost: about 1h05m of the remaining budget.  No training happens, so nothing
  about the submission candidate changes -- this run cannot damage it.

RUN
  unzip go2_pilot_v2_baseline.zip -d /workspace
  bash /workspace/go2_pilot_v2_baseline/server_run_go2_pilot_v2_baseline.sh

  It starts inside tmux and returns immediately.
  Finish marker:  [DONE] GO2_PILOT_V2_BASELINE_RESULT_READY

DOWNLOAD
  /workspace/_keep/GO2_PILOT_V2_BASELINE_RESULT.zip
  /workspace/_keep/GO2_PILOT_V2_BASELINE_RESULT.zip.sha256

GATES BUILT INTO THE RUNNER
  - the staged policy SHA must equal the frozen Pilot-01 SHA, or it aborts
  - every case summary must carry survival_proxy_source = posture_gate_v2,
    or that case FAILS rather than being banked on the old metric
  - all 69 cases and all 7 videos must exist before packaging

PRE-REGISTERED READING (fixed before the run, not renegotiated after)
  Primary output is the first true G1-G7 scorecard for Go2.  The single
  largest weighted point loss in that scorecard selects the one reward
  variable for the next training run.  No other selection rule is admitted.
  Terrain curriculum level is NOT a target: rule 7 states that step climbing
  is not required of Go2, and G5 asks only for 10-15 cm stairs.
