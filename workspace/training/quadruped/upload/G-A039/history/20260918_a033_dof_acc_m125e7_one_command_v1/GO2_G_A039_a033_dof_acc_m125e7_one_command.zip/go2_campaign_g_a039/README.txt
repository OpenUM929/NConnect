GO2 G-A039 CAMPAIGN — one upload, one command, one result
=========================================================

This package TRAINS one policy and measures it.  status: exploratory.
Plan: GO2_REWARD_MECHANISM_FORECAST.md.

ARM (byte for byte what tools/build_go2_training_length_package.py builds)
  G-A039  dof_acc_l2 -2.5e-07 -> -1.25e-07, no reward weight changes
  arms/GO2_G_A039_a033_dof_acc_m125e7_staged.zip  sha256 65730856cc980eba74fa70fdc00fca9e930c47183300509dc075e404e1b4ad09

BASELINE
  G-A033 (model ccd60e192bf4...), stored arm G-A033.
  Its summaries travel under stored_baseline/evaluation/g_a033.

RUN
  unzip -oq GO2_G_A039_a033_dof_acc_m125e7_one_command.zip -d /workspace
  bash /workspace/go2_campaign_g_a039/server_run_go2_campaign.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_campaign_g_a039/server_run_go2_campaign.sh

WHAT HAPPENS
  1 target stage (~90m): training 1000 iter, catastrophe gate,
    the 9 target cases, the 5 sentinel cases, the videos.
  2 go2_target_gate.py reads criterion 1; the runner takes the verdict from the gate's JSON:
      TARGET_PASS -> full stage (~55m); FAIL -> ends;
      REMEASURE_BASELINE -> target stage again with G-A033 remeasured, gate again;
      UNDECIDED -> no full stage.
  3 one result ZIP.  The gate only schedules GPU time; the local verifier
    (tools/verify_go2_basic_motion_harvest.py) decides every verdict.

CHECKPOINT
  The candidate is evaluated at iter 900, the last checkpoint save_interval guarantees
  for 1000 iterations.  G-A033 was evaluated at iter 900 of 1000.

DOWNLOAD
  /workspace/_keep/GO2_G_A039_CAMPAIGN_RESULT.zip
  /workspace/_keep/GO2_G_A039_CAMPAIGN_RESULT.zip.sha256
  Finish marker: [DONE] GO2_G_A039_CAMPAIGN_RESULT_READY
  Official results remain OFFICIAL_RESULT_UNMEASURED.
