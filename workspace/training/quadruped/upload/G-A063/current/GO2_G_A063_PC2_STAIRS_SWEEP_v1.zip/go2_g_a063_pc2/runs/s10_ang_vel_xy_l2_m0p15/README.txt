G-A063 PC2 batch point s10_ang_vel_xy_l2_m0p15: 부모 P0 위 ang_vel_xy_l2 -0.05 -> -0.15. 범위 중간.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
