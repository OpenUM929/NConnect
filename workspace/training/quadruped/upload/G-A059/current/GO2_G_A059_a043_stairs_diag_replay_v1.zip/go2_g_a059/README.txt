G-A059 A043 stairs diagnostic replay — no training, no reward change.
Replays G-A043 iter 900 on stairs_15_down and stairs_10_down seed 101 (plain and diag), then films
four robots on stairs_15_down with the viewer pinned to their env index.
Run: bash /workspace/go2_g_a059/server_run_go2_a043_stairs_diag_replay.sh
Plan: workspace/training/quadruped/upload/plan/GO2_G_A059_A043_STAIRS_DIAG_PLAN_20261001.md
