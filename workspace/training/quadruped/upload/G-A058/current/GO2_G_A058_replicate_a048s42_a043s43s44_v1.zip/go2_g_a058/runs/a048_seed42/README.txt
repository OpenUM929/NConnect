G-A058 replicate arm a048_seed42
A048 학습 보상 그대로(보상 변경 없음), 학습 seed 42, 4096 env, 1000 iter, 평가 iter 900, 69 case.
이 폴더는 run_sweep.sh 가 펼쳐서 쓴다. 혼자 실행하지 않는다. 다른 PC 결과는 탐색용이며 제출 후보가 아니다.
