GO2 G-A051 REWARD CHANGE ON G-A048 REWARDS — ang_vel_xy_l2 -0.05 -> -0.06
=========================================================================

This package TRAINS one policy and then measures it.  status: exploratory.
One upload, one command, one result ZIP: the whole 69-case evaluation runs in a single
pass (run_config.env pins GO2_STAGE=full), so there is no target stage and no server gate.
  unzip -oq <this zip> -d /workspace
  bash /workspace/go2_g_a051/server_run_go2_candidate_iter_pinned.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_g_a051/server_run_go2_candidate_iter_pinned.sh

WHAT CHANGES
  Exactly one reward weight on G-A048's trained rewards: ang_vel_xy_l2 -0.05 -> -0.06.
  candidate/quadruped_rewards.py and reference/reward_base_quadruped_rewards.py differ in that line only.
  Against the adoption baseline G-A033 two weights differ: lin_vel_z_l2 -2.0 -> -1.25
  (G-A048's own change) and this one; reference/baseline_quadruped_rewards.py is G-A033's.
  Effects are read as candidate - G-A048; adoption is judged against G-A033.
  Training length, seed and env count are G-A033's (and G-A048's).

WHY (analysis GO2_G_A051_PLAN_20260927.md)
  Purpose: cut G3 rough side-step rollovers on G-A048's rewards while keeping G-A048's gains (total 50.16, rough falls 16, 10 cm ge2 90, combined-turn falls 0, push falls 1). Not a promise of a higher score.
  Support: G-A038 (-0.05 -> -0.08 on G-A033) cut rough side-step falls 59 -> 18 and raised its 9-case target proxy by 0.088.
  Against: the same run collapsed the 10 cm climb (96 falls) and slowed rough side-stepping; both results are mixed with a terrain-level lag. The step is a third of G-A038's.
  Selection by Codex (relayed by the user); package and records by the main loop.

HOW THE VALUE WAS CHOSEN
  source: workspace/training/quadruped/upload/plan/GO2_G_A051_PLAN_20260927.md sections 1-3; reports/GO2_G_A038_READOUT.md; reports/evidence/go2_next_lever_20260927/CASE_ROWS.csv; reports/evidence/go2_next_lever_20260927/FALL_CHANNELS.csv; reports/evidence/go2_next_lever_20260927/AXIS.csv; reports/runs/TERRAIN_AT_PIN.csv
  role: Penalize xy-axis base angular velocity using L2 squared kernel (Isaac Lab v2.3.1, reports/evidence/go2_reward_term_roles_20260917/isaaclab_envs_mdp_rewards.py:83): -w * (omega_x^2 + omega_y^2) in the body frame. It charges roll/pitch rate, not tilt and not a fall.
  walk_margin: G-A033 walk margin +0.1359 -> +0.133 for the candidate rewards (go2_reward_mechanism.spec_margin, zone WALK, about eight times the stop zone's top +0.0155).
  situations: spec_margin situations for the candidate rewards: climb +0.0351, sway +0.0372, push -0.0067. The sheet's sway cell got the direction wrong on this baseline before (G-A047, G-A048); it is recorded, not used as a prediction.
  rule: -0.06 is +20 percent of the penalty, one third of G-A038's +60 percent step to -0.08. The width is limited because G-A038 collapsed the 10 cm climb; it is a design choice, not a measured safe value, and no data says -0.06 beats -0.055 or -0.065.
  not_claimed: No score gain is estimated. G-A038's 18 rough side-step falls are more than G-A048's 16, so G-A038 does not say G-A048 will improve. Both G-A038 results are mixed with a terrain-level lag (iteration 900: 4.4937 against 1.9499).

LEVERS NOT MOVED
  ang_vel_xy_l2_relax: -0.04 (G-A041) on G-A033: 10 cm posture falls 34 -> 93 of 96, and relaxing runs against the rough gain seen when strengthening.
  ang_vel_xy_l2_m008: not reused: G-A038's 10 cm climb collapsed to 96 falls of 96 and its rough side-step speed fell (0.162 / 0.159 / 0.149 against 0.200 / 0.195 / 0.190 m/s).
  track_lin_vel_xy_exp: held at 1.5: G-A042 raised it to 1.6 and the 10 cm two-or-more count went 43 -> 0 of 96.
  lin_vel_z_l2: held at G-A048's -1.25: the single-term search closed after six measured points, all counters non-monotone (G-A050 readout).
  feet_air_time: held at 0.2: its formula rewards air time at touchdown, not foot height; the link to the failure is indirect and 0.35 stopped the policy (A015).
  action_rate_l2: no observation ties the rough falls or the stairs failure to action rate, and no strengthening result exists.
  flat_orientation_l2: -0.5 (G-A047) lost the climb (10 cm ge1 90 -> 3) and left rough side-step falls at 60/96.
  dof_acc_l2: outside the deployed six; depends on open decision U1-R6-ENV-REWARD-20260918.
  max_iterations: training-length comparison is on hold by user decision; not used as a reason for this choice.
  training_seed: outside R-6 until U2 is answered; not used as a reason for this choice.

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  No gain estimate exists and one training seed cannot
  separate the lever from seed luck.
  Pre-registered: all other axes held -- per-scenario weighted loss at most twice its own
  evaluation sd (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358), flat G1/G2 guards unchanged.

CHECKPOINT
  Evaluated at iter 900 of 1000, the iteration G-A033 was evaluated at.

VIDEOS (4 env x 500 steps)
  G2:combined_yaw_left:101   the mirror of the case that broke G-A043. Filmed so a recurrence is not read from one direction alone.
  G2:combined_yaw_right:101  combined-turn protection: G-A043 lost 29 of 96 here; G-A048 lost none. Filmed on the candidate.
  G3:rough_forward:101       the rough axis the arm must hold. Stored G-A033 video, reused by SHA.
  G3:rough_lateral:101       the target: rough side-step posture falls G-A033 59, G-A038 18, G-A048 16 (10 of them terminated only). Baseline reused by SHA.
  G5:stairs_10_down:101      the known cost of this dial: G-A038 fell 96 of 96 here. Baseline reused by SHA.
  G5:stairs_15_down:101      stairs protection case (15 cm climb): posture falls 90 at baseline, limit 93 under g3_guard_margin_v1. Baseline reused by SHA.
  G6:push_pos_x:101          the push direction the fact_rules group scores. Baseline reused by SHA.
  G6:push_neg_x:101          push protection block direction. Baseline reused by SHA.
  G6:push_pos_y:101          push protection block direction. Baseline reused by SHA from the G-A044 run.
  G6:push_neg_y:101          push protection block direction. Baseline reused by SHA from the G-A044 run.

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
