GO2 G-A030 CANDIDATE SUITE — A017 + flat_orientation_l2 0.0 -> -1.0
==========================================================================

This package TRAINS one policy and then measures it.  status: exploratory.

WHAT CHANGES
  The baseline is A017 (Pilot-01 + track_lin_vel_xy_exp 1.4), 39.76/70 on the
  69-case internal proxy (G-A027).  The candidate changes one reward only:
  flat_orientation_l2 0.0 -> -1.0.  Deployed train/play/task code is unchanged
  (R-6); only candidate/quadruped_rewards.py carries the new value.

WHY (plan GO2_G_A030_TUNING_PLAN_20260914.md)
  A017 loses 9.03/70 on G3, and G3's floor is rough_lateral, whose survival
  loss is entirely base-contact terminations (17/14/17 of 32).  In the 0.5 s
  before a termination the body tilt q = 1 - g_z^2 is 23-46x that of surviving
  robots in the same window, and already 5-12x one window earlier.  That is a
  reason to target this behaviour, not an established cause: slipping first
  and tilting after (H-B) is not excluded.

PHASES
  1  training, seed 42, 4096 envs, 1000 iter; report.html kept
  2  catastrophe gate: non-finite training loss, or a stationary candidate on
     G1:forward_nominal:101, stops the run here (one witness video)
  3  candidate 69-case suite, seeds 101/202/303, posture_gate_v2
  4  baseline: 5 sentinel cases re-measured against the stored G-A027 arm, or
     all 69 with GO2_REMEASURE_BASELINE=1
  5  12 candidate videos + 2 baseline videos
  6  one-file result ZIP

RUN
  unzip GO2_G_A030_flat_orientation_m1.zip -d /workspace
  bash /workspace/go2_g_a030/server_run_go2_candidate_suite.sh
  Finish marker: [DONE] GO2_G_A030_RESULT_READY

DOWNLOAD
  /workspace/_keep/GO2_G_A030_RESULT.zip
  /workspace/_keep/GO2_G_A030_RESULT.zip.sha256

PRE-REGISTERED READING (plan section 6, fixed before the run)
  success needs all of:
   1 rough_lateral survival up >= 0.1 on EACH of seeds 101/202/303
     (termination count and posture-gate fall count are read separately;
      only fewer terminations counts as support for H-A)
   2 total internal proxy +1.0/70 or more, same evaluator
   3 no case loses more than 0.03125 survival or 0.02 tracking;
     slope_plus_20 posture falls rise by at most 1 per seed
   4 POLICY_LOCOMOTES and no more stationary cases than the baseline
   5 videos show normal four-legged walking (human reading)
  The expected weighted gain is NOT estimated.  +1.0/70 is a criterion, not a
  forecast.  A failure keeps A017 and does not retry -0.5 or -2.0 automatically.
  Official results remain OFFICIAL_RESULT_UNMEASURED.
