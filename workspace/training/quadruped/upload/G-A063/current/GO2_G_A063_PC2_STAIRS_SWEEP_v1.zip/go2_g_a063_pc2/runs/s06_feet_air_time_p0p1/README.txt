G-A063 PC2 batch point s06_feet_air_time_p0p1: 부모 P0 위 feet_air_time 0.2 -> 0.1. 범위 내 하단.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
