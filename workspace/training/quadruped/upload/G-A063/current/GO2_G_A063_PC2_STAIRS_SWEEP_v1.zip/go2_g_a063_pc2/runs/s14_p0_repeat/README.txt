G-A063 PC2 batch point s14_p0_repeat: 부모 P0 위 lin_vel_z_l2 -1.25 -> -1.25. P0 그대로 재학습. 같은 PC·같은 seed 학습 흔들림 측정(스윕 차이 해석 기준).
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
