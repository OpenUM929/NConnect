G-A061 PC2 tree node n5_dof_acc_l2_m1p25e_7: 부모 P0 위 dof_acc_l2 -2.5e-07 -> -1.25e-07. 학습 seed 42, 4096 env, 1000 iter, 평가 iter 900, 69 case.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
