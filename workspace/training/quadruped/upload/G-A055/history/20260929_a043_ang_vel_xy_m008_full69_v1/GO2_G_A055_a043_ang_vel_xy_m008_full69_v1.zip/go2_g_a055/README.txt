GO2 G-A055 REWARD CHANGE ON G-A043 REWARDS — ang_vel_xy_l2 -0.05 -> -0.08
=========================================================================

This package TRAINS one policy and then measures it.  status: exploratory.
One upload, one command, one result ZIP: the whole 69-case evaluation runs in a single
pass (run_config.env pins GO2_STAGE=full), so there is no target stage and no server gate.
  unzip -oq <this zip> -d /workspace
  bash /workspace/go2_g_a055/server_run_go2_candidate_iter_pinned.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_g_a055/server_run_go2_candidate_iter_pinned.sh

WHAT CHANGES
  Exactly one reward weight on G-A043's trained rewards: ang_vel_xy_l2 -0.05 -> -0.08.
  candidate/quadruped_rewards.py and reference/reward_base_quadruped_rewards.py differ in that line only.
  Against the adoption baseline G-A033 two weights differ: lin_vel_z_l2 -2.0 -> -1.5
  (G-A043's own change) and this one; reference/baseline_quadruped_rewards.py is G-A033's.
  Effects are read as candidate - G-A043; adoption is judged against G-A033.
  Training length, seed and env count are G-A033's (and G-A043's).

WHY (analysis GO2_G_A055_PLAN_20260928.md)
  Purpose: cut G-A043's first-priority losses (combined right turn 29 falls, rough side-step 24, push 10) while keeping its stairs lead (G5 1.62, 15 cm ge2 77). Not a promise of a higher score.
  Support: the lecture's 'do not tilt the body' and the deployed 'strong: less wobble'; G-A038 (-0.08 on G-A033) cut rough side-step falls 59 -> 18.
  Against: G-A038 slowed rough side-stepping and collapsed the 10 cm climb (96 of 96); G-A041 (-0.04) also collapsed it (93 of 96), so the stairs cost is not direction-specific. Why G-A043 starts to tilt is not explained; in some rough events a lateral-velocity change was observed before the tilt increase (reports/GO2_A043_TILT_ONSET_20260928.md).
  Status: conditional preparation, execution not approved (Codex 2026-09-29). Not linked to G-A056.

HOW THE VALUE WAS CHOSEN
  source: workspace/training/quadruped/upload/plan/GO2_G_A055_PLAN_20260928.md sections 1-2; reports/GO2_ANG_VEL_XY_A043_REVIEW_20260928.md; reports/GO2_A043_DEDUCTIONS_20260928.md; reports/GO2_LECTURE_REWARD_REFERENCE.md
  role: Penalize xy-axis base angular velocity using L2 squared kernel (Isaac Lab v2.3.1, reports/evidence/go2_reward_term_roles_20260917/isaaclab_envs_mdp_rewards.py:83): -w * (omega_x^2 + omega_y^2) in the body frame. It charges roll/pitch rate, not tilt and not a fall.
  walk_margin: G-A043 rewards -> candidate rewards: walk margin +0.0849 for the candidate (go2_reward_mechanism.spec_margin, zone WALK, about 5.5 times the stop zone's top +0.0155).
  situations: spec_margin situations for the candidate rewards: climb +0.015, sway +0.276, push +0.115. The sheet's cells got directions wrong on this baseline before (G-A047, G-A048); they are recorded, not used as predictions.
  rule: -0.08 is chosen because it is the strengthening value actually measured on a walking reference policy (G-A038 on G-A033); being the deployed start value and the lecture example is supporting only. It is not claimed to be the only possible value or an optimum, and no data says -0.08 beats -0.06 or -0.10 on G-A043.
  not_claimed: No score gain is estimated. Why G-A043 starts to tilt and why it does not recover is not explained (principle step 2 unmet); the G-A056 diagnostic replay is the open work on that question. G-A038's rough gain came with a terrain-level difference at iteration 900 (G-A033 4.4937, G-A038 1.9499), so its mechanism is not separated.

LEVERS NOT MOVED
  ang_vel_xy_l2_relax: -0.04 (G-A041) on G-A033: 10 cm posture falls 34 -> 93 of 96, and relaxing runs against the rough gain seen when strengthening.
  track_lin_vel_xy_exp: held at 1.5: G-A042 raised it to 1.6 and the 10 cm two-or-more count went 43 -> 0 of 96.
  lin_vel_z_l2: held at G-A043's -1.5: the single-term search on the relaxing side closed after six measured points (reports/GO2_REWARD_TRIAL_REFERENCE.md).
  feet_air_time: held at 0.2: 0.25 (proposed as G-A054) was rejected; its formula rewards air time at touchdown, not foot height, and 0.35 stopped the policy (A015).
  action_rate_l2: no observation ties the rough falls or the stairs failure to action rate, and no strengthening result exists.
  flat_orientation_l2: -0.5 (G-A047) lost the climb (10 cm ge1 90 -> 3) and left rough side-step falls at 60/96.
  dof_acc_l2: G-A053 (-3.0e-7 on G-A048) was published but its execution recommendation was withdrawn (reports/GO2_G_A053_PRINCIPLE_REVIEW_20260928.md).
  max_iterations: training-length comparison is on hold by user decision; not used as a reason for this choice.
  training_seed: outside R-6 until U2 is answered; not used as a reason for this choice.
  ang_vel_xy_l2_m006_on_a048: G-A051 (-0.06 on G-A048) was never run; its execution recommendation was withdrawn.

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  No gain estimate exists and one training seed cannot
  separate the lever from seed luck.
  Pre-registered: all other axes held -- per-scenario weighted loss at most twice its own
  evaluation sd (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358), flat G1/G2 guards unchanged.

CHECKPOINT
  Evaluated at iter 900 of 1000, the iteration G-A033 was evaluated at.

VIDEOS (4 env x 500 steps)
  G2:combined_yaw_left:101   the mirror of the case that broke G-A043. Filmed so a recurrence is not read from one direction alone.
  G2:combined_yaw_right:101  first-priority case: G-A043 lost 29 of 96 here (9 / 9 / 11); G-A048 lost none. Filmed on the candidate.
  G3:rough_forward:101       the rough axis the arm must hold. Stored G-A033 video, reused by SHA.
  G3:rough_lateral:101       first-priority case: rough side-step posture falls G-A043 24 (8 / 11 / 5), G-A033 59, G-A038 18. Baseline reused by SHA.
  G5:stairs_10_down:101      second-priority protection: G-A038 fell 96 of 96 here and G-A041 (the relaxing direction) 93 of 96. Baseline reused by SHA.
  G5:stairs_15_down:101      stairs protection case (15 cm climb): posture falls 90 at baseline, limit 93 under g3_guard_margin_v1. Baseline reused by SHA.
  G6:push_pos_x:101          the push direction the fact_rules group scores. Baseline reused by SHA.
  G6:push_neg_x:101          push protection block direction. Baseline reused by SHA.
  G6:push_pos_y:101          push protection block direction. Baseline reused by SHA from the G-A044 run.
  G6:push_neg_y:101          push protection block direction. Baseline reused by SHA from the G-A044 run.

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
