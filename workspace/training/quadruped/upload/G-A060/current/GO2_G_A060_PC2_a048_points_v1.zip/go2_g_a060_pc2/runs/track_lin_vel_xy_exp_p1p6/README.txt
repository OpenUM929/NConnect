G-A060 PC2 point track_lin_vel_xy_exp_p1p6
A048 보상 위 track_lin_vel_xy_exp 1.5 -> 1.6. 학습 seed 42, 4096 env, 1000 iter, 평가 iter 900, 69 case.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. 혼자 실행하지 않는다. PC 결과는 탐색용이며 제출 후보가 아니다.
