G-A063 PC2 batch point s02_lin_vel_z_l2_m3: 부모 P0 위 lin_vel_z_l2 -1.25 -> -3. 배포 시작값·강좌 예시 강한 쪽.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
