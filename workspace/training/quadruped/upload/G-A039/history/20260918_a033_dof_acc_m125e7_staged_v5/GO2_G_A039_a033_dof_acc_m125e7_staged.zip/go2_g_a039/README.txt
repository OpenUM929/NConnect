GO2 G-A039 REWARD CHANGE ON G-A033 — dof_acc_l2 -2.5e-07 -> -1.25e-07
=====================================================================

This package TRAINS one policy and then measures it.  status: exploratory.
It is one arm of a campaign; do not run it on its own (see the campaign guide).

WHAT CHANGES
  Exactly one reward weight: dof_acc_l2 -2.5e-07 -> -1.25e-07.
  candidate/quadruped_rewards.py and reference/baseline_quadruped_rewards.py differ in that line only.
  Training length, seed, env count and every other weight are G-A033's.

WHY (analysis GO2_REWARD_MECHANISM_FORECAST.md)
  Goal: every axis high while stairs rise. G-A033 loses most on G5 (stairs, 10.46) and G3 (rough side-step, 9.77).
  Role first (Isaac Lab formula, reports/evidence/go2_reward_term_roles_20260917/isaaclab_envs_mdp_rewards.py:163): dof_acc_l2 charges squared joint acceleration -- the cost of lifting a foot fast.
  Measured in our own logs: walking runs pay 672000-912000 raw, stopped runs 224000-532000. It is the price of moving.
  It is the largest single penalty the frozen baseline pays (-0.228) and the one weight never moved in 18 trainings.
  Walk margin: halving gives +0.2060, the largest rise of any probe, and the walking zone ends far away at -4.64717e-07.
  Unknown named in advance: the evaluation records carry no joint columns, so sway and push directions are not predicted.
  Levers not moved: each of the other six deployed names is closed by a measured rejection or a contradicted principle.
  Risks pre-registered under fact_rules_v1: climbed-robot floors, per-scenario loss limits, flat guards, stationary guard.

HOW THE VALUE WAS CHOSEN
  source: reports/GO2_REWARD_MECHANISM_FORECAST.md sections 1, 7 and 8-5; evidence reports/evidence/go2_reward_mechanism_20260917/ (PROBES.csv, TERM_VALUES.csv); reports/GO2_TUNING_BASE_DATA.md sections 0-1 and 1; reports/runs/TERRAIN_AT_PIN.csv
  role: Penalize joint accelerations on the articulation using L2 squared kernel (Isaac Lab v2.3.1, isaaclab_envs_mdp_rewards.py:163): the cost of changing joint speed, that is, of lifting a foot fast.
  walk_margin: G-A033 walk margin +0.1359 -> +0.2060 at -1.25e-07 (WALK), the largest rise of any probe in PROBES.csv; the walking zone ends at weight -4.64717e-07, so halving moves away from the edge, not toward it. Doubling instead (-5e-07) gives -0.0043, the stop zone: the term controls walking strongly in both directions.
  situations: PROBE_SITUATIONS.csv leaves climb, sway and push empty for this term: the evaluation records carry no joint columns (forecast section 5-1). The situation direction is taken from the role and from the TERM_VALUES.csv raw values, not from a situation margin.
  rule: half, not a smaller step: the probe grid in PROBES.csv holds half and double, half is the only probed value that stays in the walking zone, and no run has ever moved this term (range_status NEVER_CHANGED), so there is no observed range a fraction could sit inside. Half keeps the same order of magnitude as Isaac Lab.
  not_claimed: No score gain is estimated. The margins are reward arithmetic on measured behaviour; they say the reward charges the walking and climbing gait less, not how many robots will climb a step.

LEVERS NOT MOVED
  track_lin_vel_xy_exp: held at 1.5: rough side-step terminations rose on every raise (31 -> 48 -> 58, stairs analysis 9)
  feet_air_time: held at 0.2: 0.01 and 0.1 were both rejected at stage 1 (A031, A032) and 0.35 stopped the policy (A015)
  lin_vel_z_l2: G-A037 is HOLD_CONTRADICTED: -1.0 is outside the observed walking range and its principle came out reversed in base data S5
  ang_vel_xy_l2: G-A038 ran -0.08 and the 10cm climb collapsed (90 -> 5 robots with at least one step)
  action_rate_l2: -0.008 is in the rejected history (A018) and is the one term the walk margin does not explain
  flat_orientation_l2: MASTER 1-b D-1 argues against it and it charges every slope and stair constantly
  dof_torques_l2: the same measurement gap as dof_acc but a smaller share of the walking cost (-0.054 against -0.140, forecast section 1); one term at a time
  max_iterations: outside R-6 (not a reward weight) and without a score basis: TERRAIN_AT_PIN.csv shows the frozen baseline decelerating (4.4937 at 900 -> 4.7087 at 999)
  training_seed: outside R-6; a seed replicate buys interpretation, not score (GO2_SEED_SENSITIVITY.md section 5)

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  No gain estimate exists and one training seed cannot
  separate the lever from seed luck.
  Pre-registered: all other axes held -- per-scenario weighted loss at most twice its own
  evaluation sd (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358), flat G1/G2 guards unchanged.

CHECKPOINT
  Evaluated at iter 900 of 1000, the iteration G-A033 was evaluated at.

VIDEOS (4 env x 500 steps)
  G5:stairs_10_down:101      the step-up this lever aims at. No stored G-A033 video, so the baseline is rendered here.
  G5:stairs_15_down:101      the 15cm step where every policy stalls in front of the first tread. The stored G-A033 video is stairs_15_up (descending), so the climbing case is rendered here.
  G4:slope_plus_20:101       G-A033 climbs the slope to the end; guard against losing it (stored baseline video).
  G3:rough_forward:101       rough forward walking: a cheaper joint acceleration may loosen the gait on uneven ground (stored baseline video).

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
