GO2 G-A063 PC2 일괄 실행 — 계단 집중 범위 스윕(track 1.5 고정) 14점 (설계 workspace/training/quadruped/upload/plan/GO2_PC2_STAIRS_RANGE_SWEEP_20261004.md)
==================================================
점(실행 순서). 모든 점의 부모 P0 = PC2 A048(G-A060 B1, track 1.5). s14 는 P0 그대로 재학습:
   1. s01_lin_vel_z_l2_m5              부모 P0  lin_vel_z_l2 -> -5
   2. s02_lin_vel_z_l2_m3              부모 P0  lin_vel_z_l2 -> -3
   3. s03_lin_vel_z_l2_m2              부모 P0  lin_vel_z_l2 -> -2
   4. s04_lin_vel_z_l2_m0p5            부모 P0  lin_vel_z_l2 -> -0.5
   5. s05_feet_air_time_p0p01          부모 P0  feet_air_time -> 0.01
   6. s06_feet_air_time_p0p1           부모 P0  feet_air_time -> 0.1
   7. s07_feet_air_time_p0p35          부모 P0  feet_air_time -> 0.35
   8. s08_feet_air_time_p0p5           부모 P0  feet_air_time -> 0.5
   9. s09_ang_vel_xy_l2_m0p3           부모 P0  ang_vel_xy_l2 -> -0.3
   10. s10_ang_vel_xy_l2_m0p15          부모 P0  ang_vel_xy_l2 -> -0.15
   11. s11_ang_vel_xy_l2_m0p02          부모 P0  ang_vel_xy_l2 -> -0.02
   12. s12_action_rate_l2_m0p02         부모 P0  action_rate_l2 -> -0.02
   13. s13_action_rate_l2_m0p005        부모 P0  action_rate_l2 -> -0.005
   14. s14_p0_repeat                    부모 P0  lin_vel_z_l2 -> -1.25
점마다 학습 seed 42, 4096 env, 1000 iter, 평가 iter 900, 69 case, 영상 10편. 점당 약 2시간 25분 [추정].

1. 올리기: GO2_G_A063_PC2_STAIRS_SWEEP_v1.zip  SHA256 (발행 시 기록)  → /workspace/GO2_G_A063_PC2_STAIRS_SWEEP_v1.zip
2. 환경 변수: workspace/_keep/go2_g_a060_pc2_run_chain.sh 머리의 mount·export 줄을 먼저 실행한다.
3. 실행(한 줄, nohup 또는 tmux 안에서):
   unzip -oq /workspace/GO2_G_A063_PC2_STAIRS_SWEEP_v1.zip -d /workspace && bash /workspace/go2_g_a063_pc2/run_all.sh
   진행: /workspace/_keep/go2_g_a063_pc2_points/BATCH_RUN.log, POINT_STATUS.tsv
4. GPU 감시: tools/go2_gpu_watch.sh --hours 40 --pattern 'go2_g_a063_pc2_*' (패턴 필수, 감시는 기록만 한다)
5. 실패 처리: rc 20~25(환경·패키지)면 run_all 이 멈춘다 — 고친 뒤 같은 한 줄(끝난 점은 SKIP).
   rc 30~34(학습 뒤)는 다음 점으로 간다 — 끝난 뒤 'bash run_point.sh --only <key>' 로 그 점만 재개한다.
   학습 도중 실패(iter 900 checkpoint 없음)는 자동 재학습하지 않는다 — 보고한다.
6. 회수: 점마다 /workspace/_keep/go2_g_a063_pc2_<key>/ 폴더와 GO2_G_A063_PC2_<KEY>_RESULT.zip + .sha256,
   /workspace/_keep/go2_g_a063_pc2_points/ → 저장소 workspace/_keep/ (100MB 초과는 95MB parts).
