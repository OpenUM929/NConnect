GO2 G-A033 STAGED CANDIDATE — A017 + track_lin_vel_xy_exp 1.4 -> 1.5
====================================================================

This package TRAINS one policy and then measures it.  status: exploratory.
The candidate is evaluated at the iter-900 checkpoint, the iteration the baseline was
evaluated at, not at finalize's reward pick; training/CHECKPOINT_PIN.txt records both.

WHAT CHANGES
  The baseline is A017 (Pilot-01 + track_lin_vel_xy_exp 1.4), 39.76/70 on the
  69-case internal proxy (G-A027).  The candidate changes one reward only:
  track_lin_vel_xy_exp 1.4 -> 1.5.  Deployed train/play/task code is unchanged
  (R-6); only candidate/quadruped_rewards.py carries the new value.

WHY (plan GO2_FALL_POSTURE_CANDIDATES_20260915.md)
  A017 walks well on flat ground (G1/G2 survival 1.0, tracking >= .89). Off flat ground it is slow:
  rough_forward and DR at .25-.30 m/s for a .5 m/s command (plan 8-1).
  G7 is not lost to the randomisation: DR tracking equals rough_forward tracking on the same terrain,
  and heavier robots are not slower (mass-speed r +.05..+.36). It is lost to walking speed on rough ground.
  The only lever that raised rough_forward and DR on all three evaluation seeds is track 1.2 -> 1.4
  (rough_forward +.084/+.106/+.136, dr +.103/+.190/+.055; 69-case total +6.09/70, G-D184).
  feet_air_time 0.01 (G-A031, same iter 900) moved them both ways; G-A032 (0.1) was evaluated at iter 700.
  1.5 is the Isaac Lab v2.3.1 Go2 rough value and the guidebook lecture 14 example.
  Risks pre-registered from the same direction: slope crouch-stalls 0 -> 4-8, a lateral push case with
  3 terminations, 10cm two-step stair ascents 10-11 -> 3-5. Step +7%, less than half of 1.2 -> 1.4.

STAGES (run the target stage first)
  target (default, ~1h25m): training, catastrophe gate, the 9 target cases,
     5 sentinel cases, 5 videos, result ZIP.  Criterion 1 is decided
     on the target cases alone, so a target-stage FAIL is final for this arm.
  full (~55m more, only after the local verifier says TARGET_PASS_FULL_STAGE_REQUIRED):
     the other cases of the 69, the target stage kept, result ZIP again; criteria 2-4.

RUN
  unzip GO2_G_A033_track_lin_vel_xy_150_iter900_staged.zip -d /workspace
  PACKAGE_ROOT=/workspace/go2_g_a033 bash /workspace/go2_g_a033/server_run_go2_candidate_iter_pinned.sh
  GO2_STAGE=full GO2_RESUME=1 PACKAGE_ROOT=/workspace/go2_g_a033 bash /workspace/go2_g_a033/server_run_go2_candidate_iter_pinned.sh
  Finish marker (both stages): [DONE] GO2_G_A033_RESULT_READY; RUNNER_STATUS.txt carries STAGE and DECISION.

VIDEOS (relevant cases only; the A017 counterparts are in the G-A027 harvest)
  G1:forward_fast:101      flat gait at the fastest command: does the stronger speed push keep a normal gait
  G3:rough_forward:101     target: rough-terrain forward walking
  G4:slope_plus_20:101     target: speed and body height on the 20 deg climb (T2)
  G5:stairs_15_up:101      side effect: stairs under a stronger speed push. This case starts on the top platform and walks down first (plan 9); 1.2->1.4 cut 10cm 2-step ascents 10-11 -> 3-5
  G7:dr_seed_101:101       target: walking under domain randomisation

DOWNLOAD
  /workspace/_keep/GO2_G_A033_RESULT.zip
  /workspace/_keep/GO2_G_A033_RESULT.zip.sha256

PRE-REGISTERED READING (plan section 6-1, fixed before the run)
  success needs all of:
   1 basic motion off flat ground: the mean case proxy (survival x tracking) over
     rough_forward, slope_plus_20 and the three DR cases (9 case-seeds) rises by
     >= 0.05, and at least 2 of the 3 groups improve   [target stage]
   2 total internal proxy delta >= 0.0/70, same evaluator                 [full stage]
   3 flat ground holds: G1/G2 scenario proxy drop <= 0.02, no G1/G2 case loses
     more than 0.03125 survival; no other scenario loses more than
     0.5/70 weighted                                         [full stage]
   4 POLICY_LOCOMOTES and no new stationary case outside the stairs (G5)   [full stage]
   5 videos show normal four-legged walking with the feet lifted (human reading)
  Height and posture-gate falls on the target cases are read as the mechanism,
  not as a criterion.  The expected weighted gain is NOT estimated.
  Official results remain OFFICIAL_RESULT_UNMEASURED.
