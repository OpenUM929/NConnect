GO2 G-A043 REWARD CHANGE ON G-A033 — lin_vel_z_l2 -2.0 -> -1.5
==============================================================

This package TRAINS one policy and then measures it.  status: exploratory.
It is one arm of a campaign; do not run it on its own (see the campaign guide).

WHAT CHANGES
  Exactly one reward weight: lin_vel_z_l2 -2.0 -> -1.5.
  candidate/quadruped_rewards.py and reference/baseline_quadruped_rewards.py differ in that line only.
  Training length, seed, env count and every other weight are G-A033's.

WHY (analysis GO2_POST_A042_PLAN_20260922.md)
  The plan's goal, in its own words: find out whether relaxing the body's vertical-velocity penalty lets the policy learn a usable stair progression, while rough forward travel, sway and both push directions are held. Not a promise that it will.
  Role first (Isaac Lab formula): lin_vel_z_l2 pays -w * v_z^2 in the body frame, with no direction term, so the rise that a tread requires is charged at the same rate as the bounce that a bad landing produces. That is the mechanism this arm tests, and it is a property of the formula, not an interpretation.
  The association that suggests it: on G-A033's own trajectories the 43 robots that climb a 10 cm step carry -0.124 of this penalty against -0.072 for the 6 that stall in front of it (reports/evidence/go2_stairs_behavior_20260916/CLIMB_REWARD.csv). Holding behaviour fixed, a 25 percent smaller weight removes 25 percent of that cost.
  Named in advance, and this is why the arm is an information run and not a recommendation: the same file shows the climbers' two-term sum already higher (0.861 against 0.642), and the 15 cm stallers carrying the smallest share of this penalty (-0.021) while climbing least of all. Base data section 5 S5 tests the share rule across runs and reports False. G-A037 (-1.0) is held for exactly this reason.
  Walking is the safe side of the arithmetic: the walk margin rises +0.1359 -> +0.1480 at -1.5 and the stop zone's top is +0.0155, so this arm cannot produce a standing policy by arithmetic. It can still produce a worse one.
  The predicted cost is written down before the run: the situation sheet puts sway at -0.0470 and push at -0.0386 at this value, and the deployed participant file itself says the strong side of this dial is the one that helps rough ground and stairs. Both are in the counterevidence rows.
  -1.5 is a step size, not an optimum: it is half of the held G-A037 step, inside the deployed band 추천 -5.0 ~ -0.5, and the smallest untested relaxation of a dial that no walking baseline has ever trained at any value but -2.0. A smaller step is not proven safer.
  Risks pre-registered under fact_rules_v1 plus post_a042_push_v1: the rough and push group floors, the per-scenario loss limits (G3 2.03646, G6 0.86196), the flat guards, the stationary guard, the climbed-robot floors as the reverse guard, and both G6 x directions as a paired-seed protection block. The 15 cm stairs and both G6 y directions stay required records in stage 1 whatever the gate decides. The y directions are kept out of the gate because one seed cannot show consistency across seeds, not because a comparison is impossible on them - it is, at that one seed, and it is recorded for a human to read. That is a stated scope limit, not a judgement that they matter less.

HOW THE VALUE WAS CHOSEN
  source: workspace/training/quadruped/upload/plan/GO2_POST_A042_PLAN_20260922.md sections 2 and 3; reports/GO2_G_A042_READOUT.md; reports/GO2_STAIRS_BEHAVIOR_ANALYSIS_20260916.md; evidence reports/evidence/go2_stairs_behavior_20260916/CLIMB_REWARD.csv and reports/evidence/go2_reward_mechanism_20260917/PROBES.csv.
  role: Penalize z-axis base linear velocity using an L2 squared kernel (Isaac Lab v2.3.1, reports/evidence/go2_reward_term_roles_20260917/isaaclab_envs_mdp_rewards.py: torch.square(asset.data.root_lin_vel_b[:, 2])). It is the body frame's vertical speed squared - not foot height, not world-frame altitude, not ground clearance. On a slope the body frame tilts with the robot, so the same climb charges differently there than on flat ground; that distinction is why G4 is carried as a guard axis rather than as a target.
  walk_margin: G-A033 walk margin +0.1359 -> +0.1480 at -1.5 (reports/evidence/go2_reward_mechanism_20260917/PROBES.csv, zone WALK, delta +0.0121, range_status OUT_OF_RANGE). The stop zone's top is +0.0155, so the margin stays about ten times above it and the arithmetic cannot produce a standing policy by itself. A margin is reward arithmetic over measured postures, not a prediction of speed.
  situations: reports/evidence/go2_reward_mechanism_20260917/PROBE_SITUATIONS.csv at -1.5: walk +0.0121, climb +0.0258, sway -0.0470, push -0.0386. Two cells point up and two point down, which is the opposite shape from G-A042 (all four up) and is why the push and sway guards are strengthened here. The cells are computed from G-A033's own trajectories with behaviour held fixed; they say what the reward prefers, not what the policy will do.
  rule: The plan selects -1.5 as one 25 percent relaxation, half the step of the held G-A037 (-1.0), and explicitly not an optimum: a smaller step is not proven safer, it is only smaller. No walking baseline has ever trained any value of this term except -2.0, so every candidate value on this dial is OUT_OF_RANGE and the run is an information run.
  not_claimed: No score gain is estimated. The climb/stall penalty-share gap is an association measured across different terrains and different robot populations, not a causal experiment, and the same file shows the 15 cm stallers carrying the smallest share of this penalty (-0.021) while climbing least - so 'the penalty is what blocks the climb' is not established and is not claimed.

LEVERS NOT MOVED
  track_lin_vel_xy_exp: held at 1.5: G-A042 raised it to 1.6 and the 10 cm two-or-more count went 43 -> 0 of 96 with posture falls 34 -> 85 (reports/GO2_G_A042_READOUT.md). The local extension of that dial is measured and closed; 1.7 is not attempted.
  ang_vel_xy_l2: measured and closed for now in both directions on the stairs: -0.08 took the 10 cm climbed-robot count 90 -> 5 (G-A038) and the relaxation -0.04 took it 90 -> 34 with posture falls 34 -> 93 of 96 (G-A041). Re-tuning this axis is behind other dials until a new reading argues for it.
  feet_air_time: held at 0.2: 0.01 and 0.1 were both rejected at stage 1 (A031, A032) and 0.35 stopped the policy (A015). It is air time, not foot height, so it does not address the tread.
  flat_orientation_l2: G-A040 is on hold with six adverse rows and a climb guard whose floor is non-positive (stairs_15_climb_ge1, baseline sum 4, max drop 5.523), which tools/go2_fact_rules.py reports as inoperative. Its chain is not closed, so it does not overtake this arm.
  action_rate_l2: -0.008 is a valid rejection (A018) and reports/evidence/go2_reward_mechanism_20260917/PROBE_SITUATIONS.csv leaves climb, sway and push empty for this term, so no situation direction can be read for it.
  dof_acc_l2: G-A039 is on hold and sits outside the deployed six, which makes it dependent on open decision U1-R6-ENV-REWARD-20260918. A term inside the list needs no such decision.
  lin_vel_z_l2_to_m1: -1.0 (G-A037) is the same direction at twice this step and stays on hold: its derivation was the penalty-share rule that base data section 5 S5 reports as not holding across runs. This arm keeps that contradiction on the record instead of deleting it, halves the step, and runs it as an information run rather than a recommendation. A FAIL here does not license -1.0 afterwards.
  max_iterations: outside R-6 (not a reward weight). Matching the two arms' curriculum level at the pin would need it and is therefore not done here; see notes.curriculum_lag.
  training_seed: outside R-6. The plan asks for an independent-seed pair after a screening pass, not before it, and a seed replicate buys interpretation rather than score (reports/GO2_SEED_SENSITIVITY.md section 5).

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  No gain estimate exists and one training seed cannot
  separate the lever from seed luck.
  Pre-registered: all other axes held -- per-scenario weighted loss at most twice its own
  evaluation sd (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358), flat G1/G2 guards unchanged.

CHECKPOINT
  Evaluated at iter 900 of 1000, the iteration G-A033 was evaluated at.

VIDEOS (4 env x 500 steps)
  G5:stairs_10_down:101      the target case the climbed-robot counter reads. The G-A033 counterpart was rendered in the G-A041 run from the frozen baseline model and is reused here by SHA.
  G5:stairs_15_down:101      the height the plan refuses to drop. The G-A033 counterpart was rendered in the G-A042 run from the frozen baseline model and is reused here by SHA.
  G3:rough_forward:101       the axis the arm must hold while the stairs move; this is the case whose absence made G-A038 unscorable. Stored G-A033 video, reused by SHA.
  G3:rough_lateral:101       the sway case this change is predicted to cost (PROBE_SITUATIONS sway -0.0470). The G-A033 counterpart was rendered in the G-A041 run and is reused here by SHA.
  G6:push_pos_x:101          the push direction the guard scores, and the second cell this change is predicted to cost (push -0.0386). A bouncier body may be shoved further before it recovers, and survival alone does not show whether the robot recovered or never fell in the first place. No G-A033 video of this case exists at these settings, so the baseline is rendered here.
  G6:push_neg_x:101          the opposite push direction, which G-A042 carried as a single unscored marker. The plan requires both x directions of G6 to be guarded here, so it is filmed on both arms and measured at three seeds. No G-A033 video of this case exists, so the baseline is rendered here.

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
