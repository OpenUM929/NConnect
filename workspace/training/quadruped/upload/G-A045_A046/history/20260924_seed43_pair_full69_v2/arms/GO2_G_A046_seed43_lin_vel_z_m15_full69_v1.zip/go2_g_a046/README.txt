GO2 G-A046 — seed 43 replication arm of the pair G-A045_A046
============================================================

This package TRAINS one policy and then measures it over all 69 cases.  status: exploratory.

WHAT CHANGES
  TRAINING SEED 42 -> 43.  Deployed train/play/task code is unchanged; the seed is the
  CLI argument the deployed train.py forwards to Isaac Lab's rsl_rl train.py.
    ONE reward weight: lin_vel_z_l2 -2.0 -> -1.5,
  the value G-A043 measured at seed 42.  Inside this campaign the control is
  G-A045, which carries -2.0 at the same seed 43.

WHAT THIS ARM MAY NOT BECOME
  A submission candidate.  promotion: forbidden_not_a_reward_change.
  A training seed is not a reward weight, so nothing measured here can be promoted,
  whatever it scores.  The open reading is U2-SEED-REPLICATE-20260918 and it is the user's to close.

WHY (plan GO2_A045_SEED_PAIR_PLAN_20260924.md)
  The plan's goal in its own words: find out whether G-A043's stair gain and G2 loss belong to the weight or to the training path it happened to draw.
  Role first (Isaac Lab formula): lin_vel_z_l2 pays -w * v_z^2 in the body frame with no direction term, so the rise a tread needs and the bounce of a bad landing cost the same.
  What is measured, not argued: at this weight on the first path the pooled 15 cm >=2 step count went 0 -> 77 of 96 and combined_yaw_right posture falls went 0 -> 29 of 96, for a total of +2.09593/70 against a preregistered 2.53.
  Why repeat instead of interpolate: the interpolation was tried (G-A044) and came back below both ends on the total while sitting between them on the stairs. The next thing to learn is not another value but whether these readings repeat.
  Named in advance: the reproduction thresholds are numbers, not impressions - 50 of 96 reproduces the stairs, 10 or below refutes them, and the space between is INCONCLUSIVE.

CHECKPOINT
  Evaluated at iter 900 of 1000,
  the iteration G-A033 and G-A044 were evaluated at.  finalize's reward pick is kept as
  training/model_best_by_reward.pt and is not evaluated.

STAGES
  full only (~95m): training, catastrophe gate, all 69 cases,
  5 sentinel cases, 6 candidate videos,
  0 baseline videos, result ZIP.  There is no stage 1 and no server gate.

THIS ARM IS RUN BY THE PAIR RUNNER
  The campaign package GO2_G_A045_A046_seed43_pair_full69_v2.zip carries this ZIP and runs it with
  server_run_go2_full69_campaign.sh.  Running this arm alone also works:
    bash /workspace/go2_g_a046/server_run_go2_candidate_iter_pinned.sh
  Done marker: [DONE] GO2_G_A046_RESULT_READY
  Result:      /workspace/_keep/GO2_G_A046_RESULT.zip

VIDEOS (4 env x 500 steps)
  G5:stairs_15_down:101      the counter that moved most on this dial (pooled >=1 step 4 -> 39 -> 88 of 96 over -2.0, -1.75, -1.5) and the one this round asks to see repeated on a second training path. Filmed on both arms so a count can be read as a behaviour.
  G5:stairs_10_down:101      the other stair height, where the climbed count rose monotonically (43 -> 62 -> 94) while posture falls did not (34 -> 65 -> 17). Two counters disagreeing on the same case is the thing this round measures.
  G3:rough_lateral:101       the fall counter with the widest swing between runs at the same weight family (59 -> 80 -> 24 of 96). If the seed-43 ruler arm lands far from 59, the counter is path-sensitive and the axis limits built on it are looser than they look.
  G2:combined_yaw_right:101  the case that decided G-A043 (posture falls 0 -> 29 of 96) and the only guard counter that follows the dial monotonically. Filmed on both arms: if it breaks again at seed 43 under -1.5, the loss belongs to the value, not to the path.
  G6:push_pos_y:101          one of the four push directions whose pooled falls went 22 -> 66 -> 10 across the three points. A shove is the shortest event we film, so the recovery shape is readable rather than inferred from a survival number.
  G1:forward_nominal:101     the catastrophe case and the flat floor. Both arms must walk before any other number means anything; this is the film that shows it rather than asserting it from a gate.

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 over 69 cases,
  trained at seed 42).  Its model and env ship here so the server can verify the sentinel
  cases re-measure the same policy with the same ruler.
