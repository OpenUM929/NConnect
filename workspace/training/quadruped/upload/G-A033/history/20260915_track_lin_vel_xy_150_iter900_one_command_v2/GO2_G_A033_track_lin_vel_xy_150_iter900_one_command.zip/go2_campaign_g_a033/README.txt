GO2 G-A033 CAMPAIGN — one upload, one command, one result
=========================================================

This package TRAINS 1 policy and measures
it.  status: exploratory.  Plan: GO2_FALL_POSTURE_CANDIDATES_20260915.md.

ARMS (byte for byte what tools/build_go2_candidate_package.py builds)
  G-A033  track_lin_vel_xy_exp 1.4 -> 1.5   arms/GO2_G_A033_track_lin_vel_xy_150_iter900_staged.zip  sha256 1781fbc33fe52c3e37d83903f1ff4b67865baaf641675b3ca8a1d05069db259e

RUN
  unzip -oq GO2_G_A033_track_lin_vel_xy_150_iter900_one_command.zip -d /workspace
  bash /workspace/go2_campaign_g_a033/server_run_go2_campaign.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_campaign_g_a033/server_run_go2_campaign.sh

WHAT HAPPENS
  1 the target stage of each arm (~1h25m each): training, catastrophe gate, the
    9 target cases, the sentinel, the videos.
  2 after each target stage, go2_target_gate.py reads criterion 1 (plan 6-1); the
    runner takes the verdict from the gate's JSON:
      TARGET_PASS -> full stage (~55m); FAIL -> the arm ends;
      REMEASURE_BASELINE -> target stage again with A017 remeasured, gate again;
      UNDECIDED -> no full stage.
  3 full stage of each arm the gate passed.
  4 one result ZIP.  The gate only schedules GPU time; the local verifier
    (tools/verify_go2_basic_motion_harvest.py) decides every verdict.

CHECKPOINT
  Each candidate is evaluated at the iter-900 checkpoint, the iteration A017 was
  evaluated at, not at train.py finalize's reward pick (server_run_go2_candidate_iter_pinned.sh).

DOWNLOAD
  /workspace/_keep/GO2_G_A033_CAMPAIGN_RESULT.zip
  /workspace/_keep/GO2_G_A033_CAMPAIGN_RESULT.zip.sha256
  Finish marker: [DONE] GO2_G_A033_CAMPAIGN_RESULT_READY
  Official results remain OFFICIAL_RESULT_UNMEASURED.
