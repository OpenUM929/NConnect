GO2 G-A041 REWARD CHANGE ON G-A033 — ang_vel_xy_l2 -0.05 -> -0.04
=================================================================

This package TRAINS one policy and then measures it.  status: exploratory.
It is one arm of a campaign; do not run it on its own (see the campaign guide).

WHAT CHANGES
  Exactly one reward weight: ang_vel_xy_l2 -0.05 -> -0.04.
  candidate/quadruped_rewards.py and reference/baseline_quadruped_rewards.py differ in that line only.
  Training length, seed, env count and every other weight are G-A033's.

WHY (analysis GO2_ANG_VEL_RELAX_AUDIT_20260920.md)
  Goal: every axis held while the stairs rise. G-A033 largest deductions are G5 10.45527 and G3 9.77274 (reports/runs/SCENARIO_SCORES.csv), and G5 is bound by forward distance, not by survival (reports/GO2_AXIS_BOTTLENECK.md): the survival-1.0 counterfactual on G5 is only 1.43139/10.5.
  Role first (Isaac Lab formula, reports/evidence/go2_reward_term_roles_20260917/isaaclab_envs_mdp_rewards.py:83): ang_vel_xy_l2 charges the squared roll and pitch RATES of the trunk - the speed of the body rotation a robot needs to put a foot on a tread.
  This is the only dial in 18 trainings whose movement was measured against the climbed-robot counter, and the measurement is large: at -0.08 robots climbing at least one 10 cm step went 90 -> 5 of 96 and two or more went 43 -> 0 (reports/evidence/go2_a038_reread_20260919/CLIMB_COUNT.csv). Its relaxation side has never been run.
  The behaviour behind that number is a stall, not a fall: at -0.08 the stairs robots end the episode at 0.016 to 0.023 m/s against a 0.5 m/s command and at a lower trunk height than the baseline (reports/evidence/go2_a038_reread_20260919/STAIRS10_ROLLUP.csv, reports/GO2_A038_REREAD_20260919.md section 1-1). The same direction is what G5 needs reversed.
  Walking is the safe side of this change: relaxing a penalty raises the walk margin, +0.1359 -> +0.1569 (reports/evidence/go2_reward_mechanism_20260917/PROBES.csv), and the stop zone top is +0.0155.
  Named in advance, and this is why the arm is an information run and not a recommendation: the same probe row says sway -0.1077 and push -0.0512, and the one post-hoc check of this dial got the sway size nearly right while getting the climb size wrong by about thirteen times (reports/GO2_REWARD_MECHANISM_FORECAST.md section 9). The loss channel is the better calibrated one.
  The value is a step size, not an optimum: -0.04 is one 0.01 step on the untested side, inside the band the deployed file writes for this dial, and on the opposite side of the baseline from every rejected value, so F5 is satisfied by direction rather than by magnitude.
  Risks pre-registered under fact_rules_v1: the rough and push group floors, the per-scenario loss limits (G3 2.03646, G6 0.86196), the flat guards, the stationary guard, and the climbed-robot floors as the reverse guard.

HOW THE VALUE WAS CHOSEN
  source: workspace/training/quadruped/reports/GO2_ANG_VEL_RELAX_AUDIT_20260920.md; reports/GO2_A038_REREAD_20260919.md sections 1-1, 2-3 and 4-1; reports/GO2_REWARD_MECHANISM_FORECAST.md sections 6, 6-0, 8 and 9; evidence reports/evidence/go2_a038_reread_20260919/CLIMB_COUNT.csv, reports/evidence/go2_a038_reread_20260919/STAIRS10_ROLLUP.csv, reports/evidence/go2_reward_mechanism_20260917/PROBES.csv and reports/evidence/go2_reward_mechanism_20260917/PROBE_SITUATIONS.csv; reports/GO2_TUNING_BASE_DATA.md sections 0-1, 4 and 5; reports/runs/LEDGER.csv and reports/runs/TERRAIN_AT_PIN.csv
  role: Penalize xy-axis base angular velocity using L2 squared kernel (Isaac Lab v2.3.1, reports/evidence/go2_reward_term_roles_20260917/isaaclab_envs_mdp_rewards.py:83): the squared roll and pitch RATES of the trunk. It is not the tilt angle (flat_orientation_l2) and it does not read foot height. G-A033 logged term value over weight is 3.020, about 1.74 rad/s rms (GO2_TUNING_BASE_DATA.md section 0-1).
  walk_margin: G-A033 walk margin +0.1359 -> +0.1569 at -0.04 (reports/evidence/go2_reward_mechanism_20260917/PROBES.csv, zone WALK, delta +0.0210). Relaxing a penalty can only raise this margin, so the walking side is the safe side of this arm; the stop zone top is +0.0155. The walk-zone edge weight for this term is -0.107243, on the strengthening side, and is not approached here. The probe grid was extended to -0.04 and -0.03 by tools/go2_reward_mechanism.py on 2026-09-20 exactly as forecast section 8-1 requires for a new value; nothing else in that generator changed.
  situations: reports/evidence/go2_reward_mechanism_20260917/PROBE_SITUATIONS.csv at -0.04: walk +0.0210, climb +0.0036, sway -0.1077, push -0.0512. All three situation columns are filled for this term. The climb cell is the only one of the four that points the way this arm wants, and it is the smallest of the four. The size of the climb cell may not be used: forecast section 9 recorded that at -0.08 the predicted climb change was -0.0107 while the measured collapse was 90 -> 5 climbed robots. Direction only.
  rule: -0.04 is one step of 0.01 on the untested side, the smallest change this dial can take that still prints differently in the server log. Three reasons pick the smallest step rather than the -0.02 already in the probe grid: (a) the measured sensitivity of this dial is high and one-sided - a 60 percent strengthening (-0.05 -> -0.08) removed 94 percent of the climbing robots, so a 60 percent relaxation is not a small perturbation; (b) the predicted sway loss scales with the step, -0.1077 at -0.04 against -0.3230 at -0.02, and only the smaller one keeps the expected G3 cost inside the pre-registered guard 2.03646/70 under linear scaling of G-A038 measured sway proxy +0.356 (estimate, not measurement); (c) F5 asks a new size to be distinguishable from the rejected ones, and -0.04 is on the opposite side of the baseline from every rejected value. There is no measured optimum for this dial in this direction; the 20 percent is a step size, not a derived value.
  not_claimed: No score gain is estimated. The partial margins are reward arithmetic over measured postures: they say what the reward prefers, not how many robots will climb. The one post-hoc check of this exact dial got the climb size wrong by an order of magnitude and got the sway size nearly right - so the loss channel of this arm is the better calibrated one, and that is a reason for caution, not for confidence.

LEVERS NOT MOVED
  lin_vel_z_l2: G-A037 is on hold: -1.0 is outside the observed walking range and its derivation came out reversed in base data S5. Its climb partial margin (+0.0515) is larger than this arm's, but it loses sway and push at the same time (-0.0940, -0.0771) and that trade was never measured; this dial's trade was measured once, at G-A038.
  flat_orientation_l2: G-A040 aims the tilt ANGLE at G3 and is the better arm for that axis. It is not this arm's alternative but its complement: this arm aims G5. G-A040 also still carries a climb guard whose floor is non-positive (stairs_15_climb_ge1, baseline sum 4, max drop 5.523), which tools/go2_fact_rules.py now reports as inoperable; this spec leaves that group out for that reason.
  track_lin_vel_xy_exp: held at 1.5: every raise increased rough side-step terminations (31 -> 48 -> 58, GO2_TUNING_BASE_DATA.md section 2) and 1.5 is the Isaac Lab Go2 rough value.
  feet_air_time: held at 0.2: 0.01 and 0.1 were both rejected at stage 1 (A031, A032) and 0.35 stopped the policy (A015). It is the one deployed name closed in both directions.
  action_rate_l2: -0.008 is a valid rejection (A018) and PROBE_SITUATIONS.csv leaves climb, sway and push empty for this term, so no situation direction can be read for it.
  dof_acc_l2: G-A039 is on hold and sits outside the deployed six, which makes it invisible to go2_task/_finalize.py and dependent on open decision U1-R6-ENV-REWARD-20260918. A term inside the list needs no such decision, so it goes first.
  max_iterations: outside R-6 (not a reward weight). Matching the two arms' curriculum level at the pin would need it and is therefore not done here; see notes.curriculum_lag.
  training_seed: outside R-6. A seed replicate buys interpretation, not score (reports/GO2_SEED_SENSITIVITY.md section 5).

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  No gain estimate exists and one training seed cannot
  separate the lever from seed luck.
  Pre-registered: all other axes held -- per-scenario weighted loss at most twice its own
  evaluation sd (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358), flat G1/G2 guards unchanged.

CHECKPOINT
  Evaluated at iter 900 of 1000, the iteration G-A033 was evaluated at.

VIDEOS (4 env x 500 steps)
  G5:stairs_10_down:101      the target case. It is where this dial was measured before, in the other direction, and where the climbed-robot counter reads. No stored G-A033 video, so the baseline is rendered here.
  G3:rough_lateral:101       the predicted loss. The 2026-09-19 re-read showed G3 ends through the tilt channel and a cheaper rotation rate is the way to make it worse. No stored G-A033 video, so the baseline is rendered here.
  G3:rough_forward:101       the other half of the G3 axis, and the case whose absence made G-A038 unscorable (stored baseline video).
  G4:slope_plus_20:101       the baseline climbs the 20 degree slope to the end; a cheaper trunk rotation rate should not turn that into a wobble (stored baseline video).

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
