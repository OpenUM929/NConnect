#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
KEEP=/workspace/_keep/go2_g_a074_report_policy
PINNED_SHA=d39b88e9a6b06fd08498c90bbba334a3aaaca1cc8e540102c7d0e284bac72211
(cd "$ROOT_DIR" && sha256sum -c --quiet PACKAGE_SHA256SUMS.txt) || { echo '[FAIL] recovery package SHA mismatch'; exit 2; }
[[ -s "$KEEP/training/TRAIN_STATUS.txt" ]] && grep -qx 'TRAIN_RC=0' "$KEEP/training/TRAIN_STATUS.txt" || {
  echo '[FAIL] G-A074 TRAIN_RC=0 artifact is missing'; exit 40;
}
[[ -s "$KEEP/training/model_best.pt" ]] || { echo '[FAIL] G-A074 pinned model missing'; exit 40; }
[[ "$(sha256sum "$KEEP/training/model_best.pt" | awk '{print $1}')" == "$PINNED_SHA" ]] || {
  echo '[FAIL] G-A074 pinned model SHA mismatch'; exit 40;
}
grep -qx 'EVAL_CHECKPOINT_ITER=2400' "$KEEP/training/CHECKPOINT_PIN.txt" || { echo '[FAIL] checkpoint iter mismatch'; exit 40; }
grep -qx "EVAL_CHECKPOINT_SHA=$PINNED_SHA" "$KEEP/training/CHECKPOINT_PIN.txt" || { echo '[FAIL] checkpoint pin SHA mismatch'; exit 40; }
[[ -s "$KEEP/training/env.yaml" && -s "$KEEP/exported/report.html" ]] || { echo '[FAIL] G-A074 env/report missing'; exit 40; }
grep -qx 'REPORT_STATUS=REPORT_ACQUIRED' "$KEEP/exported/REPORT_STATUS.txt" || { echo '[FAIL] report status invalid'; exit 40; }
(cd "$KEEP/exported" && sha256sum -c --quiet report.html.sha256) || { echo '[FAIL] report SHA mismatch'; exit 40; }
if [[ -s /workspace/_keep/GO2_G_A074_REPORT_POLICY_RESULT.zip ]]; then
  BACKUP_DIR=/workspace/_keep/g_a074_pre_eval_archives
  STAMP=$(date +%Y%m%d-%H%M%S)
  mkdir -p "$BACKUP_DIR"
  cp -a /workspace/_keep/GO2_G_A074_REPORT_POLICY_RESULT.zip "$BACKUP_DIR/GO2_G_A074_REPORT_POLICY_RESULT.pre_eval_${STAMP}.zip"
  sha256sum "$BACKUP_DIR/GO2_G_A074_REPORT_POLICY_RESULT.pre_eval_${STAMP}.zip" > "$BACKUP_DIR/GO2_G_A074_REPORT_POLICY_RESULT.pre_eval_${STAMP}.zip.sha256"
fi
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8
export PACKAGE_ROOT="$ROOT_DIR" GO2_RESUME=1 GO2_STAGE=full GO2_REMEASURE_BASELINE=0
exec bash "$ROOT_DIR/server_run_go2_candidate_iter_pinned.sh" --inner
