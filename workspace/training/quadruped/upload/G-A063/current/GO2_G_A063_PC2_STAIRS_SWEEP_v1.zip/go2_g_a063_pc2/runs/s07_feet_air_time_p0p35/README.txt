G-A063 PC2 batch point s07_feet_air_time_p0p35: 부모 P0 위 feet_air_time 0.2 -> 0.35. 범위 내 상단. 배포 ② '↑ 발을 높이 들어 험지 돌파 유리', 생성기 '발 높이 ↑ 등반 유리'.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
