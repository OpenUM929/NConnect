GO2 G-A060 PC2 단일 점 탐색 — 실행 안내
==================================================

설계: workspace/training/quadruped/upload/plan/GO2_PC2_DENSE_SWEEP_PROPOSAL_20261002.md §13·§14
한 번에 한 점만 돈다. 점이 끝나면 멈춘다. 다음 점은 판독 뒤 따로 정한다(자동 연결 없음).
목록은 최대 목록이며, 목록에 있다는 것은 실행 선정이 아니다.

점 목록 (A048 보상 기준, 학습 seed 42, 4096 env, 1000 iter, 평가 iter 900, 69 case):
  a048_seed42                    보상 변경 없음                           기준선 B1 — PC2 A048 그대로. PC2 점들의 직접 대조군.
  ang_vel_xy_l2_m0p06            ang_vel_xy_l2 -0.06                조건부(§13-1): −0.08 이 표적 개선 + 세 seed 공통 보호 손실일 때만 검토 자격.
  ang_vel_xy_l2_m0p07            ang_vel_xy_l2 -0.07                −0.06 결과를 보고 따로 정한다.
  ang_vel_xy_l2_m0p08            ang_vel_xy_l2 -0.08                첫 후보(§14-1). G-A057 같은 행과 보상 바이트 동일.
  ang_vel_xy_l2_m0p1             ang_vel_xy_l2 -0.1                 자동 확장 없음. 완료점 결과로 따로 정한다.
  ang_vel_xy_l2_m0p12            ang_vel_xy_l2 -0.12                자동 확장 없음. 완료점 결과로 따로 정한다.
  track_lin_vel_xy_exp_p1p3      track_lin_vel_xy_exp 1.3           자동 확장 없음.
  track_lin_vel_xy_exp_p1p4      track_lin_vel_xy_exp 1.4           다음 우선 검토점(§14-1). G-A057 같은 행과 보상 바이트 동일.
  track_lin_vel_xy_exp_p1p45     track_lin_vel_xy_exp 1.45          자동 확장 없음.
  track_lin_vel_xy_exp_p1p55     track_lin_vel_xy_exp 1.55          자동 확장 없음.
  track_lin_vel_xy_exp_p1p6      track_lin_vel_xy_exp 1.6           자동 확장 없음. G-A057 같은 행과 보상 바이트 동일.

0. 실행 전: PC2 환경 기록(GO2_PC2_ENV_<날짜>.md)·smoke·속도 실측, 탐색 마감 시각과 회수 여유를 정한다(§13-4).
1. 올리기: GO2_G_A060_PC2_a048_points_v1.zip  SHA256 (발행 시 기록)  → /workspace/GO2_G_A060_PC2_a048_points_v1.zip
2. 첫 점(B1):
   unzip -oq /workspace/GO2_G_A060_PC2_a048_points_v1.zip -d /workspace && bash /workspace/go2_g_a060_pc2/run_point.sh --only a048_seed42
   목록·상태: bash /workspace/go2_g_a060_pc2/run_point.sh --list    진행: tmux attach -t go2_g_a060_pc2
   끊기면 같은 --only 명령을 다시 친다(부분 결과는 GO2_RESUME=1 로 이어 간다).
3. 다음 점: 판독 뒤 정해진 key 로 bash /workspace/go2_g_a060_pc2/run_point.sh --only <key>
4. 가져올 것: /workspace/_keep/go2_g_a060_pc2_<key>/ 폴더 전체, GO2_G_A060_PC2_<KEY>_RESULT.zip + .sha256,
   /workspace/_keep/go2_g_a060_pc2_points/ → 저장소 workspace/_keep/ 에 같은 이름으로 복사(원본 유지).
5. 규정: PC 학습은 탐색용이다. 제출 정책은 서버에서 다시 학습한다. 배포 학습 코드는 수정하지 않았다.
