#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
bash "$ROOT_DIR/go2_g_a085_eval.sh" "$@"
