GO2 G-A035 TRAINING LENGTH — G-A033 rewards, 1500 iterations
============================================================

This package TRAINS one policy and then measures it.  status: exploratory.

WHAT CHANGES
  NO REWARD WEIGHT CHANGES.  candidate/quadruped_rewards.py and
  reference/baseline_quadruped_rewards.py are byte-identical, on purpose.
  The single change is training length: 1000 -> 1500 iterations,
  the Isaac Lab v2.3.1 go2_rough value.  Deployed train/play/task code is unchanged.

WHY (plan GO2_BASIC_MOTION_TUNING_PLAN_20260915.md)
  The frozen baseline G-A033 scores 42.53/70. Its remaining loss is 27.47, and 20.2 of that is two cases:
  G5 stairs_15_down (10.46) and G3 rough_lateral (9.77).
  G5 is a stall, not a tracking limit: every evaluated policy stops level in front of the first 15cm riser
  (stairs analysis section 5; the earlier tracking-bound reading was a score-factor diagnosis and is withdrawn).
  G3 is survival-bound, and the only dial with a measured effect (track) moved it the wrong way:
  1.4 -> 1.5 cost rough_lateral survival .47 -> .38.
  Isaac Lab trains go2_rough for 1500 iterations; we train 1000. The training log's terrain level
  (the mean over all robots, 3.43 / 4.49 at iter 900 for A017 / G-A033) was still rising at 999.
  That mean does NOT give the highest stair trained: robots start at levels 0-5 and level 5
  already has 0.14-0.158 m steps. Whether the stair columns reached 0.15 m is unknown.
  This run changes no reward. It observes the G-A033 configuration trained to the Isaac Lab length.
  It does not show why a score changes. Inference-chain status INFORMATION_RUN; replan section 5 awaits re-judgement under G-D-FACT-RULES-20260917.

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  More training may not help.
  Observed: the training log records the terrain curriculum level every
  iteration.  It is the MEAN over all robots and all sub-terrain types, so it
  does not say how far the stair columns went.
  Not available: a determinism check.  The runner keeps iter 1450 and finalize's
  pick, not model_900.pt.  Training-seed noise is unmeasured (all runs seed 42).

CHECKPOINT
  Evaluated at iter 1450 of 1500 (save_interval 50); the baseline
  G-A033 was evaluated at 900 of 1000.  Both are near-final checkpoints of their
  own run.  The iteration differs because training length IS the variable here.
  finalize's reward pick is kept as training/model_best_by_reward.pt, not evaluated.

STAGES (run the target stage first)
  target (default, ~115m): training, catastrophe gate, the 9 target cases,
     5 sentinel cases, 5 videos, result ZIP.  Criterion 1 is decided on
     the target cases alone, so a target-stage FAIL is final for this arm.
  full (~55m, only after a target pass): GO2_STAGE=full GO2_RESUME=1

ONE COMMAND
  cd /workspace && unzip -o GO2_G_A035_a033_iter1500_staged.zip && cd /workspace/go2_g_a035 && \
    tmux new -s go2_g_a035 -d 'bash server_run_go2_candidate_iter_pinned.sh 2>&1 | tee runner.log'
  Done marker: [DONE] GO2_G_A035_RESULT_READY
  Result:      /workspace/go2_g_a035/GO2_G_A035_RESULT.zip

VIDEOS (4 env x 500 steps)
  G5:stairs_15_down:101      THE min-case of G5 and of the whole score. Stored G-A033 seed 202: posture-gate survival .03 (31 of 32 counted as fallen), tracking .14, mean speed 0.10 m/s. Whether those are real falls or stalls counted as falls is not settled (GO2_NOW section 4); the video is for a human to read. No stored counterpart exists, so the baseline video is rendered in this run.
  G5:stairs_15_up:101        the ascent counterpart at the same step height; a stored G-A033 video exists for a direct A/B
  G3:rough_lateral:101       the min-case of G3, survival .38-.41. Side-stepping falls are the second largest hole. No stored counterpart, so the baseline video is rendered here.
  G4:slope_plus_20:101       G-A033 already reaches survival 1.00 here; the video guards against losing it
  G1:forward_fast:101        R-Sci-4 stationary-exploit guard on flat ground at the fastest command

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Promoted to the frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
