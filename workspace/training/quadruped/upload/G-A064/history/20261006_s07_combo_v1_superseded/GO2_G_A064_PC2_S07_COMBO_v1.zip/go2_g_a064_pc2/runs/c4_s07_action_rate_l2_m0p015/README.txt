G-A064 PC2 batch point c4_s07_action_rate_l2_m0p015: 부모 S07 위 action_rate_l2 -0.01 -> -0.015. 강화 쪽 사이값. s12(−0.02)의 험지·평지 옆걸음 붕괴가 문턱형인지 점진형인지. 예측상 불리한 방향.
이 폴더는 run_point.sh 가 펼쳐서 쓴다. PC 결과는 탐색용이며 제출 후보가 아니다.
