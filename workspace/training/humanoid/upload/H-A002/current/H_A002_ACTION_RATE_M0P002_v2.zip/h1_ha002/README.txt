H-A002 v2 runs matched from-scratch 1000-iteration control (-0.0005) and candidate (-0.002) arms.
Run: cd /workspace/training/humanoid && unzip -o H_A002_ACTION_RATE_M0P002_v2.zip && NO_TMUX=1 H1_ROOT=/workspace/training/humanoid ISAACLAB_SH=/workspace/IsaacLab/isaaclab.sh bash h1_ha002/server_run_h1_ha002.sh
Result: /workspace/_keep/H_A002_ACTION_RATE_M0P002_RESULT.zip (+ .sha256).
