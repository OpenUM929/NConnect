G-A056 A043 diagnostic replay — no training, no reward change.
Replays G-A043 iter 900 on rough_lateral and combined_yaw_right seed 202 (plain and diag), then films
four robots with the viewer pinned to their env index.
Run: bash /workspace/go2_g_a056/server_run_go2_a043_diag_replay.sh
Plan: workspace/training/quadruped/upload/plan/GO2_G_A056_A043_DIAG_REPLAY_PLAN_20260928.md
