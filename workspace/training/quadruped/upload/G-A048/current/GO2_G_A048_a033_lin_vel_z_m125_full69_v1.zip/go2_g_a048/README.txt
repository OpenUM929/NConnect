GO2 G-A048 REWARD CHANGE ON G-A033 — lin_vel_z_l2 -2.0 -> -1.25
===============================================================

This package TRAINS one policy and then measures it.  status: exploratory.
One upload, one command, one result ZIP: the whole 69-case evaluation runs in a single
pass (run_config.env pins GO2_STAGE=full), so there is no target stage and no server gate.
  unzip -oq <this zip> -d /workspace
  bash /workspace/go2_g_a048/server_run_go2_candidate_iter_pinned.sh
  Resume after an interruption: GO2_RESUME=1 bash /workspace/go2_g_a048/server_run_go2_candidate_iter_pinned.sh

WHAT CHANGES
  Exactly one reward weight: lin_vel_z_l2 -2.0 -> -1.25.
  candidate/quadruped_rewards.py and reference/baseline_quadruped_rewards.py differ in that line only.
  Training length, seed, env count and every other weight are G-A033's.

WHY (analysis GO2_A043_YAW_RIGHT_AND_NEXT_20260926.md)
  Purpose: extend the observed range of the one dial in this campaign with direct evidence of moving both the stairs and the rough axis on this baseline, and record whether the G2 combined-turn cost moves with it. Not a promise of a higher score.
  Role first (Isaac Lab formula): lin_vel_z_l2 pays -w * v_z^2 in the body frame, with no direction term, so the rise a tread requires is charged at the same rate as the bounce a bad landing produces. That is the mechanism this arm moves, and it is a property of the formula.
  What is measured: at -2.0 / -1.75 / -1.5 the 15 cm ge1 count rose 4 -> 39 -> 88 of 96 and ge2 0 -> 0 -> 77, while rough side-step posture falls went 59 -> 80 -> 24 and combined_yaw_right falls 0 -> 0 -> 29. The stair counters are monotone in the weight; the fall counters are not.
  G-A043's loss is a rare posture collapse during the right turn: 29 of 96 robots, all through the tilt and height channels together, 0 terminations, fall times 2.46-19.8 s. The fallers' mean profile shows lateral velocity and tilt growing about 1.5 s before the verdict and the yaw-rate sign flipping last. It was observed only on G-A043 and this data cannot separate its cause.
  Why -1.25: it keeps the 0.25 interval of the measured points and steps once beyond the relaxed end. That is an operational choice, not an optimum estimate; -1.0 is G-A037's held value and further out.
  Two verdicts, fixed before the run: the hypothesis indicators (stairs 15 cm ge2 >= 50 supported / <= 10 not; rough side-step falls <= 41 supported / >= 59 not; combined_yaw_right falls at >= 2 seeds = cost present, 0 seeds = absent) and adoption under fact_rules_v1 plus post_a043_push4_v1 with every G-A044 threshold. Neither verdict rescues the other.
  Collection is G-A044's: all 69 cases in one pass, both combined-turn directions and all four push directions filmed on the candidate, every baseline counterpart reused by SHA.

HOW THE VALUE WAS CHOSEN
  source: workspace/training/quadruped/upload/plan/GO2_A043_YAW_RIGHT_AND_NEXT_20260926.md sections 3-4; reports/GO2_G_A043_READOUT.md; reports/GO2_G_A044_READOUT.md; evidence reports/evidence/go2_seed_pair_20260924/DIAL_THREE_POINTS.csv, reports/evidence/go2_a043_yaw_right_20260926/YAW_SUMMARY.csv, reports/evidence/go2_a043_scenario_split_20260922/SCENARIO_SPLIT.csv, reports/evidence/go2_reward_mechanism_20260917/PROBES.csv.
  role: Penalize z-axis base linear velocity using an L2 squared kernel (Isaac Lab v2.3.1, reports/evidence/go2_reward_term_roles_20260917/isaaclab_envs_mdp_rewards.py: torch.square(asset.data.root_lin_vel_b[:, 2])). It is the body frame's vertical speed squared - not foot height, not world-frame altitude, not ground clearance. On a slope the body frame tilts with the robot, so the same climb charges differently there than on flat ground.
  walk_margin: G-A033 walk margin +0.1359 -> +0.1540 at -1.25 (reports/evidence/go2_reward_mechanism_20260917/PROBES.csv, zone WALK, delta +0.0181, range_status OUT_OF_RANGE - beyond the walking values -2.0, -1.75 and -1.5). The stop zone's top is +0.0155, so the margin stays about ten times above it. A margin is reward arithmetic over measured postures; since the 2026-09-26 revision of reports/GO2_REWARD_MECHANISM_FORECAST.md section 8 it is not a ranking basis.
  situations: reports/evidence/go2_reward_mechanism_20260917/PROBE_SITUATIONS.csv at -1.25: walk +0.0181, climb +0.0386, sway -0.0705, push -0.0578. The sheet's post-hoc direction hits are 10 of 19 cumulative (A038 3/3, A043 4/8, A047 3/8; non-independent cells, not a statistical test); G-A043 went the opposite way on sway and on three of four push directions. The cells are carried as a record, not as a prediction this arm relies on.
  rule: -1.25 keeps the 0.25 interval of the three measured points (-2.0, -1.75, -1.5) and steps once beyond the relaxed end. The interval is an operational choice that keeps the existing spacing; it is not proven more informative than a smaller one. The larger step (-1.0) is G-A037's held value and further from the observed range.
  not_claimed: No score gain is estimated and no improvement is predicted. Three points on one training seed do not give a curve; the fall counters were non-monotone across them (rough side-step 59 -> 80 -> 24, push 22 -> 66 -> 10). A failure at -1.25 does not make G-A043's -1.5 result luck, and a success does not identify its cause.

LEVERS NOT MOVED
  lin_vel_z_l2_to_m15_again: -1.5 is measured (G-A043) and failed its gate. Repeating it on seed 42 adds nothing; repeating it on another seed is the v10 pair (G-A045/G-A046), which waits on open decision U2-SEED-REPLICATE-20260918.
  lin_vel_z_l2_to_m1: -1.0 (G-A037) stays on hold. It skips the next interval and its own derivation rests on the penalty-share rule that base data section 5 S5 reports as not holding across runs.
  track_lin_vel_xy_exp: held at 1.5: G-A042 raised it to 1.6 and the 10 cm two-or-more count went 43 -> 0 of 96 with posture falls 34 -> 85 (reports/GO2_G_A042_READOUT.md). The local extension of that dial is measured and closed.
  ang_vel_xy_l2: measured and closed for now in both directions on the stairs: -0.08 took the 10 cm climbed-robot count 90 -> 5 (G-A038) and the relaxation -0.04 took it 90 -> 34 with posture falls 34 -> 93 of 96 (G-A041).
  feet_air_time: held at 0.2: 0.01 and 0.1 were both rejected at stage 1 (A031, A032) and 0.35 stopped the policy (A015). It is air time, not foot height, so it does not address the tread.
  flat_orientation_l2: measured at -0.5 on this baseline (G-A047): INTERNAL_GATE_FAIL, its G3 hypothesis not supported (rough side-step falls 59 -> 60, tilt-only falls did not fall) and the policy slowed off flat ground. A smaller value has no direct evidence on the target behaviour; the 2026-09-26 policy revision withdrew its old second-place ranking.
  action_rate_l2: -0.008 is a valid rejection (A018) and reports/evidence/go2_reward_mechanism_20260917/PROBE_SITUATIONS.csv leaves climb, sway and push empty for this term, so no situation direction can be read for it.
  dof_acc_l2: G-A039 is on hold and sits outside the deployed six, which makes it dependent on open decision U1-R6-ENV-REWARD-20260918. The 2026-09-26 policy revision also withdrew its old priority.
  max_iterations: outside R-6 (not a reward weight). See notes.curriculum_lag.
  training_seed: outside R-6. The seed replicate is the v10 pair, open decision U2-SEED-REPLICATE-20260918.
  lin_vel_z_l2_to_m175: -1.75 is measured (G-A044): INTERNAL_GATE_FAIL, total 42.52861 -> 38.89379, rough side-step posture falls 59 -> 80 of 96, 15 cm ge2 0 of 96. Its non-monotone falls are one of this arm's contradicting rows.
  track_ang_vel_z_exp: computed and set aside in the 2026-09-26 candidate comparison (workspace/training/quadruped/upload/plan/GO2_POST_A047_POLICY_20260926.md): no direct evidence on the stairs or rough behaviour, and it is not one of the six deployed names.

WHAT IS AND IS NOT PROMISED
  Not promised: a higher score.  No gain estimate exists and one training seed cannot
  separate the lever from seed luck.
  Pre-registered: all other axes held -- per-scenario weighted loss at most twice its own
  evaluation sd (G3 2.03646, G4 0.99632, G5 0.05604, G6 0.86196, G7 0.40358), flat G1/G2 guards unchanged.

CHECKPOINT
  Evaluated at iter 900 of 1000, the iteration G-A033 was evaluated at.

VIDEOS (4 env x 500 steps)
  G2:combined_yaw_left:101   the mirror of the case that broke G-A043. Filmed so a recurrence is not read from one direction alone.
  G2:combined_yaw_right:101  the hypothesis cost indicator. G-A043 lost 29 of 96 robots here to posture falls with 0 terminations and filmed none of it, so the shape is VIDEO_UNKNOWN to this day (the mean profile of the fallers shows lateral velocity and tilt growing about 1.5 s before the verdict, reports/evidence/go2_a043_yaw_right_20260926/YAW_PROFILE.csv; an average, not an individual sequence). This run films it.
  G3:rough_forward:101       the rough axis the arm must hold. Stored G-A033 video, reused by SHA.
  G3:rough_lateral:101       the rough hypothesis indicator (posture falls 59 / 80 / 24 across the three measured values). Baseline reused by SHA.
  G5:stairs_10_down:101      the adoption target the climbed-robot counter and the plan screening read. Baseline reused by SHA.
  G5:stairs_15_down:101      the stairs hypothesis indicator (15 cm ge2 0 / 0 / 77 of 96). Baseline reused by SHA.
  G6:push_pos_x:101          the push direction the fact_rules group scores. Baseline reused by SHA.
  G6:push_neg_x:101          push protection block direction. Baseline reused by SHA.
  G6:push_pos_y:101          push protection block direction. Baseline reused by SHA from the G-A044 run.
  G6:push_neg_y:101          push protection block direction. Baseline reused by SHA from the G-A044 run.

BASELINE ARM
  workspace/_keep/go2_g_a033_a017_track_lin_vel_xy_150 (G-A033, 42.52861/70 on the 69-case
  internal proxy).  Frozen baseline by G-D-BASELINE-A033-20260916.
  Its model and env ship here so the server can verify it is the same bytes.
