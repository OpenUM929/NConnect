# G-A058 보상 무변경 재학습 — 실행 목록과 판독 기준

근거·순서: `workspace/training/quadruped/upload/plan/GO2_OTHER_PC_SEQUENCE_PROPOSAL_20260930.md` (Codex 합의 2026-09-30). 다른 PC에서 G-A057 나머지 11행보다 먼저 돈다.

- a048_seed42: A048 보상 그대로, 학습 seed 42 — 다른 PC에서 A048과 동일 보상으로 얻는 비교 기준. 학습 변동의 크기·상한이 아니며 효과 판정 문턱으로 쓰지 않는다.
- a043_seed43: A043 보상 그대로, 학습 seed 43 — A043 보상의 독립 재학습. 15cm 계단 이득의 재현과 복합 우회전 결함의 분리 여부를 본다.
- a043_seed44: A043 보상 그대로, 학습 seed 44 — A043 보상의 독립 재학습. 15cm 계단 이득의 재현과 복합 우회전 결함의 분리 여부를 본다.

## 판독 기준 (결과를 보기 전에 고정)
- base_row: a048_seed42 는 서버 A048 과의 차이를 같은 지표로 기록만 한다. G-A057 행은 이 행과 먼저 비교하고, 서버 A048 대비 결과·기존 사전등록 판정도 따로 유지한다. 두 비교가 충돌하면 그대로 공개한다.
- individual_policy: 15cm stairs_15_down >=2단 >=50/96 이고 combined_yaw_right 자세 낙상 <=5/96 이면 공동 개선 후보로 전 축 검증 대상(다른 seed 결과와 무관). 채택 기준이 아니다.
- setting_reproducibility: {"reproduced": "두 A043 seed 모두 15cm >=50", "degraded": "두 seed 모두 <=10", "inconclusive": "그 밖(11~49 또는 두 seed 상반). 추가 학습 자동 금지"}
- yaw_right_defect: {"reproduced": ">=15/96", "partial": "6~14", "protected": "<=5"}
- thresholds: 이번 탐색용 기준이며 관측에서 나온 자연 경계가 아니다. 기존 A033 대조 채택 기준을 대체하지 않는다.
- causal_claims: 단일 학습 결과이므로 관측된 성능 차이로만 보고한다.
- submission: 다른 PC 정책은 탐색용이며 제출 후보가 아니다(R-6·제14조). 서버 재학습은 별도 판단.
