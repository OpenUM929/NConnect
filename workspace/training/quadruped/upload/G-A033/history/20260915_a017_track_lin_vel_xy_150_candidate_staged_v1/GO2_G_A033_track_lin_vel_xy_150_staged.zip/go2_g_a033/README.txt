GO2 G-A033 STAGED CANDIDATE — A017 + track_lin_vel_xy_exp 1.4 -> 1.5
====================================================================

This package TRAINS one policy and then measures it.  status: exploratory.

WHAT CHANGES
  The baseline is A017 (Pilot-01 + track_lin_vel_xy_exp 1.4), 39.76/70 on the
  69-case internal proxy (G-A027).  The candidate changes one reward only:
  track_lin_vel_xy_exp 1.4 -> 1.5.  Deployed train/play/task code is unchanged
  (R-6); only candidate/quadruped_rewards.py carries the new value.

WHY (plan GO2_BASIC_MOTION_TUNING_PLAN_20260915.md)
  A017 walks well on flat ground (G1/G2 survival 1.0, tracking >= .89) but on rough,
  slope and DR it moves at about half the commanded speed.
  Lowering feet_air_time (G-A031 0.01, G-A032 0.1) failed the target stage: G-A031 raised
  the body (slope posture falls 19 -> 1) but lost slope speed and tracking; G-A032 crouched.
  Plan 6-3 keeps feet_air_time 0.2 and moves to the tracking weight. 1.2 -> 1.4 was adopted
  (target +.083, total +6.09/70, G-D184); 1.5 is the Isaac Lab Go2 rough and flat value.
  Risk: a lower stance on the slope, as 1.2 -> 1.4 showed.

STAGES (run the target stage first)
  target (default, ~1h25m): training, catastrophe gate, the 9 target cases,
     5 sentinel cases, 5 videos, result ZIP.  Criterion 1 is decided
     on the target cases alone, so a target-stage FAIL is final for this arm.
  full (~55m more, only after the local verifier says TARGET_PASS_FULL_STAGE_REQUIRED):
     the other cases of the 69, the target stage kept, result ZIP again; criteria 2-4.

RUN
  unzip GO2_G_A033_track_lin_vel_xy_150_staged.zip -d /workspace
  PACKAGE_ROOT=/workspace/go2_g_a033 bash /workspace/go2_g_a033/server_run_go2_candidate_staged.sh
  GO2_STAGE=full GO2_RESUME=1 PACKAGE_ROOT=/workspace/go2_g_a033 bash /workspace/go2_g_a033/server_run_go2_candidate_staged.sh
  Finish marker (both stages): [DONE] GO2_G_A033_RESULT_READY; RUNNER_STATUS.txt carries STAGE and DECISION.

VIDEOS (relevant cases only; the A017 counterparts are in the G-A027 harvest)
  G1:forward_fast:101      flat gait at the fastest command: does the stronger speed push keep a normal gait
  G3:rough_forward:101     target: rough-terrain forward walking
  G4:slope_plus_20:101     target: speed and body height on the 20 deg climb (T2)
  G5:stairs_15_up:101      side effect: step climbing under a stronger speed push
  G7:dr_seed_101:101       target: walking under domain randomisation

DOWNLOAD
  /workspace/_keep/GO2_G_A033_RESULT.zip
  /workspace/_keep/GO2_G_A033_RESULT.zip.sha256

PRE-REGISTERED READING (plan section 6-1, fixed before the run)
  success needs all of:
   1 basic motion off flat ground: the mean case proxy (survival x tracking) over
     rough_forward, slope_plus_20 and the three DR cases (9 case-seeds) rises by
     >= 0.05, and at least 2 of the 3 groups improve   [target stage]
   2 total internal proxy delta >= 0.0/70, same evaluator                 [full stage]
   3 flat ground holds: G1/G2 scenario proxy drop <= 0.02, no G1/G2 case loses
     more than 0.03125 survival; no other scenario loses more than
     0.5/70 weighted                                         [full stage]
   4 POLICY_LOCOMOTES and no new stationary case outside the stairs (G5)   [full stage]
   5 videos show normal four-legged walking with the feet lifted (human reading)
  Height and posture-gate falls on the target cases are read as the mechanism,
  not as a criterion.  The expected weighted gain is NOT estimated.
  Official results remain OFFICIAL_RESULT_UNMEASURED.
